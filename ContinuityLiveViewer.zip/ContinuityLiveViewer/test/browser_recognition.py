"""Optional Playwright check using the real Node server and an injected API fixture.

No external exchange requests or downloaded datasets are used. Fixture data is
created only in a temporary test runner and never in the application frontend.
"""
import asyncio,json,subprocess,tempfile,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

async def run(output):
    from playwright.async_api import async_playwright
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    checks=[];errors=[]
    def check(name,value):
        checks.append({'check':name,'passed':bool(value)})
        print(('PASS ' if value else 'FAIL ')+name,flush=True)
    with tempfile.TemporaryDirectory() as tmp:
        runner=Path(tmp)/'fixture.mjs'
        runner.write_text('import {createServer} from '+json.dumps((ROOT/'server.js').as_uri())+''';
const M=60000,DAY=1440*M,at=Date.UTC(2026,8,15),now=at+3*DAY;
const client={base:'isolated synthetic API fixture',endpointFor:m=>m==='futures'?'https://fapi.binance.com/fapi/v1/klines':'https://www.binance.com/api/v3/uiKlines',load:async(q,{signal,onProgress})=>{
  onProgress({completed:0,total:1,message:'isolated fixture loading'});
  if(q.market==='futures'&&q.symbol==='NOFUTUREUSDT')throw Error('币安没有可查询的这个USDT合约');
  if(q.market==='futures'&&q.symbol==='SLOWMARKETUSDT')await new Promise((resolve,reject)=>{const timer=setTimeout(resolve,30000);signal.addEventListener('abort',()=>{clearTimeout(timer);reject(Error('cancelled fixture'));},{once:true});});
  if(q.symbol==='ERRORUSDT')throw Error('fixture API unavailable');
  if(q.symbol==='SLOWUSDT')await new Promise((resolve,reject)=>{const timer=setTimeout(resolve,30000);signal.addEventListener('abort',()=>{clearTimeout(timer);reject(Error('cancelled fixture'));},{once:true});});
  await new Promise(r=>setTimeout(r,100));signal.throwIfAborted();
  const rows=Array.from({length:Math.floor((q.end-q.historyStart)/M)+1},(_,i)=>{
    const time=q.historyStart+i*M,future=q.market==='futures',p=(100+i*.001+Math.sin(i/300)*3)*(future?1.2:1);
    const active=time>q.at-(future?3:2)*DAY||i%(future?7:3)===0,buy=active&&(time>q.at-(future?.5:1)*DAY||i%(future?3:2)===0);
    return {time,open:p-.02,high:time===q.at+DAY?500:p+(i%(future?110:120)<(future?40:50)?0:.05),low:p-(i%150<65?.02:.05),close:p,volume:active?2:0,quote:active?2*p:0,trades:active?2:0,takerQuote:buy?p:0};
  });onProgress({completed:1,total:1,message:'fixture loaded'});return rows;
},loadRecognition:async(q,previous,{signal})=>{signal.throwIfAborted();const step=q.period*60000,start=Math.floor((q.start-73*DAY)/step)*step,end=Math.floor(q.end/step)*step;const rows=Array.from({length:(end-start)/step+1},(_,i)=>{const d=i*step/DAY,j=i*q.period/15,a=Math.exp(10+Math.sin((i*step%DAY)/DAY*2*Math.PI)*.5+Math.sin(j*1.37)*.2+(d>69?-1:0)+(d>75?2:0));return {time:start+i*step,total:a,takerBuy:a*.54,close:100+Math.sin(j*.2)*.01,market:Math.exp(12+Math.sin((i*step%DAY)/DAY*2*Math.PI)*.3+Math.cos(j*.77)*.4)}});return {rows,start,end,period:q.period,source:'isolated period-follow fixture',warnings:[]}}};
const server=createServer({client,now:()=>now});server.listen(0,'127.0.0.1',()=>console.log(server.address().port));
process.on('SIGTERM',()=>{server.close();server.closeAllConnections();});
''')
        process=subprocess.Popen(['node',str(runner)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            port=process.stdout.readline().strip()
            if not port.isdigit():raise RuntimeError('Fixture server startup failed: '+process.stderr.read())
            base='http://127.0.0.1:'+port
            async with async_playwright() as pw:
                browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
                page=await browser.new_page(viewport={'width':1500,'height':900},device_scale_factor=1)
                page.on('pageerror',lambda e:errors.append(str(e)))
                requests=[];page.on('request',lambda r:requests.append(r.url))
                external=[];page.on('request',lambda r:external.append(r.url) if not r.url.startswith(base) else None)
                await page.add_init_script("window.drawWidths=[];const width=Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype,'lineWidth');Object.defineProperty(CanvasRenderingContext2D.prototype,'lineWidth',{...width,set(v){window.drawWidths.push({id:this.canvas.id,width:v});width.set.call(this,v)}})")
                await page.add_init_script("window.multiplePatterns=[];const originalDash=CanvasRenderingContext2D.prototype.setLineDash;CanvasRenderingContext2D.prototype.setLineDash=function(pattern){if(pattern.length===2&&pattern[0]===1&&pattern[1]===3)window.multiplePatterns.push({cap:this.lineCap,color:this.strokeStyle});return originalDash.call(this,pattern)}")
                await page.goto(base);await page.wait_for_function('() => (document.querySelector("#at").value!=="")')
                await page.locator('#symbol').fill('牛来');await page.locator('#at').fill('2026-09-15T08:00')
                await page.locator('#query').click();await page.wait_for_function('() => (window.liveViewer.data!==null)')
                await page.wait_for_timeout(100)
                check('three new chart data arrays exist',await page.evaluate('liveViewer.data.volumeRecognition.length>0&&liveViewer.data.volumeReexpansion.length>0'))
                check('full prior state is available',await page.evaluate('liveViewer.data.recognitionMeta.priorPoint!==null'))
                check('v3 includes both early alert and upgrade events',await page.evaluate('liveViewer.data.volumeReexpansion.some(r=>r.alert)&&liveViewer.data.volumeReexpansion.some(r=>r.upgrade)'))
                await page.evaluate('window.nativeBefore=JSON.stringify([liveViewer.data.volumeRecognition,liveViewer.data.volumeReexpansion]);window.coreBefore=JSON.stringify([liveViewer.data.candles,liveViewer.data.scores]);window.priceBefore=document.querySelector(".price-card").getBoundingClientRect().height')
                for key in ['recognition','reexpansion','flow']:
                    await page.locator('#'+key+'-chart').scroll_into_view_if_needed();await page.wait_for_timeout(100)
                    check(key+' plot has exact 150 pixel height',await page.locator('#'+key+'-chart').evaluate('c=>c.getBoundingClientRect().height===150'))
                    check(key+' plot follows initial three minute frequency',await page.locator('#'+key+'-chart').get_attribute('data-period')=='3')
                    await page.locator('#'+key+'-chart').hover(position={'x':450,'y':60});await page.wait_for_timeout(80)
                    check(key+' crosshair follows selected candle',await page.evaluate('liveViewer.charts.cursor%(liveViewer.data.period*60000)===0'))
                    check(key+' uses inline readout without floating tooltip',not await page.locator('#tooltip').is_visible() and len(await page.locator('#'+key+'-readout').inner_text())>15)
                check('v2 axis is zero to 36',await page.locator('#recognition-chart').get_attribute('data-y-min')=='0' and await page.locator('#recognition-chart').get_attribute('data-y-max')=='36')
                check('v3 axis is minus three to three',await page.locator('#reexpansion-chart').get_attribute('data-y-min')=='-3' and await page.locator('#reexpansion-chart').get_attribute('data-y-max')=='3')
                check('flow left axis is symmetric and right capped at five',await page.evaluate('(()=>{const d=document.querySelector("#flow-chart").dataset;return Number(d.yMin)===-Number(d.yMax)&&Number(d.yMax)>=1&&d.rightMax==="5"})()'))
                await page.locator('#reexpansion-chart').scroll_into_view_if_needed();await page.wait_for_timeout(80)
                check('actual v3 event markers were drawn',int(await page.locator('#reexpansion-chart').get_attribute('data-markers'))>0)
                # Viewport linkage from each new canvas.
                for key in ['recognition','reexpansion','flow']:
                    await page.locator('#'+key+'-chart').scroll_into_view_if_needed();await page.wait_for_timeout(80)
                    before=await page.evaluate('JSON.stringify(liveViewer.charts.view)')
                    await page.locator('#'+key+'-chart').hover(position={'x':450,'y':60});await page.mouse.wheel(0,-150);await page.wait_for_timeout(100)
                    check(key+' can zoom shared time range',await page.evaluate('JSON.stringify(liveViewer.charts.view)')!=before)
                    check(key+' viewport matches shared range',await page.locator('#'+key+'-chart').evaluate('c=>Number(c.dataset.timeStart)===liveViewer.charts.view[0]&&Number(c.dataset.timeEnd)===liveViewer.charts.view[1]'))
                await page.evaluate('liveViewer.charts.fit();window.beforeHide=JSON.stringify(liveViewer.charts.view)')
                for key in ['recognition','reexpansion','flow']:
                    await page.locator('#visible-'+key).uncheck();check(key+' can be hidden',not await page.locator('#'+key+'-chart').is_visible())
                    await page.locator('#visible-'+key).check()
                check('visibility preserves price height and time',await page.evaluate('document.querySelector(".price-card").getBoundingClientRect().height===window.priceBefore&&JSON.stringify(liveViewer.charts.view)===window.beforeHide'))
                for period in [1,3,5,30,60,15]:
                    await page.locator('#period').select_option(str(period))
                    await page.wait_for_function('(p)=>liveViewer.data.period===p&&liveViewer.data.recognitionMeta.stepMinutes===p&&!document.querySelector("#query").disabled',arg=period,timeout=180000)
                    check(str(period)+' minute backend uses selected step for both algorithms',await page.evaluate('(p)=>liveViewer.data.recognitionMeta.recognition.stepMin===p&&liveViewer.data.recognitionMeta.reexpansion.stepMin===p',period))
                    check(str(period)+' minute recognition points align exactly with K-line timestamps',await page.evaluate('()=>{const d=liveViewer.data;return d.volumeRecognition.length===d.candles.length&&d.volumeReexpansion.length===d.candles.length&&d.candles.every((r,i)=>r.time===d.volumeRecognition[i].time&&r.time===d.volumeReexpansion[i].time)}'))
                    check(str(period)+' minute windows retain clock durations',await page.evaluate('liveViewer.data.recognitionMeta.reexpansion.flowHours===72&&liveViewer.data.recognitionMeta.reexpansion.armDays===5'))
                    for key in ['recognition','reexpansion','flow']:
                        await page.locator('#'+key+'-chart').scroll_into_view_if_needed();await page.wait_for_timeout(60)
                        check(key+' axis follows '+str(period)+' minute step',await page.locator('#'+key+'-chart').get_attribute('data-period')==str(period))
                        check(key+' title follows '+str(period)+' minute step',('1小时' if period==60 else str(period)+'分钟') in await page.locator('#'+key+'-title').inner_text())
                        await page.locator('#'+key+'-chart').hover(position={'x':450,'y':60});await page.wait_for_timeout(60)
                        check(key+' hover aligns old K-line readout at '+str(period),await page.evaluate('()=>{const v=liveViewer,c=v.charts.cursor,r=v.data.candles.find(r=>r.time===c);return !!r&&document.querySelector("#price-readout").textContent===v.charts.priceText(r)}'))
                check('period change actually recomputes recognition data',await page.evaluate('JSON.stringify([liveViewer.data.volumeRecognition,liveViewer.data.volumeReexpansion])!==window.nativeBefore'))
                for key in ['recognition','reexpansion','flow']:
                    await page.locator('#'+key+'-chart').scroll_into_view_if_needed();await page.wait_for_timeout(60)
                    await page.locator('#'+key+'-chart').hover(position={'x':500,'y':60});await page.mouse.wheel(0,-250);await page.wait_for_timeout(60)
                    before=await page.evaluate('JSON.stringify(liveViewer.charts.view)')
                    rect=await page.locator('#'+key+'-chart').bounding_box()
                    await page.mouse.move(rect['x']+500,rect['y']+60);await page.mouse.down();await page.mouse.move(rect['x']+530,rect['y']+60);await page.mouse.up();await page.wait_for_timeout(80)
                    check(key+' drag changes shared time range',await page.evaluate('JSON.stringify(liveViewer.charts.view)')!=before)
                    await page.locator('#price-chart').scroll_into_view_if_needed();await page.wait_for_timeout(80)
                    check(key+' drag propagates to old charts',await page.locator('#price-chart').evaluate('c=>Number(c.dataset.timeStart)===liveViewer.charts.view[0]&&Number(c.dataset.timeEnd)===liveViewer.charts.view[1]'))
                await page.evaluate('window.v3Before=JSON.stringify(liveViewer.data.volumeReexpansion);window.coreBefore=JSON.stringify([liveViewer.data.candles,liveViewer.data.scores])')
                await page.locator('#recognition-h').fill('15');await page.locator('#recognition-h').press('Tab');await page.wait_for_function('()=>liveViewer.data.recognitionMeta.recognition.cusumH===15&&!document.querySelector("#query").disabled',timeout=60000)
                check('v2 controls are independent of v3 and old charts',await page.evaluate('JSON.stringify(liveViewer.data.volumeReexpansion)===window.v3Before&&JSON.stringify([liveViewer.data.candles,liveViewer.data.scores])===window.coreBefore'))
                await page.evaluate('window.v2Before=JSON.stringify(liveViewer.data.volumeRecognition)')
                await page.locator('#reexpansion-short-k').fill('0.7');await page.locator('#reexpansion-short-k').press('Tab');await page.wait_for_function('()=>liveViewer.data.recognitionMeta.reexpansion.shortK===0.7&&!document.querySelector("#query").disabled',timeout=60000)
                check('v3 controls preserve v2',await page.evaluate('JSON.stringify(liveViewer.data.volumeRecognition)===window.v2Before'))
                # Real readout vs display cap, and explicit gap break.
                await page.evaluate('''()=>{const rows=liveViewer.data.volumeReexpansion;const i=Math.floor(rows.length/2);window.flowTarget=rows[i].time;rows[i].absorb=8;rows[i+1].absorb=null;window.flowPaths=[];for(const n of ['moveTo','lineTo']){const f=CanvasRenderingContext2D.prototype[n];CanvasRenderingContext2D.prototype[n]=function(x,y){if(this.canvas.id==='flow-chart'&&this.strokeStyle==='#e08a00')window.flowPaths.push({n,x,y});return f.call(this,x,y)}}liveViewer.charts.cursor=window.flowTarget;liveViewer.charts.fit();liveViewer.charts.schedule()}''')
                await page.locator('#flow-chart').scroll_into_view_if_needed();await page.wait_for_timeout(80)
                flow_position=await page.evaluate('()=>{const c=liveViewer.charts,g=c.geometry(document.querySelector("#flow-chart"));return {x:g.L+(flowTarget+liveViewer.data.period*60000*.2-c.view[0])/(c.view[1]-c.view[0])*(g.w-g.L-g.R),y:60}}')
                await page.locator('#flow-chart').hover(position=flow_position);await page.wait_for_timeout(150)
                check('absorb readout retains actual value beyond five', '8×' in await page.locator('#flow-readout').inner_text())
                check('absorb plot caps coordinates without crossing missing bar',await page.evaluate('''()=>{const c=liveViewer.charts,g=c.geometry(document.querySelector('#flow-chart')),x=t=>g.L+(t-c.view[0])/(c.view[1]-c.view[0])*(g.w-g.L-g.R);return flowPaths.some(p=>Math.abs(p.x-x(flowTarget))<.01&&Math.abs(p.y-g.T)<.01)&&flowPaths.some(p=>p.n==='moveTo'&&Math.abs(p.x-x(flowTarget+1800000))<.01)}'''))
                for key in ['score','state','uw','strength','buyz','bbw','amountz','volume']:
                    await page.locator('#visible-'+key).uncheck()
                await page.locator('#reexpansion-chart').scroll_into_view_if_needed();await page.screenshot(path=str(output/'three-charts.png'))
                check('no browser runtime errors',not errors)
                check('no fixture network calls escape local server',not external)
                await browser.close()
        finally:
            process.terminate()
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:process.kill();process.wait()
    (output/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
    if not all(c['passed'] for c in checks):raise SystemExit(1)

if __name__=='__main__':asyncio.run(run(sys.argv[1] if len(sys.argv)>1 else '/tmp/live-viewer-browser'))
