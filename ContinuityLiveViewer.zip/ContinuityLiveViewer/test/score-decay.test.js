import test from 'node:test';
import assert from 'node:assert/strict';
import {createScoreKernel,scoreSettings} from '../lib/score-decay.js';
import {parseQuery} from '../lib/binance.js';
import {plan,keepScores} from '../lib/sessions.js';
import {computeView} from '../lib/metrics.js';
const M=60000,D=1440*M,at=Date.UTC(2026,8,15);
test('all decay kernels match direct age-weighted sums across transition and long tail',()=>{
 for(const days of [1,3,7,14]){
  const k=createScoreKernel({scoreDecayDays:days}),s=k.kernelState(),values=[];
  for(let i=0;i<=days*1440*3;i++){
   const v=i%71<23?1:((i%13)/13);values.push(v);const actual=k.advance(s,v,i);
   if([0,days*1440-1,days*1440,days*1440+1,days*1440*3].includes(i)){
    let expected=0;for(let j=0;j<=i;j++){const age=i-j,w=age<=days*1440?2**(-age/(days*1440)):.5*2**(-(age-days*1440)/(days*1440/7));expected+=values[j]*w;}
    assert.ok(Math.abs(actual-expected)<1e-6,`${days} days at ${i}`);
    let omitted=0;for(let age=i+1;age<i+days*1440*35;age++)omitted+=age<=days*1440?2**(-age/(days*1440)):.5*2**(-(age-days*1440)/(days*1440/7));
    assert.ok(Math.abs(k.tailWeight(i)-omitted)<1e-5);
   }
  }
  assert.equal(k.settings.warmupDays,2*days);
 }
 assert.throws(()=>scoreSettings({scoreDecayDays:2}));
});
test('two week change plans only missing warmup history and never reuses old decay scores',()=>{
 const q=parseQuery({symbol:'BTC',at:new Date(at).toISOString()},at+D),previous={query:q,result:{scores:[{time:at,buyScore:77}]}};
 assert.equal(q.scoreDecayDays,7);assert.equal(q.historyDays,28);
 const next=plan({action:'period',scoreDecayDays:14},previous,at+D);
 assert.equal(next.query.historyDays,56);assert.equal(next.load.historyStart,q.historyStart-28*D);assert.equal(next.load.end,q.historyStart-M);
 const scores=[{time:at,buyScore:12}];assert.deepEqual(keepScores(scores,previous,next.query),scores);
 const shorter=plan({action:'period',scoreDecayDays:1},{query:next.query},at+D);assert.equal(shorter.load,null);assert.equal(shorter.query.historyDays,56);
 assert.throws(()=>parseQuery({symbol:'BTC',at:new Date(at).toISOString(),scoreDecayDays:2},at+D));
});
test('decay selections change actual scores, preserve price and state, and remain causal',()=>{
 const rows=Array.from({length:60*1440},(_,i)=>({time:at-60*D+i*M,open:100,high:100,low:100,close:100,volume:1,quote:100,trades:i<56*1440?1:Number(i%3===0),takerQuote:i<56*1440?50:Number(i%7===0)*50}));
 const base={at:rows.at(-1).time,start:at-D,end:rows.at(-1).time,historyStart:rows[0].time,period:5};
 const results=[1,3,7,14].map(scoreDecayDays=>computeView(rows,{...base,scoreDecayDays}));
 for(let i=0;i<4;i++){
  const out=results[i];assert.ok(out.scores.every(r=>Number.isFinite(r.buyScore)));
  assert.deepEqual(out.candles,results[0].candles);assert.deepEqual(out.states,results[0].states);
  const cutoff=at-720*M;
  const prefix=computeView(rows.filter(r=>r.time<=cutoff),{...base,end:cutoff,scoreDecayDays:[1,3,7,14][i]});
  assert.deepEqual(prefix.scores,out.scores.filter(r=>r.time<=cutoff));
 }
 for(let i=1;i<4;i++)assert.ok(results[i].scores.at(-1).buyScore>results[i-1].scores.at(-1).buyScore);
});
