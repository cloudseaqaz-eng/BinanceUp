import test from 'node:test';
import assert from 'node:assert/strict';
import {volumePersistenceSettings,volumeContributions,computeVolumePersistence} from '../lib/volume-persistence.js';
import {computeView} from '../lib/metrics.js';
import {parseQuery} from '../lib/binance.js';
import {plan} from '../lib/sessions.js';
const M=60000,D=1440*M,at=Date.UTC(2026,8,15),near=(a,b,tol=1e-9)=>assert.ok(Math.abs(a-b)<tol,`${a} != ${b}`);
const rows=(n,p=3)=>Array.from({length:n},(_,i)=>({time:at+i*p*M,buyZ:((i*17)%31-15)/5,tradeZ:((i*13)%37-18)/6}));
test('continuous high and low contributions have the agreed thresholds, endpoints and neutral interval',()=>{
 for(const [p,high,low] of [[0,0,1],[.1,0,.5],[.2,0,0],[.35,0,0],[.5,0,0],[.6,.2,0],[.8,.6,0],[1,1,0]]){const u=volumeContributions(p);near(u.high,high);near(u.low,low);}
 for(const p of [null,NaN,Infinity,-.1,1.1])assert.deepEqual(volumeContributions(p),{high:null,low:null});
 near(volumeContributions(.500001).high,.000002);near(volumeContributions(.199999).low,.000005);
 const settings={...volumePersistenceSettings(),rankBars:20,halfLifeMinutes:30},input=rows(200).map(r=>({...r,buyZ:1,tradeZ:-1})),out=computeVolumePersistence(input,settings);
 assert.equal(out.at(-1).buyPercentile,.5);for(const field of ['buyHighScore','tradeHighScore','buyLowScore','tradeLowScore'])assert.equal(out.at(-1)[field],0);
 input[150].buyZ=-1;input[150].tradeZ=-.1;const changed=computeVolumePersistence(input,settings);
 assert.equal(changed[150].buyLowContribution,1);assert.equal(changed[150].tradeHighContribution,1);assert.ok(changed[150].tradeZ<0);
});
test('all four integral channels match direct prior percentiles and independently weighted high/low contributions',()=>{
 for(const period of [1,3,5,15,30,60]){
  const settings={...volumePersistenceSettings({period}),rankBars:30,halfLifeMinutes:60},input=rows(650,period),out=computeVolumePersistence(input,settings),history={buy:[],trade:[]};
  for(let i=0;i<input.length;i++)for(const key of ['buy','trade']){
   const z=input[i][key+'Z'],h=input.slice(Math.max(0,i-30),i).map(r=>r[key+'Z']);
   const p=i<30?null:(h.filter(x=>x<z).length+.5*h.filter(x=>x===z).length)/h.length;
   const u=p===null?null:{High:Math.max(0,2*p-1),Low:Math.max(0,1-5*p)};history[key].push(u);
   if(p!==null){near(out[i][key+'Percentile'],p);near(out[i][key+'HighContribution'],u.High);near(out[i][key+'LowContribution'],u.Low);}
   for(const band of ['High','Low'])if(out[i][key+band+'Score']!==null){let num=0,den=0;for(let j=0;j<=i;j++)if(history[key][j]!==null){const w=2**(-(i-j)*period/60);num+=w*history[key][j][band];den+=w;}near(out[i][key+band+'Score'],100*num/den);}
  }
  for(const field of ['buyHighScore','tradeHighScore','buyLowScore','tradeLowScore'])assert.ok(out.some(r=>r[field]!==null));
 }
});
test('equal physical duration produces equal score response across candle periods',()=>{
 const scores=[];
 for(const period of [1,3,5,15,30,60]){
  const s={...volumePersistenceSettings({period}),rankBars:20,halfLifeMinutes:60},quiet=2400/period;
  const input=rows(quiet+120/period,period).map((r,i)=>({...r,buyZ:i<quiet?1:2+(i-quiet)*period,tradeZ:i<quiet?1:2+(i-quiet)*period}));
  const out=computeVolumePersistence(input,s),score=out[quiet+60/period-1].buyHighScore;
  near(score,50,1e-3);scores.push(score);assert.ok(out.at(-1).buyHighScore>74.9);const falling=input.map((r,i)=>i<quiet?r:{...r,buyZ:-2-(i-quiet)*period,tradeZ:-2-(i-quiet)*period});const low=computeVolumePersistence(falling,s);near(low[quiet+60/period-1].buyLowScore,50,1e-3);assert.ok(low.at(-1).tradeLowScore>74.9);
 }
 assert.ok(Math.max(...scores)-Math.min(...scores)<1e-3);
});
test('missing values stay unavailable, quality recovers, and future spikes cannot rewrite past percentiles or scores',()=>{
 const s={...volumePersistenceSettings(),rankBars:100,halfLifeMinutes:30},input=rows(500),original=computeVolumePersistence(input,s);
 assert.deepEqual(computeVolumePersistence(input.slice(0,350),s),original.slice(0,350));
 const changed=input.map((r,i)=>i>=350?{...r,buyZ:1e6,tradeZ:-1e6}:r);assert.deepEqual(computeVolumePersistence(changed,s).slice(0,350),original.slice(0,350));
 const gaps=input.map((r,i)=>i>=250&&i<255?{...r,buyZ:null,buyReason:'当前K线缺失'}:r),out=computeVolumePersistence(gaps,s);
 assert.equal(out[250].buyHighScore,null);assert.equal(out[250].buyLowScore,null);assert.equal(out[250].buyLowContribution,null);assert.equal(out[250].buyHighContribution,null);assert.equal(out[255].buyHighScore,null);assert.equal(out[255].buyReason,'分位历史不足');assert.notEqual(out.at(-1).buyHighScore,null);
 assert.equal(out[250].tradeHighScore,original[250].tradeHighScore);assert.ok(out.every(r=>r.buyHighScore===null||r.buyHighScore>=0&&r.buyHighScore<=100));
});
test('settings validate and query/session planning adds enough prehistory for two baselines plus long decay',()=>{
 const s=volumePersistenceSettings();assert.equal(s.rankDays,7);assert.equal(s.halfLifeMinutes,240);assert.equal(s.highThreshold,.5);assert.equal(s.lowThreshold,.2);
 const q=parseQuery({symbol:'BTC',at:new Date(at).toISOString()},at+30*D);assert.equal(q.historyDays,28);
 const long=parseQuery({symbol:'BTC',at:new Date(at).toISOString(),amountZDays:14,volumeRankDays:14,volumeHalfLife:4320},at+30*D);
 assert.ok(long.historyDays>=14+14+21);const change=plan({action:'period',amountZDays:14,volumeRankDays:14,volumeHalfLife:4320},{query:q},at+30*D);
 assert.ok(change.load&&change.query.historyStart<q.historyStart);assert.equal(change.query.volumeHalfLife,4320);
 assert.equal(plan({action:'extend',direction:'after'},{query:change.query},at+30*D).query.volumeRankDays,14);
 for(const options of [{volumeRankDays:5},{volumeHalfLife:30},{volumeRankDays:'7'}])assert.throws(()=>volumePersistenceSettings(options));
 assert.throws(()=>parseQuery({symbol:'BTC',at:new Date(at).toISOString(),volumeHalfLife:30},at+D));
});
test('integration uses prewindow raw Z, aligns with selected candles and leaves existing series unchanged',()=>{
 const start=at-25*D,input=Array.from({length:25*1440},(_,i)=>({time:start+i*M,open:100,close:100,high:101,low:99,quote:i%11===0?0:100+i%31,takerQuote:i%11===0?0:10+i%29,trades:1,volume:1}));
 for(const period of [3,60]){
  const q={period,start:at-D,at:at-D,end:input.at(-1).time,historyStart:start},out=computeView(input,q),all=computeView(input,{...q,start});
  assert.deepEqual(out.volumePersistence,all.volumePersistence.filter(r=>r.time>=q.start));assert.equal(out.volumePersistence.length,out.candles.length);assert.ok(out.volumePersistence.some(r=>r.buyHighScore!==null&&r.tradeHighScore!==null));
  const changed=computeView(input,{...q,volumeRankDays:3,volumeHalfLife:60});for(const key of ['candles','scores','states','uw','relativeStrength','buyPressure','bbw'])assert.deepEqual(out[key],changed[key]);assert.deepEqual(out.amountZ.map(r=>[r.time,r.buyZ,r.tradeZ]),changed.amountZ.map(r=>[r.time,r.buyZ,r.tradeZ]));
 }
});

test('omitted candle timestamps match explicit missing bars without stretching current contribution',()=>{
 const s={...volumePersistenceSettings(),rankBars:100,halfLifeMinutes:30},input=rows(500),dense=input.map((r,i)=>i>=250&&i<255?{...r,buyZ:null,tradeZ:null}:r),sparse=input.filter((_,i)=>i<250||i>=255);
 const expected=new Map(computeVolumePersistence(dense,s).map(r=>[r.time,r]));
 for(const r of computeVolumePersistence(sparse,s)){const e=expected.get(r.time);for(const key of ['buy','trade']){assert.equal(r[key+'Percentile'],e[key+'Percentile']);near(r[key+'Coverage'],e[key+'Coverage']);for(const band of ['High','Low']){if(e[key+band+'Score']===null)assert.equal(r[key+band+'Score'],null);else near(r[key+band+'Score'],e[key+band+'Score']);}}}
});
