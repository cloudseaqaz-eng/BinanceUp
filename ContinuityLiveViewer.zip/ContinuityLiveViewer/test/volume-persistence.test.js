import test from 'node:test';
import assert from 'node:assert/strict';
import {volumePersistenceSettings,volumeContribution,computeVolumePersistence} from '../lib/volume-persistence.js';
import {computeView} from '../lib/metrics.js';
import {parseQuery} from '../lib/binance.js';
import {plan} from '../lib/sessions.js';
const M=60000,D=1440*M,at=Date.UTC(2026,8,15),near=(a,b,tol=1e-9)=>assert.ok(Math.abs(a-b)<tol,`${a} != ${b}`);
const rows=(n,p=3)=>Array.from({length:n},(_,i)=>({time:at+i*p*M,buyZ:((i*17)%31-15)/5,tradeZ:((i*13)%37-18)/6}));
test('volume contribution uses only positive Z and top five percent, keeping ties at midrank',()=>{
 assert.equal(volumeContribution(1,.95),0);near(volumeContribution(1,.975),.5);assert.equal(volumeContribution(1,1),1);
 assert.equal(volumeContribution(0,1),0);assert.equal(volumeContribution(-1,1),0);assert.equal(volumeContribution(null,1),null);assert.equal(volumeContribution(1,null),null);
 const s={...volumePersistenceSettings(),rankBars:20,halfLifeMinutes:30},out=computeVolumePersistence(rows(200).map(r=>({...r,buyZ:1,tradeZ:-1})),s);
 assert.equal(out.at(-1).buyPercentile,.5);assert.equal(out.at(-1).buyScore,0);assert.equal(out.at(-1).tradeScore,0);
});
test('strictly prior midrank, gated contributions and normalized exponential score match independent direct calculation',()=>{
 for(const period of [1,3,5,15,30,60]){
  const s={...volumePersistenceSettings({period}),rankBars:30,halfLifeMinutes:60},input=rows(650,period),out=computeVolumePersistence(input,s),history={buy:[],trade:[]};
  for(let i=0;i<input.length;i++)for(const key of ['buy','trade']){
   const z=input[i][key+'Z'],h=input.slice(Math.max(0,i-30),i).map(r=>r[key+'Z']);
   const p=i<30?null:(h.filter(x=>x<z).length+.5*h.filter(x=>x===z).length)/h.length;
   const u=p===null?null:z<=0?0:Math.max(0,Math.min(1,(p-.95)/.05));history[key].push(u);
   if(p!==null)near(out[i][key+'Percentile'],p);
   if(out[i][key+'Score']!==null){let num=0,den=0;for(let j=0;j<=i;j++)if(history[key][j]!==null){const w=2**(-(i-j)*period/60);num+=w*history[key][j];den+=w;}near(out[i][key+'Score'],100*num/den);}
  }
  assert.ok(out.some(r=>r.buyScore!==null));
 }
});
test('equal physical duration produces equal score response across candle periods',()=>{
 const scores=[];
 for(const period of [1,3,5,15,30,60]){
  const s={...volumePersistenceSettings({period}),rankBars:20,halfLifeMinutes:60},quiet=2400/period;
  const input=rows(quiet+120/period,period).map((r,i)=>({...r,buyZ:i<quiet?1:2+(i-quiet)*period,tradeZ:i<quiet?1:2+(i-quiet)*period}));
  const out=computeVolumePersistence(input,s),score=out[quiet+60/period-1].buyScore;
  near(score,50,1e-3);scores.push(score);assert.ok(out.at(-1).buyScore>74.9);
 }
 assert.ok(Math.max(...scores)-Math.min(...scores)<1e-3);
});
test('missing values stay unavailable, quality recovers, and future spikes cannot rewrite past percentiles or scores',()=>{
 const s={...volumePersistenceSettings(),rankBars:100,halfLifeMinutes:30},input=rows(500),original=computeVolumePersistence(input,s);
 assert.deepEqual(computeVolumePersistence(input.slice(0,350),s),original.slice(0,350));
 const changed=input.map((r,i)=>i>=350?{...r,buyZ:1e6,tradeZ:-1e6}:r);assert.deepEqual(computeVolumePersistence(changed,s).slice(0,350),original.slice(0,350));
 const gaps=input.map((r,i)=>i>=250&&i<255?{...r,buyZ:null,buyReason:'当前K线缺失'}:r),out=computeVolumePersistence(gaps,s);
 assert.equal(out[250].buyScore,null);assert.equal(out[250].buyContribution,null);assert.equal(out[255].buyScore,null);assert.equal(out[255].buyReason,'分位历史不足');assert.notEqual(out.at(-1).buyScore,null);
 assert.equal(out[250].tradeScore,original[250].tradeScore);assert.ok(out.every(r=>r.buyScore===null||r.buyScore>=0&&r.buyScore<=100));
});
test('settings validate and query/session planning adds enough prehistory for two baselines plus long decay',()=>{
 const s=volumePersistenceSettings();assert.equal(s.rankDays,7);assert.equal(s.halfLifeMinutes,240);
 const q=parseQuery({symbol:'BTC',at:new Date(at).toISOString()},at+30*D);assert.equal(q.historyDays,28);
 const long=parseQuery({symbol:'BTC',at:new Date(at).toISOString(),amountZDays:14,volumeRankDays:14,volumeHalfLife:4320},at+30*D);
 assert.ok(long.historyDays>=14+14+21);const change=plan({action:'period',amountZDays:14,volumeRankDays:14,volumeHalfLife:4320},{query:q},at+30*D);
 assert.ok(change.load&&change.query.historyStart<q.historyStart);assert.equal(change.query.volumeHalfLife,4320);
 assert.equal(plan({action:'extend',direction:'after'},{query:change.query},at+30*D).query.volumeRankDays,14);
 for(const options of [{volumeRankDays:5},{volumeHalfLife:30},{volumeRankDays:'7'}])assert.throws(()=>volumePersistenceSettings(options));
 assert.throws(()=>parseQuery({symbol:'BTC',at:new Date(at).toISOString(),volumeHalfLife:30},at+D));
});
test('integration uses prewindow raw Z, aligns with selected candles and leaves existing series unchanged',()=>{
 const start=at-25*D,input=Array.from({length:25*1440},(_,i)=>({time:start+i*M,open:100,close:100,high:101,low:99,quote:i%11===0?0:100+i%31,takerQuote:i%11===0?0:10+i%29,trades:1,volume:1}));
 for(const period of [3,60]){
  const q={period,start:at-D,at:at-D,end:input.at(-1).time,historyStart:start},out=computeView(input,q),all=computeView(input,{...q,start});
  assert.deepEqual(out.volumePersistence,all.volumePersistence.filter(r=>r.time>=q.start));assert.equal(out.volumePersistence.length,out.candles.length);assert.ok(out.volumePersistence.some(r=>r.buyScore!==null&&r.tradeScore!==null));
  const changed=computeView(input,{...q,volumeRankDays:3,volumeHalfLife:60});for(const key of ['candles','scores','states','uw','relativeStrength','buyPressure','bbw','amountZ'])assert.deepEqual(out[key],changed[key]);
 }
});

test('omitted candle timestamps match explicit missing bars without stretching current contribution',()=>{
 const s={...volumePersistenceSettings(),rankBars:100,halfLifeMinutes:30},input=rows(500),dense=input.map((r,i)=>i>=250&&i<255?{...r,buyZ:null,tradeZ:null}:r),sparse=input.filter((_,i)=>i<250||i>=255);
 const expected=new Map(computeVolumePersistence(dense,s).map(r=>[r.time,r]));
 for(const r of computeVolumePersistence(sparse,s)){const e=expected.get(r.time);for(const key of ['buy','trade']){assert.equal(r[key+'Percentile'],e[key+'Percentile']);near(r[key+'Coverage'],e[key+'Coverage']);if(e[key+'Score']===null)assert.equal(r[key+'Score'],null);else near(r[key+'Score'],e[key+'Score']);}}
});
