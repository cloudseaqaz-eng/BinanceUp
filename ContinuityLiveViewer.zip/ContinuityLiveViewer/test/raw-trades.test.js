import test from 'node:test';
import assert from 'node:assert/strict';
import {RawTradeClient} from '../lib/raw-trades.js';
const T=Date.UTC(2026,8,1);
function fixture({maxRows=3000,mutate=x=>x}={}){
 const trades=Array.from({length:2500},(_,i)=>({id:i,time:T+i*1000,price:'2',qty:'3',quoteQty:String(i%5+1),isBuyerMaker:i%2===0})),calls=[];
 const client=new RawTradeClient({spacing:0,maxRows,fetchImpl:async url=>{calls.push(url);let body;if(url.pathname.endsWith('/aggTrades')){const first=trades.find(r=>r.time>=Number(url.searchParams.get('startTime')));body=first?[{f:first.id,T:first.time,p:'999999',q:'999999'}]:[];}else body=mutate(trades.filter(r=>r.id>=Number(url.searchParams.get('fromId'))).slice(0,1000).map(r=>({...r})));return new Response(JSON.stringify(body));}});return {client,trades,calls};
}
test('time lookup uses aggregate IDs only; all amounts and counts come from paginated raw fills',async()=>{
 const {client,calls}=fixture();const rows=await client.load({symbol:'BTCUSDT',start:T,end:T+2001*1000});assert.equal(rows.length,2001);assert.equal(rows[0].amount,1);assert.equal(rows.at(-1).id,2000);assert.equal(calls.filter(u=>u.pathname.endsWith('/historicalTrades')).length,3);assert.ok(!calls[0].searchParams.has('endTime'));
 const n=calls.length;assert.equal((await client.load({symbol:'BTCUSDT',start:T+1000,end:T+10000})).length,9);assert.equal(calls.length,n);
});
test('raw cache extends either side without refetching covered IDs',async()=>{
 const {client,calls}=fixture();await client.load({symbol:'BTCUSDT',start:T+100000,end:T+200000});const n=calls.length;
 const r=await client.load({symbol:'BTCUSDT',start:T+50000,end:T+250000});assert.equal(r.length,200);assert.equal(calls.length,n+4);assert.equal(new Set(r.map(x=>x.id)).size,200);
});
test('raw data errors, row cap, cancellation and forbidden API never produce approximate counts',async()=>{
 await assert.rejects(fixture({mutate:a=>a.map((r,i)=>i===2?{...r,id:999}:r)}).client.load({symbol:'BTCUSDT',start:T,end:T+100000}),/不连续/);
 await assert.rejects(fixture({maxRows:10}).client.load({symbol:'BTCUSDT',start:T,end:T+100000}),/上限/);
 const client=new RawTradeClient({spacing:0,fetchImpl:async()=>new Response('{}',{status:403})});await assert.rejects(client.load({symbol:'BTCUSDT',start:T,end:T+100000}),/HTTP 403/);
 const abort=new AbortController();abort.abort(Error('cancelled'));await assert.rejects(fixture().client.load({symbol:'BTCUSDT',start:T,end:T+100000},{signal:abort.signal}),/cancelled/);
});
