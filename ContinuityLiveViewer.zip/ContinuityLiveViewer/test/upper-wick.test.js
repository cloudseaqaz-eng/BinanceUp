import test from 'node:test';
import assert from 'node:assert/strict';
import {createUWCalculator,uwSettings} from '../lib/upper-wick.js';
import {computeView} from '../lib/metrics.js';
const M=60000;
function c(time,upper=0,lower=0,body=0){return {time,open:100,close:100+body,high:100+body+upper,low:100-lower};}
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-12,`${a} != ${b}`);
test('UW3 averages only upper shadow ratios over three selected candles',()=>{
 const calc=createUWCalculator(uwSettings({period:5}));
 assert.equal(calc.push(c(5*M,1)).zeroRate,null);assert.equal(calc.push(c(10*M,0,9)).zeroRate,null);
 const r=calc.push(c(15*M,0,0,10));close(r.uw3,1/3);assert.equal(r.zeroInput,0);assert.equal(r.zeroRate,0);
});
test('zero upper shadows give one regardless of lower shadows',()=>{
 for(const [upper,lower,body,zero,total] of [[1,0,0,0,1],[0,1,0,1,0],[1,1,0,0,.5],[0,0,1,1,0]]){
  const calc=createUWCalculator(uwSettings());let r;for(let i=1;i<=3;i++)r=calc.push(c(i*3*M,upper,lower,body));assert.equal(r.zeroInput,zero);assert.equal(r.zeroRate,zero);close(r.uw3,total);
 }
});
test('any upper shadow in the last three candles prevents zero while lower shadows do not',()=>{
 const calc=createUWCalculator(uwSettings());const values=[[1,0],[0,1],[0,0],[0,0],[0,0]];
 const rows=values.map(([u,l],i)=>calc.push(c((i+1)*3*M,u,l,1)));
 assert.equal(rows[2].zeroInput,0);assert.equal(rows[3].zeroInput,1);assert.equal(rows[4].zeroInput,1);
 // Even an extremely short nonzero wick is still nonzero, with no threshold.
 assert.equal(calc.push(c(18*M,1e-8,0,1)).zeroInput,0);
});
test('causal time-aware zero-state EMA matches independent logic for all six periods',()=>{
 for(const period of [1,3,5,15,30,60])for(const uwHalfLife of [30,60,120,240,360,1440]){
  const settings=uwSettings({period,uwHalfLife}),calc=createUWCalculator(settings),history=[];let ema=null;
  for(let i=0;i<100;i++){
   const candle=c((i+1)*period*M,i%12<6?0:1,i%12<6?0:2,2);history.push(candle);const r=calc.push(candle);
   if(i<2){assert.equal(r.zeroRate,null);continue;}
   const raw=Number(history.slice(-3).every(k=>k.high===Math.max(k.open,k.close)));
   ema=ema===null?raw:settings.alpha*raw+(1-settings.alpha)*ema;assert.equal(r.zeroInput,raw);close(r.zeroRate,ema);assert.ok(r.zeroRate>=0&&r.zeroRate<=1);
  }
 }
});
test('known flat candles count as zero under the restored UW convention',()=>{
 const calc=createUWCalculator(uwSettings());assert.equal(calc.push(c(3*M)).zeroRate,null);assert.equal(calc.push(c(6*M)).zeroRate,null);const flat=calc.push(c(9*M));assert.equal(flat.uw3,0);assert.equal(flat.zeroInput,1);assert.equal(flat.zeroRate,1);
 assert.equal(calc.push(c(12*M,2,0)).zeroInput,0);for(let i=0;i<3;i++)calc.push(c((i+5)*3*M));assert.equal(calc.push(c(24*M)).zeroInput,1);
});
test('missing or invalid candles reset EMA and require three valid candles to recover',()=>{
 const calc=createUWCalculator(uwSettings());for(let i=0;i<3;i++)calc.push(c(i*3*M));
 const missing=calc.push({...c(9*M),open:null});assert.equal(missing.zeroRate,null);assert.equal(missing.uw3,null);assert.equal(calc.push(c(12*M,1,0)).zeroRate,null);assert.equal(calc.push(c(15*M,1,0)).zeroRate,null);assert.equal(calc.push(c(18*M,1,0)).zeroRate,0);
 assert.equal(calc.push({...c(21*M),high:99}).zeroRate,null);
});
test('integration uses complete period candles and pre-window history without future leakage',()=>{
 const start=Date.UTC(2026,8,1),rows=Array.from({length:1200},(_,i)=>({time:start+(i+1)*M,open:100,high:i%19===0?101:100,low:99,close:100,volume:1,quote:100,trades:1,takerQuote:50}));
 const q={at:start+1000*M,start:start+700*M,end:start+1200*M,historyStart:start+M,period:15};
 const view=computeView(rows,q),calc=createUWCalculator(uwSettings(q)),expected=[];
 for(let end=15;end<=1200;end+=15){const group=rows.slice(end-15,end),r=calc.push({time:group.at(-1).time,open:100,high:Math.max(...group.map(r=>r.high)),low:99,close:100});if(r.time>=q.start)expected.push(r);}
 assert.deepEqual(view.uw,expected);
 const short=computeView(rows,{...q,end:q.at});assert.deepEqual(short.uw,view.uw.filter(r=>r.time<=q.at));
 const changed=computeView(rows.map(r=>r.time>q.at?{...r,high:200}:r),q);assert.deepEqual(short.uw,changed.uw.filter(r=>r.time<=q.at));
});
test('wick settings validate; smoothing changes leave other charts unchanged',()=>{
 assert.throws(()=>uwSettings({uwHalfLife:5}));assert.throws(()=>uwSettings({period:2}));
 const start=Date.UTC(2026,8,1),rows=Array.from({length:200},(_,i)=>({time:start+(i+1)*M,open:100,high:i%30<15?102:101,low:100,close:101,volume:1,quote:100,trades:1,takerQuote:50}));
 const q={at:start+100*M,start,historyStart:start,end:start+200*M},a=computeView(rows,q),b=computeView(rows,{...q,uwHalfLife:240});assert.deepEqual(a.candles,b.candles);assert.deepEqual(a.scores,b.scores);assert.deepEqual(a.states,b.states);assert.notDeepEqual(a.uw,b.uw);
});
test('lower-shadow changes do not affect upper zero states or EMA',()=>{
 const settings=uwSettings({period:15}),first=createUWCalculator(settings),second=createUWCalculator(settings);
 for(let i=0;i<100;i++){
  const upper=i%12<6?0:1,a=first.push(c((i+1)*15*M,upper,0,1)),b=second.push(c((i+1)*15*M,upper,i%7,1));
  assert.equal(a.zeroRate,b.zeroRate);assert.equal(a.zeroInput,b.zeroInput);
 }
});
