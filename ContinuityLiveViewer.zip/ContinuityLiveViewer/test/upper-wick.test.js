import test from 'node:test';
import assert from 'node:assert/strict';
import {createUWCalculator,uwSettings} from '../lib/upper-wick.js';
import {computeView} from '../lib/metrics.js';
const M=60000;
function c(time,upper=0,lower=0,body=0){return {time,open:100,close:100+body,high:100+body+upper,low:100-lower};}
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-12,`${a} != ${b}`);
test('signed wick bias weights lengths by range across three selected candles',()=>{
 const calc=createUWCalculator(uwSettings({period:5}));
 assert.equal(calc.push(c(5*M,1)).bias,null);assert.equal(calc.push(c(10*M,0,9)).bias,null);
 const result=calc.push(c(15*M,0,0,10));close(result.biasInput,-.4);close(result.upperShare,.05);close(result.lowerShare,.45);close(result.totalShadow,.5);close(result.bias,-.4);
 // A mean of individual ratios would be zero, and would overweight the tiny bar.
});
test('bias reaches both signed extremes and separates balanced long shadows from no shadows',()=>{
 for(const [upper,lower,body,bias,total] of [[1,0,0,1,1],[0,1,0,-1,1],[1,1,0,0,1],[0,0,1,0,0]]){
  const calc=createUWCalculator(uwSettings());let r;for(let i=1;i<=3;i++)r=calc.push(c(i*3*M,upper,lower,body));close(r.bias,bias);close(r.totalShadow,total);
 }
});
test('time-aware causal EMA agrees with independent length sums for all six periods',()=>{
 for(const period of [1,3,5,15,30,60]){
  const settings=uwSettings({period,uwHalfLife:120}),calc=createUWCalculator(settings),history=[];let ema=null;
  for(let i=0;i<100;i++){
   const candle=c((i+1)*period*M,i%7,i%5,2);history.push(candle);const r=calc.push(candle);
   if(i<2){assert.equal(r.bias,null);continue;}
   const last=history.slice(-3);let sum=0,span=0;for(const k of last){sum+=k.high-Math.max(k.open,k.close)-(Math.min(k.open,k.close)-k.low);span+=k.high-k.low;}
   const raw=sum/span;ema=ema===null?raw:settings.alpha*raw+(1-settings.alpha)*ema;close(r.biasInput,raw);close(r.bias,ema);assert.ok(r.bias>=-1&&r.bias<=1);
  }
 }
});
test('all-flat windows are blank; a flat bar in a moving window contributes no range',()=>{
 const calc=createUWCalculator(uwSettings());for(let i=0;i<3;i++){const r=calc.push(c(i*3*M));assert.equal(r.bias,null);assert.equal(r.totalShadow,null);}
 const moving=calc.push(c(9*M,0,2));assert.equal(moving.biasInput,-1);assert.equal(moving.bias,-1);
 for(let i=0;i<3;i++)calc.push(c((i+4)*3*M));assert.equal(calc.push(c(21*M,1)).bias,1);
});
test('missing or invalid candles reset smoothing and need three complete candles to recover',()=>{
 const calc=createUWCalculator(uwSettings());for(let i=0;i<3;i++)calc.push(c(i*3*M,2));
 assert.equal(calc.push({...c(9*M),open:null}).bias,null);assert.equal(calc.push(c(12*M,0,1)).bias,null);assert.equal(calc.push(c(15*M,0,1)).bias,null);assert.equal(calc.push(c(18*M,0,1)).bias,-1);
 assert.equal(calc.push({...c(21*M),high:99}).bias,null);
});
test('integration uses complete period candles and pre-window history without future leakage',()=>{
 const start=Date.UTC(2026,8,1),rows=Array.from({length:1200},(_,i)=>({time:start+(i+1)*M,open:100,high:i%19===0?101:100,low:99,close:100,volume:1,quote:100,trades:1,takerQuote:50}));
 const q={at:start+1000*M,start:start+700*M,end:start+1200*M,historyStart:start+M,period:15};
 const view=computeView(rows,q),calc=createUWCalculator(uwSettings(q)),expected=[];
 for(let end=15;end<=1200;end+=15){const group=rows.slice(end-15,end),r=calc.push({time:group.at(-1).time,open:100,high:Math.max(...group.map(r=>r.high)),low:99,close:100});if(r.time>=q.start)expected.push(r);}
 assert.deepEqual(view.uw,expected);
 const short=computeView(rows,{...q,end:q.at});assert.deepEqual(short.uw,view.uw.filter(r=>r.time<=q.at));
 const changed=computeView(rows.map(r=>r.time>q.at?{...r,high:200}:r),q);assert.deepEqual(short.uw,changed.uw.filter(r=>r.time<=q.at));
});
test('wick settings validate; smoothing changes leave candles, scores and states unchanged',()=>{
 assert.throws(()=>uwSettings({uwHalfLife:5}));assert.throws(()=>uwSettings({period:2}));
 const start=Date.UTC(2026,8,1),rows=Array.from({length:200},(_,i)=>({time:start+(i+1)*M,open:100,high:i%30<15?101:100,low:99,close:100,volume:1,quote:100,trades:1,takerQuote:50}));
 const q={at:start+100*M,start,historyStart:start,end:start+200*M},a=computeView(rows,q),b=computeView(rows,{...q,uwHalfLife:240});assert.deepEqual(a.candles,b.candles);assert.deepEqual(a.scores,b.scores);assert.deepEqual(a.states,b.states);assert.notDeepEqual(a.uw,b.uw);
});
test('reflecting prices reverses bias while preserving total shadow degree',()=>{
 const settings=uwSettings({period:15}),up=createUWCalculator(settings),down=createUWCalculator(settings);
 for(let i=0;i<100;i++){
  const candle=c((i+1)*15*M,i%7,i%5,1),mirrored={time:candle.time,open:200-candle.open,close:200-candle.close,high:200-candle.low,low:200-candle.high},a=up.push(candle),b=down.push(mirrored);
  if(a.bias===null){assert.equal(b.bias,null);continue;}close(a.bias,-b.bias);close(a.biasInput,-b.biasInput);close(a.totalShadow,b.totalShadow);close(a.upperShare,b.lowerShare);
 }
});
