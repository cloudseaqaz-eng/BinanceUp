import test from 'node:test';
import assert from 'node:assert/strict';
import {createUWCalculator,uwSettings} from '../lib/upper-wick.js';
import {computeView} from '../lib/metrics.js';
const M=60000;
function c(time,ratio=0){return {time,open:100,close:100,high:100+ratio,low:99+ratio};}
test('UW3 is last three selected candles, single and soft indicators are distinct',()=>{
 const settings=uwSettings({period:5}),calc=createUWCalculator(settings),ratios=[0,0,.3,0,0,0];
 const output=ratios.map((r,i)=>calc.push(c((i+1)*5*M,r)));
 assert.equal(output[1].uw3,null);assert.ok(Math.abs(output[2].uw3-.1)<1e-12);assert.equal(output[2].threeInput,0);assert.equal(output[3].singleInput,1);assert.equal(output[3].threeInput,0);assert.equal(output[5].threeInput,1);assert.ok(Math.abs(output[2].softInput-Math.exp(-3))<1e-12);
});
test('time-aware one-sided EMA matches independent recurrence across every period',()=>{
 for(const period of [1,3,5,15,30,60]){
  const settings=uwSettings({period,uwHalfLife:120}),calc=createUWCalculator(settings),previous={three:null,single:null,soft:null},history=[];
  for(let i=0;i<100;i++){
   const r=calc.push(c((i+1)*period*M,i%4===0?.4:0));history.push(r);
   for(const key of Object.keys(previous)){
    const input=r[key+'Input'];previous[key]=input===null?null:previous[key]===null?input:settings.alpha*input+(1-settings.alpha)*previous[key];assert.ok(r[key]===null&&previous[key]===null||Math.abs(r[key]-previous[key])<1e-12);
    const last=history.slice(-settings.referenceBars).map(x=>x[key+'Input']);const expected=last.length===settings.referenceBars&&last.every(x=>x!==null)?last.reduce((a,b)=>a+b,0)/settings.referenceBars:null;assert.equal(r[key+'Reference'],expected);
   }
  }
 }
});
test('flat candles count zero, missing candles blank and reset each indicator separately',()=>{
 const calc=createUWCalculator(uwSettings({period:3}));const flat={time:3*M,open:100,high:100,low:100,close:100};
 assert.equal(calc.push(flat).single,1);calc.push(flat);assert.equal(calc.push(flat).three,1);
 const unknown=calc.push({...flat,open:null});assert.equal(unknown.three,null);assert.equal(unknown.single,null);assert.equal(unknown.soft,null);
 assert.equal(calc.push(flat).three,null);assert.equal(calc.push(flat).three,null);assert.equal(calc.push(flat).three,1);
});
test('integration uses complete period candles and full pre-window history with no future leakage',()=>{
 const start=Date.UTC(2026,8,1),rows=Array.from({length:1200},(_,i)=>({time:start+(i+1)*M,open:100,high:i%19===0?101:100,low:99,close:100,volume:1,quote:100,trades:1,takerQuote:50}));
 const q={at:start+1000*M,start:start+700*M,end:start+1200*M,historyStart:start+M,period:15};
 const view=computeView(rows,q),calc=createUWCalculator(uwSettings(q));let expected=[];
 for(let end=15;end<=1200;end+=15){const group=rows.slice(end-15,end);const o=calc.push({time:group.at(-1).time,open:group[0].open,high:Math.max(...group.map(r=>r.high)),low:99,close:100});if(o.time>=q.start)expected.push(o);}
 assert.deepEqual(view.uw,expected);
 const short=computeView(rows,{...q,end:q.at});assert.deepEqual(short.uw,view.uw.filter(r=>r.time<=q.at));
 const changed=computeView(rows.map(r=>r.time>q.at?{...r,high:200}:r),q);assert.deepEqual(short.uw,changed.uw.filter(r=>r.time<=q.at));
});
test('UW settings reject invalid values and half-life smoothing leaves core data unchanged',()=>{
 assert.throws(()=>uwSettings({uwHalfLife:5}));assert.throws(()=>uwSettings({uwSoftScale:0}));
 const start=Date.UTC(2026,8,1),rows=Array.from({length:200},(_,i)=>({time:start+(i+1)*M,open:100,high:i%2?101:100,low:99,close:100,volume:1,quote:100,trades:1,takerQuote:50}));
 const q={at:start+100*M,start,historyStart:start,end:start+200*M};const a=computeView(rows,q),b=computeView(rows,{...q,uwHalfLife:240,uwSoftScale:.2});assert.deepEqual(a.candles,b.candles);assert.deepEqual(a.scores,b.scores);assert.deepEqual(a.states,b.states);assert.notDeepEqual(a.uw,b.uw);
});
