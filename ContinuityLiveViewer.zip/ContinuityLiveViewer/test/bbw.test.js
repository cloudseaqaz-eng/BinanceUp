import test from 'node:test';
import assert from 'node:assert/strict';
import {bbwSettings,computeBBW} from '../lib/bbw.js';
import {computeView} from '../lib/metrics.js';
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-10,`${a} != ${b}`),M=60000;
test('BBW and strictly prior seven-day percentile match direct population-standard-deviation calculation',()=>{
 for(const period of [1,3,5,15,30,60]){
  const s=bbwSettings({period}),input=Array.from({length:s.baselineBars+150},(_,i)=>({time:i*period*M,close:100+Math.sin(i/11)*3+(i%13)/10})),out=computeBBW(input,s);
  const widths=input.map((_,i)=>{if(i<19)return null;const values=input.slice(i-19,i+1).map(r=>r.close),mean=values.reduce((a,b)=>a+b,0)/20;return 4*Math.sqrt(values.reduce((a,v)=>a+(v-mean)**2,0)/20)/mean;});
  for(const i of [s.baselineBars+19,s.baselineBars+41,input.length-1]){
   near(out[i].bbw,widths[i]);const prior=out.slice(i-s.baselineBars,i).map(r=>r.bbw);assert.equal(out[i].percentile,prior.filter(v=>v<=out[i].bbw).length/s.baselineBars);
  }
  assert.equal(out[s.baselineBars+18].percentile,null);
 }
});
test('flat prices have exact zero BBW and tied past values use original max-rank convention',()=>{
 const s={...bbwSettings(),baselineBars:30},input=Array.from({length:100},(_,i)=>({time:i*3*M,close:.1})),out=computeBBW(input,s);
 assert.equal(out.at(-1).bbw,0);assert.equal(out.at(-1).percentile,1);
});
test('missing candles blank current BBW and full baseline; future values never change history',()=>{
 const s={...bbwSettings(),baselineBars:30},input=Array.from({length:160},(_,i)=>({time:i*3*M,close:100+Math.sin(i/7)}));input[70].close=null;
 const out=computeBBW(input,s);for(let i=70;i<90;i++)assert.equal(out[i].bbw,null);for(let i=70;i<120;i++)assert.equal(out[i].percentile,null);assert.notEqual(out[120].percentile,null);
 assert.deepEqual(computeBBW(input.slice(0,130),s),out.slice(0,130));
 const changed=input.map((r,i)=>i>=130?{...r,close:1e8}:r);assert.deepEqual(computeBBW(changed,s).slice(0,130),out.slice(0,130));
});
test('integration follows selected period and uses prewindow candles',()=>{
 const start=Date.UTC(2026,7,1),rows=Array.from({length:12500},(_,i)=>({time:start+i*M,open:100,close:100+Math.sin(i/77),high:102,low:98,volume:1,quote:100,takerQuote:50,trades:1}));
 for(const period of [3,5,60]){
  const opts={period,at:rows.at(-1).time,start:start+12300*M,end:rows.at(-1).time,historyStart:start},out=computeView(rows,opts);
  assert.equal(out.bbw.length,out.candles.length);assert.equal(out.metaMetrics.bbwSettings.baselineBars,10080/period);assert.ok(out.bbw.some(r=>r.percentile!==null));
  assert.ok(out.bbw.every((r,i)=>r.time===out.candles[i].time));
 }
 assert.throws(()=>bbwSettings({period:2}));
});
