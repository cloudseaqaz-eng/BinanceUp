import test from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {createServer} from '../server.js';
const M=60000,D=1440*M,T=Date.UTC(2026,8,15);
async function serve(tradeClient,run){const client={load:async q=>Array.from({length:(q.end-q.historyStart)/M+1},(_,i)=>({time:q.historyStart+i*M,open:100,high:101,low:99,close:100,volume:1,quote:100,trades:1,takerQuote:100}))};const s=createServer({client,tradeClient,now:()=>T+8*D});s.listen(0,'127.0.0.1');await once(s,'listening');const base='http://127.0.0.1:'+s.address().port;
 async function post(path,body){const r=await fetch(base+path,{method:'POST',body:JSON.stringify(body)});return {status:r.status,...await r.json()};}
 async function poll(path,id){for(let i=0;i<200;i++){const r=await(await fetch(base+path+'/'+id)).json();if(r.status!=='running')return r;await new Promise(resolve=>setTimeout(resolve,10));}assert.fail('timeout');}
 try{const {id}=await post('/api/jobs',{symbol:'BTC',at:new Date(T).toISOString()}),core=(await poll('/api/jobs',id)).result;await run({post,poll,base,core});}finally{s.closeAllConnections();await new Promise(r=>s.close(r));}}
test('independent raw-trade job verifies counts computes minute frequency and preserves core query',async()=>{
 const raw={base:'raw fixture',load:async(q,{rows})=>rows.filter(r=>r.time>q.start&&r.time<=q.end).map((r,i)=>({id:i,time:r.time-M+1000,amount:i%11+1,isBuyerMaker:false}))};
 await serve(raw,async({post,poll,base,core})=>{
  const job=await post('/api/trade-jobs',{sessionId:core.sessionId,start:T,end:T+60*M});assert.equal(job.status,202);const result=await poll('/api/trade-jobs',job.id);assert.equal(result.status,'done');assert.equal(result.result.meta.verified,true);assert.equal(result.result.points.length,61);assert.ok(result.result.points.every(r=>r.count===null||r.rate===r.count/30));
  const still=await(await fetch(base+'/api/jobs/'+core.sessionId)).json();assert.deepEqual(still.result,core);
  assert.equal((await post('/api/trade-jobs',{sessionId:core.sessionId,start:T-100*D})).status,400);
 });
});
test('incomplete raw history gives an explicit isolated error and remains cancellable',async()=>{
 const raw={load:async()=>[]};await serve(raw,async({post,poll,core})=>{const job=await post('/api/trade-jobs',{sessionId:core.sessionId,start:T,end:T+M}),r=await poll('/api/trade-jobs',job.id);assert.equal(r.status,'error');assert.match(r.error,/不一致/);assert.equal(r.result,undefined);});
 const slow={load:async(_,{signal})=>new Promise((_,reject)=>signal.addEventListener('abort',()=>reject(signal.reason),{once:true}))};
 await serve(slow,async({post,base,core})=>{const job=await post('/api/trade-jobs',{sessionId:core.sessionId,start:T,end:T+M});assert.equal((await post('/api/trade-jobs',{sessionId:core.sessionId})).status,429);assert.equal((await fetch(base+'/api/trade-jobs/'+job.id,{method:'DELETE'})).status,200);assert.equal((await fetch(base+'/api/jobs/'+core.sessionId)).status,200);});
});
