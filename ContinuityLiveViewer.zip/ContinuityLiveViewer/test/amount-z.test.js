import test from 'node:test';
import assert from 'node:assert/strict';
import {amountZSettings,computeAmountZ} from '../lib/amount-z.js';
import {computeView} from '../lib/metrics.js';
import {parseQuery} from '../lib/binance.js';
import {plan} from '../lib/sessions.js';
const M=60000,D=1440*M,at=Date.UTC(2026,8,15),near=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
function bars(n,period=3){return Array.from({length:n},(_,i)=>({time:at+i*period*M,quote:i%7===0?0:Math.exp(2+(i%31)/10),takerQuote:i%5===0?0:Math.exp(1+(i%19)/10)}));}
test('amount Z matches independent prior-window log population moments for all periods and baseline choices',()=>{
 for(const period of [1,3,5,15,30,60])for(const amountZDays of [3,7,14]){
  const s=amountZSettings({period,amountZDays}),input=bars(s.baselineBars+73,period),out=computeAmountZ(input,s);
  assert.equal(out[s.baselineBars-1].buyZ,null);
  for(const i of [s.baselineBars,s.baselineBars+72])for(const [key,field] of [['buy','takerQuote'],['trade','quote']]){
   const h=input.slice(i-s.baselineBars,i).map(r=>Math.log1p(r[field])),mean=h.reduce((a,b)=>a+b,0)/h.length,std=Math.sqrt(h.reduce((a,b)=>a+(b-mean)**2,0)/h.length);
   near(out[i][key+'Mean'],mean);near(out[i][key+'Std'],std);near(out[i][key+'Z'],(Math.log1p(input[i][field])-mean)/std);
   assert.equal(out[i][key+'Coverage'],1);
  }
 }
});
test('zero and constant histories stay unavailable; zeros are valid observations and positive sample checks are independent',()=>{
 const s={...amountZSettings(),baselineBars:100},input=bars(250),zero=computeAmountZ(input.map(r=>({...r,quote:0,takerQuote:0})),s);
 assert.ok(zero.every(r=>r.buyZ===null&&r.tradeZ===null));assert.equal(zero.at(-1).tradeCoverage,1);
 for(const amount of [.1,1e10]){const out=computeAmountZ(input.map(r=>({...r,quote:amount,takerQuote:amount})),s);assert.equal(out.at(-1).tradeZ,null);assert.equal(out.at(-1).tradeReason,'历史波动不足');}
 const sparse=computeAmountZ(input.map((r,i)=>({...r,takerQuote:i%10===0?100:0})),s);
 assert.equal(sparse.at(-1).buyReason,'历史正额样本不足');assert.notEqual(sparse.at(-1).tradeZ,null);
 const out=computeAmountZ(input,s);assert.ok(out.some((r,i)=>i>=100&&r.tradeAmount===0&&r.tradeZ<0));
});
test('current spike is excluded from baseline, gaps are not zeros, future values cannot change history',()=>{
 const s={...amountZSettings(),baselineBars:100},input=bars(400),original=computeAmountZ(input,s);
 const spike=input.map((r,i)=>i===160?{...r,quote:1e100}:r),out=computeAmountZ(spike,s);
 assert.equal(out[160].tradeMean,original[160].tradeMean);assert.equal(out[160].tradeStd,original[160].tradeStd);assert.ok(out[160].tradeZ>100);
 assert.deepEqual(computeAmountZ(input.slice(0,200),s),original.slice(0,200));
 const missing=input.map((r,i)=>i>=150&&i<=152?{...r,quote:null,takerQuote:null}:r),gaps=computeAmountZ(missing,s);
 assert.equal(gaps[150].tradeZ,null);assert.equal(gaps[153].tradeZ,null);assert.equal(gaps[153].tradeReason,'历史覆盖不足');assert.notEqual(gaps[253].tradeZ,null);
 const one=input.map((r,i)=>i===150?{...r,quote:null}:r),oneOut=computeAmountZ(one,s),h=one.slice(51,151).filter(r=>r.quote!==null).map(r=>Math.log1p(r.quote));
 near(oneOut[151].tradeMean,h.reduce((a,b)=>a+b,0)/99);assert.equal(oneOut[151].tradeCoverage,.99);assert.notEqual(oneOut[151].tradeZ,null);
});
test('amount Z validation and sessions preserve days across period changes and extensions',()=>{
 assert.equal(amountZSettings().baselineDays,7);
 for(const amountZDays of [0,1,5,'7',NaN])assert.throws(()=>amountZSettings({amountZDays}));
 const q=parseQuery({symbol:'BTC',at:new Date(at).toISOString(),amountZDays:14},at+D);
 assert.equal(q.amountZDays,14);assert.ok(q.start-q.historyStart>=14*D);
 const changed=plan({action:'period',period:60,amountZDays:3},{query:q},at+30*D).query;assert.equal(changed.amountZDays,3);
 assert.equal(plan({action:'extend',direction:'after'},{query:changed},at+30*D).query.amountZDays,3);
 assert.throws(()=>parseQuery({symbol:'BTC',at:new Date(at).toISOString(),amountZDays:5},at+D));
 assert.throws(()=>plan({action:'period',amountZDays:5},{query:q},at+D));
});
test('integration uses aggregated candle amounts, prehistory and selected period without changing old series',()=>{
 const start=at-4*D,raw=Array.from({length:4*1440},(_,i)=>({time:start+i*M,open:100,close:100,high:101,low:99,volume:1,quote:i%7===0?0:100+i%23,takerQuote:i%7===0?0:i%11,trades:1}));
 for(const period of [1,3,5,15,30,60]){
  const q={period,amountZDays:3,at:at-D,start:at-D,end:raw.at(-1).time,historyStart:start},a=computeView(raw,q),all=computeView(raw,{...q,start});
  assert.deepEqual(a.amountZ,all.amountZ.filter(r=>r.time>=q.start));assert.equal(a.amountZ.length,a.candles.length);assert.ok(a.amountZ.some(r=>r.buyZ!==null&&r.tradeZ!==null));
  assert.ok(a.amountZ.every((r,i)=>r.time===a.candles[i].time&&r.buyAmount===a.candles[i].takerQuote&&r.tradeAmount===a.candles[i].quote));
  const b=computeView(raw,{...q,amountZDays:7});for(const key of ['candles','scores','states','uw','relativeStrength','buyPressure','bbw'])assert.deepEqual(a[key],b[key]);
 }
});

test('displayed Z percentile matches prior historical Z and integral input before integral warmup',()=>{
 const start=at-30*D,raw=Array.from({length:30*1440},(_,i)=>({time:start+i*M,open:100,close:100,high:101,low:99,quote:i%11===0?0:100+i%31,takerQuote:i%11===0?0:10+i%29,trades:1,volume:1}));
 for(const rankDays of [3,14]){
  const q={period:60,amountZDays:7,volumeRankDays:rankDays,volumeHalfLife:4320,at:at-D,start:at-D,end:raw.at(-1).time,historyStart:start},view=computeView(raw,q),all=computeView(raw,{...q,start}),B=rankDays*24;
  assert.equal(view.metaMetrics.amountZSettings.display,'historical_z_percentile');assert.equal(view.metaMetrics.amountZSettings.rankDays,rankDays);
  for(let i=0;i<view.amountZ.length;i++){
   const r=view.amountZ[i],j=all.amountZ.findIndex(x=>x.time===r.time);
   for(const key of ['buy','trade']){
    const h=all.amountZ.slice(j-B,j).map(x=>x[key+'Z']).filter(Number.isFinite),z=r[key+'Z'],expected=(h.filter(v=>v<z).length+.5*h.filter(v=>v===z).length)/h.length;
    near(r[key+'Percentile'],expected);assert.equal(r[key+'Percentile'],view.volumePersistence[i][key+'Percentile']);assert.equal(r[key+'PercentileReason'],'');
   }
  }
  assert.ok(view.amountZ.some(r=>r.buyPercentile!==null&&r.tradePercentile!==null));assert.ok(view.volumePersistence.every(r=>r.buyScore===null&&r.tradeScore===null));
  const fast=computeView(raw,{...q,volumeHalfLife:60});assert.deepEqual(fast.amountZ,view.amountZ);
 }
});
