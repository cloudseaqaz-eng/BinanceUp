import test from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {computeView} from '../lib/metrics.js';
import {parseQuery} from '../lib/binance.js';
import {plan,availability} from '../lib/sessions.js';
import {createServer} from '../server.js';
const M=60000,D=1440*M,at=Date.UTC(2026,8,15);
function rows(q){return Array.from({length:Math.floor((q.end-q.historyStart)/M)+1},(_,i)=>{const time=q.historyStart+i*M,p=100+(time-at)/D;return {time,open:p,high:p+1,low:p-1,close:p+.5,volume:1,quote:100,trades:1,takerQuote:50};});}
test('all six periods aggregate UTC buckets with correct OHLC totals',()=>{
 const q={at,start:at,end:at+180*M,historyStart:at-1000*M,emaPeriods:[2,3,5]};const input=rows(q);
 for(const period of [1,3,5,15,30,60]){
  const output=computeView(input,{...q,period});assert.equal(output.candles.length,180/period+1);
  for(const c of output.candles){const group=input.filter(r=>r.time>c.time-period*M&&r.time<=c.time);assert.equal(c.time%(period*M),0);assert.equal(c.open,group[0].open);assert.equal(c.close,group.at(-1).close);assert.equal(c.high,Math.max(...group.map(r=>r.high)));assert.equal(c.volume,period);}
 }
 assert.throws(()=>computeView(input,{...q,period:2}));
});
test('score data is independent of selected candle period and larger buckets reset on gaps',()=>{
 const q={at:at+15*D,start:at+14.5*D,end:at+16*D,historyStart:at,scoreMode:'fixed5',emaPeriods:[2,3,5]};const input=rows(q),reference=computeView(input,{...q,period:1});
 for(const period of [3,5,15,30,60])assert.deepEqual(computeView(input,{...q,period}).scores,reference.scores);
 const gap=at+15*D+M,missing=input.filter(r=>r.time!==gap);
 const candles=computeView(missing,{...q,period:60}).candles;
 assert.equal(candles.find(c=>c.time===at+15*D+60*M).close,null);
 assert.equal(candles.find(c=>c.time===at+15*D+120*M).emaFast,null);
 assert.ok(Number.isFinite(candles.find(c=>c.time===at+15*D+180*M).emaFast));
});
test('extension planning fetches only added historical minutes and respects latest close',()=>{
 const query=parseQuery({symbol:'BTC',at:new Date(at).toISOString()},at+30*D),previous={query};
 const earlier=plan({action:'extend',direction:'before'},previous,at+30*D);
 assert.equal(earlier.query.start,query.start-7*D);assert.equal(earlier.load.end,query.historyStart-M);
 assert.equal(earlier.load.end-earlier.load.historyStart+M,7*D);
 const later=plan({action:'extend',direction:'after'},previous,at+8*D+5000);
 assert.equal(later.load.historyStart,query.end+M);assert.equal(later.query.end,at+8*D);
 assert.equal(availability(later.query,at+8*D).after,false);
 assert.throws(()=>plan({action:'extend',direction:'after'},{query:later.query},at+8*D),/最近/);
 assert.throws(()=>plan({action:'period',period:2},previous));assert.throws(()=>plan({action:'period'},null),/过期/);
});
test('HTTP extension and period reuse session, preserve old scores and avoid refetch',async()=>{
 const calls=[];const client={base:'fixture',load:async q=>{calls.push({...q});return rows(q);}};
 const server=createServer({client,now:()=>at+30*D});server.listen(0,'127.0.0.1');await once(server,'listening');const base='http://127.0.0.1:'+server.address().port;
 async function job(body){const r=await fetch(base+'/api/jobs',{method:'POST',body:JSON.stringify(body)});assert.equal(r.status,202);const {id}=await r.json();for(let i=0;i<100;i++){const j=await(await fetch(base+'/api/jobs/'+id)).json();if(j.status==='error')assert.fail(j.error);if(j.status==='done')return j.result;await new Promise(r=>setTimeout(r,10));}assert.fail('timeout');}
 try{
  const initial=await job({symbol:'BTC',at:new Date(at).toISOString(),scoreMode:'fixed5'});assert.equal(calls.length,1);
  const hourly=await job({action:'period',period:60,sessionId:initial.sessionId});assert.equal(calls.length,1);assert.equal(hourly.interval,'1h');assert.deepEqual(hourly.scores,initial.scores);
  const followed=await job({action:'period',scoreMode:'follow',sessionId:hourly.sessionId});assert.equal(calls.length,1);assert.equal(followed.meta.scoreSettings.continuityWindow,60);assert.notDeepEqual(followed.scores,hourly.scores);
  const fixed=await job({action:'period',scoreMode:'fixed5',sessionId:followed.sessionId});assert.deepEqual(fixed.scores,initial.scores);
  const stateChanged=await job({action:'period',sessionId:fixed.sessionId,stateMode:'fixed5',stateWindow:180});assert.equal(calls.length,1);assert.equal(stateChanged.meta.stateSettings.continuityWindow,5);assert.equal(stateChanged.meta.stateSettings.windowMinutes,180);assert.deepEqual(stateChanged.scores,fixed.scores);
  const earlier=await job({action:'extend',direction:'before',sessionId:stateChanged.sessionId});assert.equal(calls.length,2);assert.equal(earlier.start,initial.start-7*D);assert.equal(earlier.period,60);assert.deepEqual(earlier.scores.filter(r=>r.time>=initial.start),initial.scores);
  const later=await job({action:'extend',direction:'after',sessionId:earlier.sessionId});assert.equal(calls.length,3);assert.equal(later.end,initial.end+7*D);assert.deepEqual(later.scores.filter(r=>r.time<=earlier.end),earlier.scores);
 }finally{server.closeAllConnections();await new Promise(r=>server.close(r));}
});
