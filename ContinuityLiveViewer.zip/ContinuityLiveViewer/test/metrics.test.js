import test from 'node:test';
import assert from 'node:assert/strict';
import { computeView, validMinute, MINUTE } from '../lib/metrics.js';

const BASE = Date.parse('2026-08-01T00:00:00Z');
const time = i => BASE + (i + 1) * MINUTE;
function rows(n, value = () => ({})) {
  return Array.from({ length: n }, (_, i) => ({ time: time(i), open: 100, high: 100, low: 100, close: 100,
    volume: 1, quote: 100, trades: 1, takerQuote: 50, ...value(i) }));
}
const options = (n, extra = {}) => ({ at: time(n - 1), start: time(0), end: time(n - 1), historyStart: time(0), scoreMode:'fixed5',scoreDecayDays:7, emaPeriods: [2, 3, 4], ...extra });
function near(a, b, tolerance = 1e-9) { assert.ok(Math.abs(a - b) <= tolerance, `${a} != ${b}`); }
function weight(age) { return age <= 10080 ? 2 ** (-age / 10080) : .5 * 2 ** (-(age - 10080) / 1440); }
function directScore(source, index, field) {
  let numerator = 0, denominator = 0;
  for (let j = 4; j <= index; j++) {
    const recent = source.slice(j - 4, j + 1);
    if (!recent.every(validMinute)) continue;
    const c5 = recent.filter(r => r[field] > 0).length / 5;
    const w = weight(index - j);
    numerator += w * c5; denominator += w;
  }
  return 100 * numerator / denominator;
}

test('three-minute bars use complete closed UTC buckets and sum native volumes', () => {
  const source = rows(13, i => ({ open: 9 + i, high: 12 + i, low: 8 + i, close: 10 + i, volume: i, quote: 100 + i, takerQuote: i }));
  const actual = computeView(source, options(13, { at: time(4) }));
  assert.equal(actual.candles.length, 4);
  assert.deepEqual(actual.candles[0], { time: BASE + 3 * MINUTE, open: 9, high: 14, low: 8, close: 12,
    volume: 3, quote: 303, trades: 3, takerQuote: 3, emaFast: null, emaMid: null, emaSlow: null });
  assert.equal(actual.metaMetrics.anchorPrice, 14);
  assert.equal(actual.candles.at(-1).time, BASE + 12 * MINUTE);
  assert.equal(actual.scores.length, 13);
});

test('EMA is calculated over pre-window history with declared 3-minute periods', () => {
  const source = rows(30, i => ({ open: 100 + i, high: 100 + i, low: 100 + i, close: 100 + i }));
  const all = computeView(source, options(30));
  const cropped = computeView(source, options(30, { start: time(15) }));
  assert.deepEqual(cropped.candles, all.candles.filter(r => r.time >= time(15)));
  let expected = all.candles[0].close;
  for (let i = 1; i < all.candles.length; i++) {
    expected += 2 / 3 * (all.candles[i].close - expected);
    near(all.candles[i].emaFast, expected);
  }
  assert.equal(all.candles[1].emaMid, null);
  assert.ok(all.candles[2].emaMid !== null);
});

test('missing minute creates empty candle and resets EMA warmup', () => {
  const source = rows(21);
  source.splice(7, 1); // 00:08 closed minute missing; entire 00:09 candle unknown.
  const actual = computeView(source, options(21));
  assert.equal(actual.candles[2].close, null);
  assert.equal(actual.candles[3].emaFast, null);
  assert.equal(actual.candles[4].emaFast, 100);
  assert.equal(actual.candles[4].emaMid, null);
  assert.equal(actual.candles[5].emaMid, 100);
  assert.equal(actual.metaMetrics.missingMinutes, 1);
  assert.equal(actual.metaMetrics.loadedMinutes, 20);
});

test('weekly C5 score matches independent age-weighted minute calculation', () => {
  const source = rows(16 * 1440, i => ({ trades: i % 5 === 0 ? 0 : 1, takerQuote: i % 3 === 0 ? 0 : 50 }));
  source[21001] = { ...source[21001], close: NaN };
  const actual = computeView(source, options(source.length));
  assert.equal(actual.scores[20163].tradeScore, null);
  assert.ok(actual.scores[20164].tradeScore !== null); // first C5 at minute index4 +14days.
  for (const index of [20164, 21000, 21008, source.length - 1]) {
    near(actual.scores[index].tradeScore, directScore(source, index, 'trades'), 2e-9);
    near(actual.scores[index].buyScore, directScore(source, index, 'takerQuote'), 2e-9);
  }
  assert.ok(actual.scores.at(-1).buyScore < actual.scores.at(-1).tradeScore);
});

test('unknown current C5 blanks score and recovers after five complete minutes', () => {
  const source = rows(16 * 1440);
  source[21000] = { ...source[21000], trades: -1 };
  const actual = computeView(source, options(source.length));
  assert.equal(actual.scores[20999].tradeScore, 100);
  for (let i = 21000; i <= 21004; i++) assert.equal(actual.scores[i].tradeScore, null);
  near(actual.scores[21005].tradeScore, 100);
  assert.equal(actual.metaMetrics.invalidMinutes, 1);
  assert.equal(actual.metaMetrics.missingMinutes, 1);
});

test('true zero activity contributes zero while historical gaps lower coverage', () => {
  const zero = rows(16 * 1440, () => ({ volume: 0, quote: 0, trades: 0, takerQuote: 0 }));
  const result = computeView(zero, options(zero.length));
  assert.equal(result.scores.at(-1).tradeScore, 0);
  assert.equal(result.scores.at(-1).buyScore, 0);
  const gap = zero.filter((_, i) => i < 18000 || i > 22000);
  const missing = computeView(gap, options(zero.length));
  assert.equal(missing.scores.at(-1).tradeScore, null);
  assert.ok(missing.scores.at(-1).tradeCoverage < .99);
});

test('future extension and mutation cannot alter prior scores EMA or candles', () => {
  const source = rows(16 * 1440, i => ({ trades: i % 7 ? 1 : 0, takerQuote: i % 4 ? 50 : 0 }));
  const cutoff = 21000;
  const past = computeView(source, options(cutoff, { start: time(20500) }));
  const future = source.map((r, i) => i < cutoff ? r : { ...r, high: 200, close: 200, trades: 20, takerQuote: 100 });
  const extended = computeView(future, options(source.length, { at: time(cutoff - 1), start: time(20500) }));
  assert.deepEqual(past.scores, extended.scores.filter(r => r.time <= time(cutoff - 1)));
  assert.deepEqual(past.candles, extended.candles.filter(r => r.time <= time(cutoff - 1)));
  assert.equal(past.metaMetrics.anchorPrice, extended.metaMetrics.anchorPrice);
});

test('28-day API preload gives a conservative tiny omitted-tail error bound', () => {
  const source = rows(30 * 1440);
  const actual = computeView(source, options(source.length, { start: time(28 * 1440) }));
  assert.ok(actual.metaMetrics.scoreErrorBound > 0);
  assert.ok(actual.metaMetrics.scoreErrorBound < .00001);
  near(actual.scores[0].buyScore, 100);
});

test('invalid rows, duplicate timestamps, nonminute times and period settings rejected', () => {
  assert.equal(validMinute({ ...rows(1)[0], low: 101 }), false);
  assert.equal(validMinute({ ...rows(1)[0], takerQuote: 101 }), false);
  assert.equal(validMinute({ ...rows(1)[0], trades: .5 }), false);
  assert.throws(() => computeView([rows(1)[0], rows(1)[0]], options(2)), /重复/);
  assert.throws(() => computeView([{ ...rows(1)[0], time: BASE + 59999 }], options(2)), /整分钟/);
  assert.throws(() => computeView(rows(1), options(1, { emaPeriods: [0, 2, 3] })), /EMA/);
});
