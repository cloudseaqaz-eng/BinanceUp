"""Optional Playwright check using the real Node server and an injected API fixture.

No external exchange requests or downloaded datasets are used. Fixture data is
created only in a temporary test runner and never in the application frontend.
"""
import asyncio,json,subprocess,tempfile,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

async def run(output):
    from playwright.async_api import async_playwright
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    checks=[];errors=[]
    def check(name,value):
        checks.append({'check':name,'passed':bool(value)})
        print(('PASS ' if value else 'FAIL ')+name,flush=True)
    with tempfile.TemporaryDirectory() as tmp:
        runner=Path(tmp)/'fixture.mjs'
        runner.write_text('import {createServer} from '+json.dumps((ROOT/'server.js').as_uri())+''';
const M=60000,DAY=1440*M,at=Date.UTC(2026,8,15),now=at+3*DAY;
const client={base:'isolated synthetic API fixture',endpointFor:m=>m==='futures'?'https://fapi.binance.com/fapi/v1/klines':'https://www.binance.com/api/v3/uiKlines',load:async(q,{signal,onProgress})=>{
  onProgress({completed:0,total:1,message:'isolated fixture loading'});
  if(q.market==='futures'&&q.symbol==='NOFUTUREUSDT')throw Error('币安没有可查询的这个USDT合约');
  if(q.market==='futures'&&q.symbol==='SLOWMARKETUSDT')await new Promise((resolve,reject)=>{const timer=setTimeout(resolve,30000);signal.addEventListener('abort',()=>{clearTimeout(timer);reject(Error('cancelled fixture'));},{once:true});});
  if(q.symbol==='ERRORUSDT')throw Error('fixture API unavailable');
  if(q.symbol==='SLOWUSDT')await new Promise((resolve,reject)=>{const timer=setTimeout(resolve,30000);signal.addEventListener('abort',()=>{clearTimeout(timer);reject(Error('cancelled fixture'));},{once:true});});
  await new Promise(r=>setTimeout(r,100));signal.throwIfAborted();
  const rows=Array.from({length:Math.floor((q.end-q.historyStart)/M)+1},(_,i)=>{
    const time=q.historyStart+i*M,future=q.market==='futures',p=(100+i*.001+Math.sin(i/300)*3)*(future?1.2:1);
    const active=time>q.at-(future?3:2)*DAY||i%(future?7:3)===0,buy=active&&(time>q.at-(future?.5:1)*DAY||i%(future?3:2)===0);
    return {time,open:p-.02,high:time===q.at+DAY?500:p+(i%(future?110:120)<(future?40:50)?0:.05),low:p-(i%150<65?.02:.05),close:p,volume:active?2:0,quote:active?2*p:0,trades:active?2:0,takerQuote:buy?p:0};
  });onProgress({completed:1,total:1,message:'fixture loaded'});return rows;
},loadRecognition:async(q,previous,{signal})=>{signal.throwIfAborted();const step=q.period*60000,start=Math.floor((q.start-73*DAY)/step)*step,end=Math.floor(q.end/step)*step;const rows=Array.from({length:(end-start)/step+1},(_,i)=>{const d=i*step/DAY,j=i*q.period/15,a=Math.exp(10+Math.sin((i*step%DAY)/DAY*2*Math.PI)*.5+Math.sin(j*1.37)*.2+(d>69?-1:0)+(d>75?2:0));return {time:start+i*step,total:a,takerBuy:a*.54,close:100*Math.exp(Math.sin(j/100)*.2),market:Math.exp(12+Math.sin((i*step%DAY)/DAY*2*Math.PI)*.3+Math.cos(j*.77)*.4)}});return {rows,start,end,period:q.period,source:'isolated period-follow fixture',warnings:[]}}};
const server=createServer({client,now:()=>now});server.listen(0,'127.0.0.1',()=>console.log(server.address().port));
process.on('SIGTERM',()=>{server.close();server.closeAllConnections();});
''')
        process=subprocess.Popen(['node',str(runner)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            port=process.stdout.readline().strip()
            if not port.isdigit():raise RuntimeError('Fixture server startup failed: '+process.stderr.read())
            base='http://127.0.0.1:'+port
            async with async_playwright() as pw:
                browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
                page=await browser.new_page(viewport={'width':1500,'height':900},device_scale_factor=1,color_scheme='dark')
                page.on('pageerror',lambda e:errors.append(str(e)))
                requests=[];page.on('request',lambda r:requests.append(r.url))
                external=[];page.on('request',lambda r:external.append(r.url) if not r.url.startswith(base) else None)
                await page.add_init_script("window.drawWidths=[];const width=Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype,'lineWidth');Object.defineProperty(CanvasRenderingContext2D.prototype,'lineWidth',{...width,set(v){window.drawWidths.push({id:this.canvas.id,width:v});width.set.call(this,v)}})")
                await page.add_init_script("window.multiplePatterns=[];const originalDash=CanvasRenderingContext2D.prototype.setLineDash;CanvasRenderingContext2D.prototype.setLineDash=function(pattern){if(pattern.length===2&&pattern[0]===1&&pattern[1]===3)window.multiplePatterns.push({cap:this.lineCap,color:this.strokeStyle});return originalDash.call(this,pattern)}")
                await page.add_init_script("window.chartPalette={light:{},dark:{}};const stroke=CanvasRenderingContext2D.prototype.stroke;CanvasRenderingContext2D.prototype.stroke=function(...args){const t=document.documentElement.dataset.theme==='dark'?'dark':'light',id=this.canvas.id;if(!chartPalette[t][id])chartPalette[t][id]=[];if(!chartPalette[t][id].includes(this.strokeStyle))chartPalette[t][id].push(this.strokeStyle);return stroke.apply(this,args)}")
                await page.goto(base);await page.wait_for_function('() => (document.querySelector("#at").value!=="")')
                await page.locator('#symbol').fill('牛来');await page.locator('#at').fill('2026-09-15T08:00')
                await page.locator('#query').click();await page.wait_for_function('() => (window.liveViewer.data!==null)')
                await page.wait_for_timeout(100)
                check('new visitor defaults to light even with dark OS preference',await page.evaluate('document.documentElement.dataset.theme==="light"&&getComputedStyle(document.documentElement).colorScheme==="light"'))
                check('theme selector starts at light',await page.locator('#theme-select').input_value()=='light')
                check('light panels and inputs are white',await page.evaluate('getComputedStyle(document.querySelector(".chart-card")).backgroundColor==="rgb(255, 255, 255)"&&getComputedStyle(document.querySelector("#symbol")).backgroundColor==="rgb(255, 255, 255)"'))
                await page.evaluate('()=>{window.themeOriginalData=liveViewer.data;window.themeView=[...liveViewer.charts.view];window.originalHeights=[...document.querySelectorAll(".chart-card")].map(e=>e.getBoundingClientRect().height)}')
                jobs_before=len([u for u in requests if u.endswith('/api/jobs')])
                for key in ['price','score','state','uw-three','buy-activity','buy-z','bbw','amount-z','volume','recognition','reexpansion','flow']:
                    await page.locator('#'+key+'-chart').scroll_into_view_if_needed();await page.wait_for_timeout(70)
                    check(key+' uses the light canvas grid',await page.evaluate('(id)=>window.chartPalette.light[id]?.includes("#dce3ec")',key+'-chart'))
                check('flow has histogram plus both line series',await page.locator('#flow-chart').get_attribute('data-series')=='imb,drift,absorb')
                check('flow left axis fixed minus100 to plus100 percent',await page.locator('#flow-chart').evaluate('c=>c.dataset.yMin==="-100"&&c.dataset.yMax==="100"'))
                check('flow right axis remains zero to five',await page.locator('#flow-chart').get_attribute('data-right-max')=='5')
                check('flow legend labels both line axes','对数位移（左）' in await page.locator('.flow-card .legend').inner_text() and '吸收强度（右）' in await page.locator('.flow-card .legend').inner_text())
                check('purple displacement and orange absorption are actually stroked',await page.evaluate('chartPalette.light["flow-chart"].includes("#8050c7")&&chartPalette.light["flow-chart"].includes("#ad6500")'))
                check('small legend and readout text meet light contrast',await page.evaluate('''()=>{const rgb=s=>s.match(/[0-9.]+/g).slice(0,3).map(Number),lum=a=>a.map(x=>{x/=255;return x<=.04045?x/12.92:((x+.055)/1.055)**2.4}).reduce((a,v,i)=>a+v*[.2126,.7152,.0722][i],0);return [...document.querySelectorAll('.legend span,.legend label,.readout')].every(e=>{const c=lum(rgb(getComputedStyle(e).color));return 1.05/(c+.05)>=4.5})}'''))
                for key in ['score','state','uw','strength','buyz','bbw','amountz','volume']:
                    await page.locator('#visible-'+key).uncheck()
                await page.locator('#reexpansion-chart').scroll_into_view_if_needed();await page.screenshot(path=str(output/'light.png'))
                await page.locator('#theme-select').select_option('dark');await page.wait_for_timeout(100)
                check('dark theme can be selected and remembered',await page.evaluate('document.documentElement.dataset.theme==="dark"&&localStorage.getItem("viewer-theme")==="dark"'))
                check('dark controls and panels keep dark colors',await page.evaluate('getComputedStyle(document.querySelector(".chart-card")).backgroundColor==="rgb(18, 33, 49)"&&getComputedStyle(document.querySelector("#symbol")).backgroundColor==="rgb(26, 43, 61)"'))
                for key in ['score','state','uw','strength','buyz','bbw','amountz','volume']:
                    await page.locator('#visible-'+key).check()
                for key in ['price','score','state','uw-three','buy-activity','buy-z','bbw','amount-z','volume','recognition','reexpansion','flow']:
                    await page.locator('#'+key+'-chart').scroll_into_view_if_needed();await page.wait_for_timeout(70)
                    check(key+' redraws with dark grid',await page.evaluate('(id)=>window.chartPalette.dark[id]?.includes("#293c4e")',key+'-chart'))
                check('both fund curves remain visible in dark',await page.evaluate('chartPalette.dark["flow-chart"].includes("#bc95f9")&&chartPalette.dark["flow-chart"].includes("#e08a00")'))
                check('theme switching keeps the same data object',await page.evaluate('liveViewer.data===window.themeOriginalData'))
                check('theme switching keeps time range and heights',await page.evaluate('JSON.stringify(liveViewer.charts.view)===JSON.stringify(window.themeView)&&[...document.querySelectorAll(".chart-card")].every((e,i)=>e.getBoundingClientRect().height===window.originalHeights[i])'))
                check('theme switching sends no new calculation jobs',len([u for u in requests if u.endswith('/api/jobs')])==jobs_before)
                await page.locator('#theme-select').select_option('light');await page.wait_for_timeout(80)
                # A controlled fixture proves units, coordinate mapping and gap boundaries.
                await page.evaluate('''()=>{const rows=liveViewer.data.volumeReexpansion,i=Math.floor(rows.length/2);window.flowTestRows=rows.slice(i,i+3).map(r=>({...r}));window.flowTestIndex=i;Object.assign(rows[i],{imb:.35,drift:.6,absorb:8});Object.assign(rows[i+1],{drift:null,absorb:null});Object.assign(rows[i+2],{drift:-.4,absorb:.75});window.flowTarget=rows[i].time;window.flowDraws=[];const original={};window.flowBuffer=[];for(const n of ['beginPath','moveTo','lineTo','stroke']){original[n]=CanvasRenderingContext2D.prototype[n];CanvasRenderingContext2D.prototype[n]=function(...args){if(this.canvas.id==='flow-chart'){if(n==='beginPath')window.flowBuffer=[];if(n==='moveTo'||n==='lineTo')window.flowBuffer.push({n,x:args[0],y:args[1]});if(n==='stroke'&&['#8050c7','#ad6500'].includes(this.strokeStyle))window.flowDraws.push({color:this.strokeStyle,path:window.flowBuffer.slice()});}return original[n].apply(this,args)}}window.stopFlowCapture=()=>{for(const n in original)CanvasRenderingContext2D.prototype[n]=original[n]};liveViewer.charts.fit();liveViewer.charts.schedule()}''')
                await page.locator('#flow-chart').scroll_into_view_if_needed();await page.wait_for_timeout(100)
                position=await page.evaluate('()=>{const c=liveViewer.charts,g=c.geometry(document.querySelector("#flow-chart"));return {x:g.L+(flowTarget+liveViewer.data.period*60000*.2-c.view[0])/(c.view[1]-c.view[0])*(g.w-g.L-g.R),y:60}}')
                await page.locator('#flow-chart').hover(position=position);await page.wait_for_timeout(100)
                readout=await page.locator('#flow-readout').inner_text()
                check('actual readout retains 35percent imbalance 60percent log drift and 8x absorption','35%' in readout and '60%' in readout and '8×' in readout)
                check('drift maps 0.6 to plus60percent on left fixed axis',await page.evaluate('''()=>{const c=liveViewer.charts,g=c.geometry(document.querySelector('#flow-chart')),x=g.L+(flowTarget-c.view[0])/(c.view[1]-c.view[0])*(g.w-g.L-g.R),y=g.T+.2*(g.h-g.T-g.B);return flowDraws.some(s=>s.color==='#8050c7'&&s.path.some(p=>Math.abs(p.x-x)<.01&&Math.abs(p.y-y)<.01))}'''))
                check('absorption maps actual8x to right5x top',await page.evaluate('''()=>{const c=liveViewer.charts,g=c.geometry(document.querySelector('#flow-chart')),x=g.L+(flowTarget-c.view[0])/(c.view[1]-c.view[0])*(g.w-g.L-g.R);return flowDraws.some(s=>s.color==='#ad6500'&&s.path.some(p=>Math.abs(p.x-x)<.01&&Math.abs(p.y-g.T)<.01))}'''))
                check('both lines restart after a missing sample',await page.evaluate('''()=>{const c=liveViewer.charts,g=c.geometry(document.querySelector('#flow-chart')),x=g.L+(flowTarget+2*liveViewer.data.period*60000-c.view[0])/(c.view[1]-c.view[0])*(g.w-g.L-g.R);return ['#8050c7','#ad6500'].every(color=>flowDraws.some(s=>s.color===color&&s.path.some(p=>p.n==='moveTo'&&Math.abs(p.x-x)<.01)))}'''))
                await page.evaluate('()=>{stopFlowCapture();const rows=liveViewer.data.volumeReexpansion;for(let k=0;k<3;k++)Object.assign(rows[flowTestIndex+k],flowTestRows[k]);liveViewer.charts.schedule()}')
                await page.locator('#flow-chart').hover(position={'x':450,'y':50});before=await page.evaluate('JSON.stringify(liveViewer.charts.view)');await page.mouse.wheel(0,-200);await page.wait_for_timeout(80)
                check('flow zoom remains linked',await page.evaluate('JSON.stringify(liveViewer.charts.view)')!=before)
                await page.locator('#price-chart').scroll_into_view_if_needed();await page.wait_for_timeout(80)
                check('old K-line follows flow zoom',await page.locator('#price-chart').evaluate('c=>Number(c.dataset.timeStart)===liveViewer.charts.view[0]&&Number(c.dataset.timeEnd)===liveViewer.charts.view[1]'))
                for period in [15,60]:
                    await page.locator('#period').select_option(str(period));await page.wait_for_function('(p)=>liveViewer.data.period===p&&!document.querySelector("#query").disabled',arg=period,timeout=90000)
                    await page.locator('#flow-chart').scroll_into_view_if_needed();await page.wait_for_timeout(80)
                    check('fixed flow axes survive '+str(period)+' minute recalculation',await page.locator('#flow-chart').evaluate('c=>c.dataset.yMin==="-100"&&c.dataset.yMax==="100"&&c.dataset.rightMax==="5"'))
                for width in [900,700,1500]:
                    await page.set_viewport_size({'width':width,'height':900});await page.wait_for_timeout(80)
                    check('theme selector stays within header at '+str(width),await page.locator('#theme-select').evaluate('e=>{const r=e.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth}'))
                for key in ['score','state','uw','strength','buyz','bbw','amountz','volume']:
                    await page.locator('#visible-'+key).uncheck()
                await page.locator('#theme-select').select_option('dark');await page.locator('#reexpansion-chart').scroll_into_view_if_needed();await page.wait_for_timeout(100);await page.screenshot(path=str(output/'dark.png'))
                await page.reload();await page.wait_for_function('()=>document.querySelector("#at").value!==""')
                check('dark preference survives reload before new query',await page.locator('#theme-select').input_value()=='dark' and await page.evaluate('document.documentElement.dataset.theme==="dark"'))
                await page.locator('#theme-select').select_option('light');await page.reload();await page.wait_for_function('()=>document.querySelector("#at").value!==""')
                check('light preference survives reload',await page.locator('#theme-select').input_value()=='light')
                await page.evaluate('localStorage.setItem("viewer-theme","invalid")');await page.reload();await page.wait_for_function('()=>document.querySelector("#at").value!==""')
                check('invalid saved preference falls back to light',await page.locator('#theme-select').input_value()=='light')
                blocked=await browser.new_page(viewport={'width':1200,'height':800})
                blocked.on('pageerror',lambda e:errors.append(str(e)))
                await blocked.add_init_script("Storage.prototype.getItem=function(){throw Error('blocked storage')};Storage.prototype.setItem=function(){throw Error('blocked storage')}")
                await blocked.goto(base);await blocked.wait_for_function('()=>document.querySelector("#at").value!==""')
                check('storage unavailable still defaults to light',await blocked.locator('#theme-select').input_value()=='light')
                await blocked.locator('#theme-select').select_option('dark');check('storage unavailable still allows theme switch',await blocked.evaluate('document.documentElement.dataset.theme==="dark"'))
                await blocked.close()
                check('no browser runtime errors',not errors)
                check('fixture only uses local server',not external)
                await browser.close()
        finally:
            process.terminate()
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:process.kill();process.wait()
    (output/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
    if not all(c['passed'] for c in checks):raise SystemExit(1)

if __name__=='__main__':asyncio.run(run(sys.argv[1] if len(sys.argv)>1 else '/tmp/live-viewer-browser'))
