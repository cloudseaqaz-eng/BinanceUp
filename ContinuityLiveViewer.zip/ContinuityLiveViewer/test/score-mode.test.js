import test from 'node:test';
import assert from 'node:assert/strict';
import {computeView,MINUTE as M} from '../lib/metrics.js';
import {parseQuery} from '../lib/binance.js';
import {plan} from '../lib/sessions.js';
const start=Date.UTC(2026,7,1),n=16*1440;
const source=Array.from({length:n},(_,i)=>({time:start+i*M,open:100,high:100,low:100,close:100,volume:1,quote:100,trades:i%3===0?1:0,takerQuote:i%7===0?50:0}));
const opts={at:source.at(-1).time,start:start+15*1440*M,end:source.at(-1).time,historyStart:start};
function reference(window,field,index){let num=0,den=0;for(let i=window-1;i<=index;i++){const age=index-i,w=age<=10080?2**(-age/10080):.5*2**(-(age-10080)/1440);let active=0;for(let j=i-window+1;j<=i;j++)active+=source[j][field]>0;num+=w*active/window;den+=w;}return 100*num/den;}
test('every follow-period score matches independent CN weighted average',()=>{
 for(const period of [1,3,5,15,30,60]){const out=computeView(source,{...opts,period});assert.equal(out.metaMetrics.scoreSettings.continuityWindow,period);assert.equal(out.metaMetrics.scoreSettings.mode,'follow');for(const [k,f] of [['buyScore','takerQuote'],['tradeScore','trades']])assert.ok(Math.abs(out.scores.at(-1)[k]-reference(period,f,n-1))<1e-8);}
});
test('fixed C5 scores and candle series have independent controls',()=>{
 const base=computeView(source,{...opts,period:3,scoreMode:'fixed5'});
 for(const period of [1,5,60])assert.deepEqual(computeView(source,{...opts,period,scoreMode:'fixed5'}).scores,base.scores);
 const followed=computeView(source,{...opts,period:60});assert.notDeepEqual(followed.scores,base.scores);assert.deepEqual(followed.candles,computeView(source,{...opts,period:60,scoreMode:'fixed5'}).candles);
 assert.deepEqual(computeView(source,{...opts,period:5}).scores,base.scores);
});
test('CN gaps stay unknown until full window recovers, no future influence',()=>{
 const gap=n-180,rows=source.filter((_,i)=>i!==gap);const q={...opts,period:60};const out=computeView(rows,q);const byTime=new Map(out.scores.map(r=>[r.time,r]));
 for(let i=gap;i<gap+60;i++)assert.equal(byTime.get(start+i*M).buyScore,null);assert.ok(Number.isFinite(byTime.get(start+(gap+60)*M).buyScore));
 const end=start+(n-120)*M,short=computeView(rows,{...q,end});assert.deepEqual(short.scores,out.scores.filter(r=>r.time<=end));
});
test('API defaults to follow and session mode validation is explicit',()=>{
 const q=parseQuery({symbol:'BTC',at:new Date(opts.at).toISOString()},opts.at+M);assert.equal(q.scoreMode,'follow');
 const changed=plan({action:'period',scoreMode:'fixed5'},{query:q},opts.at+M);assert.equal(changed.query.scoreMode,'fixed5');assert.equal(changed.load,null);
 assert.throws(()=>plan({action:'period',scoreMode:'bad'},{query:q},opts.at+M));assert.throws(()=>computeView(source,{...opts,scoreMode:'bad'}));
});
