import test from 'node:test';
import assert from 'node:assert/strict';
import {BinanceClient,parseQuery} from '../lib/binance.js';
const M=60000,at=Date.UTC(2026,8,15),now=Date.UTC(2026,9,1);
const row=t=>[t,'10','11','9','10','2',t+59999,'20',3,'1','10','0'];
test('query normalizes Unicode and Beijing time, fixed windows and closed future clip',()=>{
 const q=parseQuery({symbol:' 币安人生/USDT ',at:'2026-09-15T08:00:00+08:00'},now);
 assert.equal(q.symbol,'币安人生USDT');assert.equal(q.at,at);assert.equal(q.at-q.start,21*1440*M);assert.equal(q.requestedEnd-q.at,7*1440*M);assert.equal(q.start-q.historyStart,28*1440*M);
 assert.equal(parseQuery({symbol:'T',at:new Date(at).toISOString()},now).symbol,'TUSDT');
 const recent=parseQuery({symbol:'BTC',at:new Date(now-30*M).toISOString()},now+3000);assert.equal(recent.end,now);
 for(const bad of [{symbol:'../BTC'}, {at:'2026-09-15'}, {emaPeriods:[21,9,55]},{at:'2027-01-01T00:00:00Z'}])assert.throws(()=>parseQuery({symbol:'BTC',at:new Date(at).toISOString(),...bad},now));
});
test('pagination requests exact minute boundaries, preserves no-trade zeros and memory cache',async()=>{
 const calls=[];const client=new BinanceClient({spacing:0,fetchImpl:async u=>{
  calls.push(u);const s=Number(u.searchParams.get('startTime')),e=Number(u.searchParams.get('endTime'));return new Response(JSON.stringify(Array.from({length:(e-s)/M+1},(_,i)=>row(s+i*M))));
 }});const query={symbol:'牛来USDT',historyStart:at+M,end:at+2003*M};
 const progress=[];const r=await client.load(query,{onProgress:p=>progress.push(p.completed)});
 assert.equal(calls.length,3);assert.equal(r.length,2003);assert.equal(r[0].time,at+M);assert.equal(r.at(-1).time,query.end);assert.equal(new Set(r.map(x=>x.time)).size,r.length);assert.equal(r[0].takerQuote,10);
 assert.ok(calls.every(u=>u.pathname==='/api/v3/uiKlines'));assert.equal(calls[0].origin,process.env.BINANCE_API_BASE||'https://www.binance.com');assert.ok(calls.every(u=>u.searchParams.get('interval')==='1m'&&u.searchParams.get('limit')==='1000'));
 assert.ok(calls[0].href.includes('%E7%89%9B'));assert.equal(progress.at(-1),3);
 await client.load(query);assert.equal(calls.length,3);
});
test('forbidden and invalid-symbol responses fail explicitly without partial data',async()=>{
 for(const [status,body,pattern] of [[403,'blocked',/拒绝/],[400,JSON.stringify({code:-1121}),/没有这个/]]){
  let calls=0;const client=new BinanceClient({spacing:0,fetchImpl:async()=>{calls++;return new Response(body,{status});}});
  await assert.rejects(client.page('BTCUSDT',at,at,new AbortController().signal),pattern);assert.equal(calls,1);
 }
});
test('aborted query does not fetch and cache is bounded',async()=>{
 const controller=new AbortController();controller.abort();let calls=0;
 const client=new BinanceClient({spacing:0,maxCacheRows:1,fetchImpl:async u=>{calls++;return new Response(JSON.stringify([row(Number(u.searchParams.get('startTime')))]));}});
 await assert.rejects(client.load({symbol:'BTCUSDT',historyStart:at+M,end:at+M},{signal:controller.signal}));assert.equal(calls,0);
 await client.page('BTCUSDT',at,at);await client.page('BTCUSDT',at+M,at+M);assert.equal(client.cacheRows,1);
});
