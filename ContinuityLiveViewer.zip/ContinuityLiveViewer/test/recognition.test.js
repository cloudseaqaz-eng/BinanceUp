import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {detectSustainedVolume,detectReexpansion,recognitionCusum,recognitionDefaults,reexpansionState} from '../lib/recognition-models.mjs';
import * as reference from '../lib/volume-chart-models.mjs';
import {recognitionSettings,computeRecognition} from '../lib/recognition.js';
import {BinanceClient,parseQuery} from '../lib/binance.js';
import {plan} from '../lib/sessions.js';
const STEP=900000,DAY=96*STEP,start=Date.UTC(2026,0,1);
function fixture(days=80){return Array.from({length:days*96},(_,i)=>{
 const day=i/96,total=Math.exp(10+Math.sin(i%96/96*2*Math.PI)*.5+Math.sin(i*1.37)*.2+(day>69?-1:0)+(day>75?2:0));
 return {time:start+i*STEP,total,takerBuy:total*.54,close:100+Math.sin(i*.2)*.01,market:Math.exp(12+Math.sin(i%96/96*2*Math.PI)*.3+Math.cos(i*.77)*.4)};
});}
test('portable model matches the supplied snapshot byte for byte',async()=>{
 const bytes=await readFile(new URL('../lib/volume-chart-models.mjs',import.meta.url));
 assert.equal(createHash('sha256').update(bytes).digest('hex'),'545256e5be244e637f6a09aa6c0e625f9f0ae176ceb718d9d691f8f8f583e52d');
});
test('CUSUM clips evidence, holds through missing samples, records onset and caps',()=>{
 const r=recognitionCusum([-4,2,null,4,100,-100,-100],{...recognitionDefaults,cusumCap:6});
 assert.deepEqual(r.S,[0,1.5,1.5,5,6,1.5,0]);assert.deepEqual(r.start,[-1,1,1,1,1,1,-1]);
});
test('both algorithms are prefix causal including future BTC availability and absent candle slots',()=>{
 const input=fixture(),cut=77*96,missing=input.filter((_,i)=>i<74*96||i>=74*96+8);
 for(const detect of [detectSustainedVolume,detectReexpansion]){
  const options={useMarket:false};const all=detect(missing,options),prefix=detect(missing.filter(r=>r.time<start+cut*STEP),options);
  assert.deepEqual(prefix.rows,all.rows.filter(r=>r.time<start+cut*STEP));
  const future=fixture(42).map((r,i)=>({...r,market:i<38*96?null:r.market}));
  assert.deepEqual(detect(future.slice(0,38*96)).rows,detect(future).rows.slice(0,38*96));
 }
});
test('v2 retains legacy market coverage while v3 requires paired history; flow uses raw money ratios',()=>{
 const input=fixture(),a=detectSustainedVolume(input),b=detectReexpansion(input);
 assert.ok(a.rows.some((r,i)=>r.z!==null&&b.rows[i].z===null));
 const row=b.rows.at(-1);assert.ok(Math.abs(row.imb-.08)<1e-10);assert.ok(Number.isFinite(row.absorb));
 assert.ok(b.rows.some(r=>r.Sdn>0));assert.ok(b.rows.some(r=>r.alert));assert.ok(b.rows.some(r=>r.upgrade));
 assert.ok(b.events.every(e=>b.rows.some(r=>r.time===e.time)));
 const absent=detectReexpansion(fixture(45).map(r=>({...r,total:null,takerBuy:null,close:null,market:null})));
 assert.ok(absent.rows.every(r=>r.z===null&&r.zShort===null&&r.Sdn===0));assert.equal(reexpansionState(absent.rows.at(-1)),'基准预热 / 数据不足');
});
test('parameters are independent, validated and preserved across period/extension requests',()=>{
 const q=parseQuery({symbol:'TEST',at:new Date(start+100*DAY).toISOString(),recognition:{cusumH:15},reexpansion:{shortK:.7}},start+110*DAY);
 assert.equal(q.recognitionSettings.recognition.cusumH,15);assert.equal(q.recognitionSettings.reexpansion.cusumH,12);
 const next=plan({action:'period',period:15,recognition:{useMarket:false}},{query:q},start+110*DAY).query;
 assert.equal(next.recognitionSettings.recognition.useMarket,false);assert.equal(next.recognitionSettings.reexpansion.shortK,.7);assert.equal(next.recognitionSettings.reexpansion.useMarket,true);
 for(const x of [{recognition:{cusumH:'12'}},{recognition:{stepMin:5}},{reexpansion:{upgradeImb:2}},{recognition:{useMarket:1}}])assert.throws(()=>recognitionSettings(x));
});
test('worker preserves exact supplied outputs and prior state when clipping the display',async()=>{
 const rows=fixture(),query={start:start+74*DAY,end:rows.at(-1).time,recognitionSettings:recognitionSettings({recognition:{useMarket:false},reexpansion:{useMarket:false}})};
 const out=await computeRecognition({rows,start,source:'test',warnings:[]},query);
 const v2=reference.detectSustainedVolume(rows,query.recognitionSettings.recognition),v3=reference.detectReexpansion(rows,query.recognitionSettings.reexpansion);
 assert.deepEqual(out.volumeRecognition,v2.rows.filter(r=>r.time>=query.start));assert.deepEqual(out.volumeReexpansion,v3.rows.filter(r=>r.time>=query.start));
 assert.deepEqual(out.recognitionMeta.priorPoint,v2.rows.filter(r=>r.time<query.start).at(-1));
 const abort=new AbortController();const job=computeRecognition({rows,start},query,{signal:abort.signal});abort.abort(Error('cancel-test'));await assert.rejects(job,/cancel-test/);
});
test('native loader requests 15m with BTC, excludes open bars, caches independently and isolates markets',async()=>{
 const calls=[],client=new BinanceClient({proxy:'direct',spacing:0,fetchImpl:async url=>{
  const u=new URL(url),first=Number(u.searchParams.get('startTime')),last=Number(u.searchParams.get('endTime'));calls.push(u);
  const data=[];for(let t=first;t<=last;t+=STEP)data.push([t,'100','101','99','100','2',t+STEP-1,'200',2,'1','110','0']);
  return new Response(JSON.stringify(data),{status:200});}});
 const q=parseQuery({symbol:'TEST',period:15,at:new Date(start+100*DAY+5*60000).toISOString()},start+102*DAY+5*60000);
 const out=await client.loadRecognition(q,null);assert.ok(calls.length>2);assert.ok(calls.every(u=>u.searchParams.get('interval')==='15m'));assert.ok(calls.some(u=>u.searchParams.get('symbol')==='BTCUSDT'));
 assert.ok(out.rows.every(r=>r.time%STEP===0&&r.time<=q.end));assert.equal(out.rows.at(-1).market,200);
 const n=calls.length;await client.loadRecognition(q,out);assert.equal(calls.length,n);
 const btc=await client.loadRecognition({...q,symbol:'BTCUSDT'},null);assert.ok(btc.rows.every(r=>r.market===null));
 await client.loadRecognition({...q,market:'futures'},out);assert.ok(calls.some(u=>u.hostname==='fapi.binance.com'));
});
test('all six periods match the supplied math, including optimized quantiles, paired coverage and missing slots',()=>{
 for(const period of [1,3,5,15,30,60]){
  const per=1440/period,raw=Array.from({length:11*per},(_,i)=>{
   const phase=i*period/15,day=i/per,total=Math.exp(9+Math.sin(2*Math.PI*i/per)*.4+Math.sin(phase*1.13)*.3+(day>5?-.8:0)+(day>8?1.8:0));
   return {time:start+i*period*60000,total:i%397===0?null:total,takerBuy:total*.53,close:100+Math.sin(phase)*.05,market:i<2*per||i%307===0?null:Math.exp(11+Math.cos(phase*.77)*.4)};
  });
  const options={stepMin:period,lagDays:1,baseDays:2,dutyHours:6,floorHours:6,flowHours:6,shortDays:2,shortDutyHours:6,shortFloorHours:6,armDays:1};
  assert.deepEqual(detectSustainedVolume(raw,options),reference.detectSustainedVolume(raw,options),'legacy '+period);
  const actual=detectReexpansion(raw,options);assert.deepEqual(actual,reference.detectReexpansion(raw,options),'v3 '+period);
  assert.ok(actual.rows.some(r=>r.z!==null));assert.ok(actual.rows.some(r=>r.absorb!==null));
 }
});
test('period follows K lines across params, changes and extensions while clock windows remain hours/days',()=>{
 for(const period of [1,3,5,15,30,60]){
  const q=parseQuery({symbol:'TEST',period,at:new Date(start+100*DAY).toISOString()},start+110*DAY);
  for(const action of ['period','extend']){
   const next=plan({action,period,direction:'before'},{query:q},start+110*DAY).query;
   for(const key of ['recognition','reexpansion']){
    assert.equal(next.recognitionSettings[key].stepMin,period);
    assert.equal(next.recognitionSettings[key].flowHours,72);assert.equal(next.recognitionSettings[key].baseDays,28);
   }
   assert.equal(next.recognitionSettings.reexpansion.armDays,5);
  }
 }
});
test('native client follows interval and excludes caches from other periods for coin and BTC',async()=>{
 const calls=[],client=new BinanceClient({proxy:'direct',spacing:0,fetchImpl:async url=>{
  const u=new URL(url),interval=u.searchParams.get('interval'),step=(interval==='1h'?60:Number.parseInt(interval))*60000;
  calls.push({symbol:u.searchParams.get('symbol'),interval});
  const data=[];for(let t=Number(u.searchParams.get('startTime'));t<=Number(u.searchParams.get('endTime'));t+=step)data.push([t,'100','101','99','100','2',t+step-1,'200',2,'1','110','0']);
  return new Response(JSON.stringify(data));
 }});
 let previous=null;
 for(const period of [15,1,3,5,30,60]){
  const q=parseQuery({symbol:'TEST',period,at:new Date(start+100*DAY+7*60000).toISOString()},start+102*DAY+7*60000),before=calls.length;
  const out=await client.loadRecognition(q,previous),expected=period===60?'1h':period+'m';
  assert.ok(calls.slice(before).every(c=>c.interval===expected));assert.ok(calls.slice(before).some(c=>c.symbol==='TESTUSDT'));assert.ok(calls.slice(before).some(c=>c.symbol==='BTCUSDT'));
  assert.equal(out.period,period);assert.ok(out.source.includes('interval='+expected));assert.ok(out.rows.every(r=>r.time%(period*60000)===0&&r.time<=q.end));
  assert.equal(out.rows[1].time-out.rows[0].time,period*60000);
  const n=calls.length;await client.loadRecognition(q,out);assert.equal(calls.length,n);previous=out;
 }
});
