import test from 'node:test';
import assert from 'node:assert/strict';
import {computeRelativeStrength,strengthSettings} from '../lib/relative-strength.js';
import {computeView} from '../lib/metrics.js';
const M=60000;
const rows=n=>Array.from({length:n},(_,i)=>({time:i*M,quote:i%53===0?null:(i%31)*7,takerQuote:i%53===0?null:(i%17)*3}));
function reference(input,s,field){let ema=null;const sums=input.map((_,i)=>{const a=input.slice(Math.max(0,i-s.windowMinutes+1),i+1);return a.length===s.windowMinutes&&a.every(r=>Number.isFinite(r[field]))?a.reduce((a,r)=>a+r[field],0):null;});return sums.map((v,i)=>{const history=sums.slice(Math.max(0,i-s.windowMinutes-s.baselineMinutes+1),i-s.windowMinutes+1).filter(x=>x!==null);let rank=null,median=null;if(i>=s.baselineMinutes+2*s.windowMinutes-2&&history.length>=Math.ceil(s.baselineMinutes*s.minimumCoverage)){history.sort((a,b)=>a-b);const n=history.length;median=n%2?history[(n-1)/2]:(history[n/2-1]+history[n/2])/2;if(v!==null)rank=100*(history.filter(x=>x<v).length+.5*history.filter(x=>x===v).length)/n;}ema=rank===null?null:ema===null?rank:ema+s.alpha*(rank-ema);return {rank,median,ema};});}
test('ranks ties medians and EMA match independent rolling reference',()=>{
 for(const W of [3,5,15,30,60])for(const H of [15,30,60,240,1440]){
  const s={...strengthSettings({strengthWindow:W,strengthHalfLife:H}),baselineMinutes:80,minimumCoverage:.6},input=rows(500),out=computeRelativeStrength(input,s);
  for(const [field,key] of [['quote','trade'],['takerQuote','buy']]){const expected=reference(input,s,field);out.forEach((r,i)=>{assert.equal(r[key+'Percentile'],expected[i].rank);assert.equal(r[key+'Median'],expected[i].median);assert.equal(r[key+'Strength'],expected[i].ema);});}
 }
});
test('constant and zero histories use midrank, zero median gives no invented multiple',()=>{
 const s={...strengthSettings(),baselineMinutes:50},input=Array.from({length:160},(_,i)=>({time:i*M,quote:10,takerQuote:0})),out=computeRelativeStrength(input,s).at(-1);
 assert.equal(out.tradeStrength,50);assert.equal(out.buyStrength,50);assert.equal(out.buyMedian,0);assert.equal(out.buyMultiple,null);assert.equal(out.tradeMultiple,1);
});
test('strictly prior baseline excludes all current minutes and future changes do not leak',()=>{
 const s={...strengthSettings({strengthWindow:15}),baselineMinutes:50},input=Array.from({length:150},(_,i)=>({time:i*M,quote:i<130?1:100,takerQuote:i<130?1:100})),all=computeRelativeStrength(input,s);
 assert.equal(all[144].tradeMedian,15);assert.equal(all[144].tradePercentile,100);
 assert.deepEqual(computeRelativeStrength(input.slice(0,145),s),all.slice(0,145));
 const altered=input.map((r,i)=>i>=145?{...r,quote:1e10,takerQuote:0}:r);assert.deepEqual(computeRelativeStrength(altered,s).slice(0,145),all.slice(0,145));
});
test('missing current minutes blank and reset smoothing; scaled coins have identical scores',()=>{
 const s={...strengthSettings({strengthWindow:15}),baselineMinutes:100},input=Array.from({length:350},(_,i)=>({time:i*M,quote:i%23,takerQuote:i%19}));
 const a=computeRelativeStrength(input,s),b=computeRelativeStrength(input.map(r=>({...r,quote:r.quote*100,takerQuote:r.takerQuote*10})),s);
 a.forEach((r,i)=>{assert.equal(r.buyStrength,b[i].buyStrength);assert.equal(r.tradeStrength,b[i].tradeStrength);});
 input[200]={time:200*M,quote:null,takerQuote:null};const gap=computeRelativeStrength(input,s);for(let i=200;i<215;i++)assert.equal(gap[i].buyStrength,null);
 assert.equal(gap[199].buyStrength,a[199].buyStrength);
});
test('integration is independent of candle period, uses seven days and validates settings',()=>{
 const input=Array.from({length:11000},(_,i)=>({time:i*M,open:10,high:10,low:10,close:10,volume:1,quote:i%31,takerQuote:i%31/2,trades:1})),q={at:10999*M,start:10500*M,end:10999*M,historyStart:0};
 const base=computeView(input,{...q,period:3});assert.ok(base.relativeStrength.some(r=>r.buyStrength!==null));assert.equal(base.metaMetrics.strengthSettings.baselineMinutes,10080);
 for(const period of [1,5,15,30,60])assert.deepEqual(computeView(input,{...q,period}).relativeStrength,base.relativeStrength);
 assert.throws(()=>strengthSettings({strengthWindow:2}));assert.throws(()=>strengthSettings({strengthHalfLife:10}));
});
