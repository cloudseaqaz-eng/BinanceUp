import test from 'node:test';
import assert from 'node:assert/strict';
import {computeRelativeStrength,strengthSettings} from '../lib/relative-strength.js';
import {computeView} from '../lib/metrics.js';
const M=60000;
const rows=n=>Array.from({length:n},(_,i)=>({time:i*M,quote:i%53===0?null:(i%31)*7,takerQuote:i%53===0?null:(i%17)*3}));
function reference(input,s,field){let ema=null;const sums=input.map((_,i)=>{const a=input.slice(Math.max(0,i-s.windowMinutes+1),i+1);return a.length===s.windowMinutes&&a.every(r=>Number.isFinite(r[field]))?a.reduce((a,r)=>a+r[field],0):null;});return sums.map((v,i)=>{const history=sums.slice(Math.max(0,i-s.windowMinutes-s.baselineMinutes+1),i-s.windowMinutes+1).filter(x=>x!==null);let rank=null,median=null;if(i>=s.baselineMinutes+2*s.windowMinutes-2&&history.length>=Math.ceil(s.baselineMinutes*s.minimumCoverage)){history.sort((a,b)=>a-b);const n=history.length;median=n%2?history[(n-1)/2]:(history[n/2-1]+history[n/2])/2;if(v!==null)rank=100*(history.filter(x=>x<v).length+.5*history.filter(x=>x===v).length)/n;}ema=rank===null?null:ema===null?rank:ema+s.alpha*(rank-ema);return {rank,median,ema};});}
test('ranks ties medians and EMA match independent rolling reference',()=>{
 for(const W of [3,5,15,30,60])for(const H of [15,30,60,240,1440]){
  const s={...strengthSettings({strengthWindow:W,strengthHalfLife:H}),baselineMinutes:80,minimumCoverage:.6},input=rows(500),out=computeRelativeStrength(input,s);
  for(const [field,key] of [['quote','trade'],['takerQuote','buy']]){const expected=reference(input,s,field);out.forEach((r,i)=>{assert.equal(r[key+'Percentile'],expected[i].rank);assert.equal(r[key+'Median'],expected[i].median);assert.equal(r[key+'Strength'],expected[i].ema);});}
 }
});
test('constant and zero histories use midrank, zero median gives no invented multiple',()=>{
 const s={...strengthSettings(),baselineMinutes:50},input=Array.from({length:160},(_,i)=>({time:i*M,quote:10,takerQuote:0})),out=computeRelativeStrength(input,s).at(-1);
 assert.equal(out.tradeStrength,50);assert.equal(out.buyStrength,50);assert.equal(out.buyMedian,0);assert.equal(out.buyMultiple,null);assert.equal(out.tradeMultiple,1);
});
test('strictly prior baseline excludes all current minutes and future changes do not leak',()=>{
 const s={...strengthSettings({strengthWindow:15}),baselineMinutes:50},input=Array.from({length:150},(_,i)=>({time:i*M,quote:i<130?1:100,takerQuote:i<130?1:100})),all=computeRelativeStrength(input,s);
 assert.equal(all[144].tradeMedian,15);assert.equal(all[144].tradePercentile,100);
 assert.deepEqual(computeRelativeStrength(input.slice(0,145),s),all.slice(0,145));
 const altered=input.map((r,i)=>i>=145?{...r,quote:1e10,takerQuote:0}:r);assert.deepEqual(computeRelativeStrength(altered,s).slice(0,145),all.slice(0,145));
});
test('missing current minutes blank and reset smoothing; scaled coins have identical scores',()=>{
 const s={...strengthSettings({strengthWindow:15}),baselineMinutes:100},input=Array.from({length:350},(_,i)=>({time:i*M,quote:i%23,takerQuote:i%19}));
 const a=computeRelativeStrength(input,s),b=computeRelativeStrength(input.map(r=>({...r,quote:r.quote*100,takerQuote:r.takerQuote*10})),s);
 a.forEach((r,i)=>{assert.equal(r.buyStrength,b[i].buyStrength);assert.equal(r.tradeStrength,b[i].tradeStrength);});
 input[200]={time:200*M,quote:null,takerQuote:null};const gap=computeRelativeStrength(input,s);for(let i=200;i<215;i++)assert.equal(gap[i].buyStrength,null);
 assert.equal(gap[199].buyStrength,a[199].buyStrength);
});
test('integration is independent of candle period, uses seven days and validates settings',()=>{
 const input=Array.from({length:11000},(_,i)=>({time:i*M,open:10,high:10,low:10,close:10,volume:1,quote:i%31,takerQuote:i%31/2,trades:1})),q={at:10999*M,start:10500*M,end:10999*M,historyStart:0};
 const base=computeView(input,{...q,period:3});assert.ok(base.relativeStrength.some(r=>r.buyStrength!==null));assert.equal(base.metaMetrics.strengthSettings.baselineMinutes,10080);
 for(const period of [1,5,15,30,60])assert.deepEqual(computeView(input,{...q,period}).relativeStrength,base.relativeStrength);
 assert.throws(()=>strengthSettings({strengthWindow:2}));assert.throws(()=>strengthSettings({strengthHalfLife:10}));
});
test('new defaults and multiple EMA use identical causal half-life with no zero-median interpolation',()=>{
 assert.equal(strengthSettings().windowMinutes,3);assert.equal(strengthSettings().halfLifeMinutes,1440);
 for(const halfLife of [15,1440]){
  const settings={...strengthSettings({strengthWindow:3,strengthHalfLife:halfLife}),baselineMinutes:60};
  const input=Array.from({length:300},(_,i)=>({time:i*M,quote:i===180?null:i<100?0:i%17+1,takerQuote:i===180?null:i<100?0:i%11+1}));
  const out=computeRelativeStrength(input,settings);
  for(const key of ['buy','trade']){let expected=null;for(const r of out){const value=r[key+'Multiple'];expected=value===null?null:expected===null?value:expected+settings.alpha*(value-expected);assert.equal(r[key+'MultipleEMA'],expected);if(r[key+'PositiveMedian']===null)assert.equal(r[key+'MultipleEMA'],null);}}
  assert.equal(out[180].buyMultipleEMA,null);assert.deepEqual(computeRelativeStrength(input.slice(0,200),settings),out.slice(0,200));
 }
});
test('zero windows stay exactly zero after decimal trades, with no phantom median or enormous multiple',()=>{
 const settings=strengthSettings();
 const input=Array.from({length:12000},(_,i)=>({time:i*M,quote:1,takerQuote:i===0?.1:i===1?.2:i===11000?1:0}));
 const out=computeRelativeStrength(input,settings);
 assert.equal(out[4].buyAmount,0);assert.equal(out[10090].buyMedian,0);
 assert.equal(out[11000].buyMedian,0);assert.equal(out[11000].buyMultiple,null);assert.equal(out[11000].buyMultipleEMA,null);
 assert.equal(out[11000].buyPositiveMedian,null);
 assert.equal(out[11010].buyAmount,0);
});
test('window sums depend only on current amounts, preserve tiny real trades and reset on missing data',()=>{
 for(const W of [3,5,15,30,60]){
  const settings={...strengthSettings({strengthWindow:W}),baselineMinutes:80};
  const input=Array.from({length:600},(_,i)=>({time:i*M,quote:i%47===0?1e12:i%13===0?1e-8:0,takerQuote:i%31===0?.2:i%17===0?.1:0}));
  const out=computeRelativeStrength(input,settings);
  for(let i=W-1;i<input.length;i++){
   const recent=input.slice(i-W+1,i+1);
   if(recent.every(r=>r.takerQuote===0))assert.equal(out[i].buyAmount,0);
   if(recent.every(r=>r.quote<=1e-8)&&recent.some(r=>r.quote===1e-8))assert.ok(out[i].tradeAmount>0&&out[i].tradeAmount<1e-5);
  }
  const mutated=input.map((r,i)=>i<300?{...r,quote:1e16,takerQuote:1e16}:r);
  const changed=computeRelativeStrength(mutated,settings);
  for(let i=300+W;i<input.length;i++){assert.equal(out[i].tradeAmount,changed[i].tradeAmount);assert.equal(out[i].buyAmount,changed[i].buyAmount);}
 }
});
test('positive-window median prevents zero-baseline dropouts without removing zeros from percentiles',()=>{
 const settings={...strengthSettings(),baselineMinutes:100},input=Array.from({length:500},(_,i)=>({time:i*M,quote:i%20===0?10:0,takerQuote:i%20===0?4:0}));
 const result=computeRelativeStrength(input,settings);
 for(let i=110;i<result.length;i++){
  const r=result[i];assert.equal(r.buyMedian,0);assert.equal(r.buyPositiveMedian,4);assert.equal(r.tradePositiveMedian,10);
  assert.ok(Number.isFinite(r.buyMultipleEMA));assert.ok(r.buyMultiple>=0&&r.buyMultiple<=1);
  assert.ok(r.buyMultipleEMA>=0&&r.buyMultipleEMA<=1);
  assert.equal(r.buyPercentile,r.buyAmount===0?42.5:92.5);
 }
});
test('positive baseline matches independent samples through sparse-to-dense transitions and never uses future data',()=>{
 const s={...strengthSettings({strengthHalfLife:15}),baselineMinutes:100};
 const input=Array.from({length:450},(_,i)=>({time:i*M,quote:i%17===0?20:0,takerQuote:i%17===0||i>240?5+(i%4):0})),out=computeRelativeStrength(input,s);
 let ema=null;
 for(let i=0;i<input.length;i++){
  let expected=null;
  if(i>=100+2*3-2){const positive=[];for(let j=i-3-100+1;j<=i-3;j++){const v=input.slice(j-2,j+1).reduce((a,r)=>a+r.takerQuote,0);if(v>0)positive.push(v);}positive.sort((a,b)=>a-b);const n=positive.length;if(n)expected=n%2?positive[(n-1)/2]:(positive[n/2-1]+positive[n/2])/2;}
  assert.equal(out[i].buyPositiveMedian,expected);
  const ratio=expected===null?null:out[i].buyAmount/expected;
  ema=ratio===null?null:ema===null?ratio:ema+s.alpha*(ratio-ema);
  assert.equal(out[i].buyMultiple,ratio);assert.equal(out[i].buyMultipleEMA,ema);
 }
 assert.deepEqual(computeRelativeStrength(input.slice(0,300),s),out.slice(0,300));
});
