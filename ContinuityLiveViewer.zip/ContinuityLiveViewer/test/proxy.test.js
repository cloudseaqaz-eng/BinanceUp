import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import https from 'node:https';
import net from 'node:net';
import {readFile} from 'node:fs/promises';
import {once} from 'node:events';
import {createProxyFetch} from '../lib/proxy-fetch.js';
const listen=async server=>{server.listen(0,'127.0.0.1');await once(server,'listening');return server.address().port;};
const close=server=>new Promise(r=>{server.closeAllConnections?.();server.close(r);});
test('HTTP CONNECT proxy transports HTTPS response, preserves errors and validates certificates',async()=>{
 const ca=await readFile(new URL('./fixtures/proxy-test-cert.pem',import.meta.url)),key=await readFile(new URL('./fixtures/proxy-test-key.pem',import.meta.url));
 const paths=[],connections=[],sockets=new Set();
 const origin=https.createServer({cert:ca,key},(req,res)=>{paths.push(req.url);res.writeHead(429,{'retry-after':'12','content-type':'application/json'});res.end(JSON.stringify({throughProxy:true}));});
 const originPort=await listen(origin);
 const proxy=http.createServer();proxy.on('connect',(req,client,head)=>{
  connections.push(req.url);sockets.add(client);client.on('close',()=>sockets.delete(client));
  const upstream=net.connect(originPort,'127.0.0.1',()=>{client.write('HTTP/1.1 200 Connection Established\r\n\r\n');if(head.length)upstream.write(head);client.pipe(upstream);upstream.pipe(client);});
  upstream.on('error',()=>client.destroy());client.on('error',()=>upstream.destroy());client.on('close',()=>upstream.destroy());
 });
 const proxyPort=await listen(proxy),address='http://127.0.0.1:'+proxyPort,target='https://localhost:'+originPort+'/api/v3/uiKlines?symbol=AMPUSDT';
 try{
  const response=await createProxyFetch(address,{ca})(target,{signal:AbortSignal.timeout(3000)});
  assert.equal(response.status,429);assert.equal(response.headers.get('retry-after'),'12');assert.deepEqual(await response.json(),{throughProxy:true});
  assert.deepEqual(paths,['/api/v3/uiKlines?symbol=AMPUSDT']);assert.equal(connections[0],'localhost:'+originPort);
  await assert.rejects(createProxyFetch(address)(target,{signal:AbortSignal.timeout(3000)}),/self.signed|certificate/i);
 }finally{for(const s of sockets)s.destroy();await close(proxy);await close(origin);}
});
test('proxy errors are explicit and cancellation interrupts stalled CONNECT',async()=>{
 const sockets=new Set(),proxy=http.createServer();let mode='deny';proxy.on('connect',(req,socket)=>{sockets.add(socket);socket.on('close',()=>sockets.delete(socket));if(mode==='deny')socket.end('HTTP/1.1 502 Bad Gateway\r\n\r\n');});
 const port=await listen(proxy),fetcher=createProxyFetch('http://127.0.0.1:'+port);
 try{
  await assert.rejects(fetcher('https://www.binance.com/api/v3/uiKlines',{signal:AbortSignal.timeout(1000)}),/502/);
  mode='stall';await assert.rejects(fetcher('https://www.binance.com/',{signal:AbortSignal.timeout(40)}));
  const c=new AbortController();c.abort(Error('test cancel'));await assert.rejects(fetcher('https://www.binance.com/',{signal:c.signal}),/test cancel/);
 }finally{for(const s of sockets)s.destroy();await close(proxy);}
 await assert.rejects(fetcher('https://www.binance.com/',{signal:AbortSignal.timeout(1000)}),/无法连接代理.*ECONNREFUSED/);
 assert.throws(()=>createProxyFetch('socks5://127.0.0.1:7890'),/HTTP/);
});
