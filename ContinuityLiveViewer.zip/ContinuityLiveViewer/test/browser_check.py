"""Optional Playwright check using the real Node server and an injected API fixture.

No external exchange requests or downloaded datasets are used. Fixture data is
created only in a temporary test runner and never in the application frontend.
"""
import asyncio,json,subprocess,tempfile,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

async def run(output):
    from playwright.async_api import async_playwright
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    checks=[];errors=[]
    def check(name,value):
        checks.append({'check':name,'passed':bool(value)})
        print(('PASS ' if value else 'FAIL ')+name,flush=True)
    with tempfile.TemporaryDirectory() as tmp:
        runner=Path(tmp)/'fixture.mjs'
        runner.write_text('import {createServer} from '+json.dumps((ROOT/'server.js').as_uri())+''';
const M=60000,DAY=1440*M,at=Date.UTC(2026,8,15),now=at+3*DAY;
const client={base:'isolated synthetic API fixture',load:async(q,{signal,onProgress})=>{
  onProgress({completed:0,total:1,message:'isolated fixture loading'});
  if(q.symbol==='ERRORUSDT')throw Error('fixture API unavailable');
  if(q.symbol==='SLOWUSDT')await new Promise((resolve,reject)=>{const timer=setTimeout(resolve,30000);signal.addEventListener('abort',()=>{clearTimeout(timer);reject(Error('cancelled fixture'));},{once:true});});
  await new Promise(r=>setTimeout(r,100));signal.throwIfAborted();
  const rows=Array.from({length:Math.floor((q.end-q.historyStart)/M)+1},(_,i)=>{
    const time=q.historyStart+i*M,p=100+i*.001+Math.sin(i/300)*3;
    const active=time>q.at-2*DAY||i%3===0,buy=active&&(time>q.at-DAY||i%2===0);
    return {time,open:p-.02,high:time===q.at+DAY?500:p+(i%120<50?0:.05),low:p-(i%150<65?.02:.05),close:p,volume:active?2:0,quote:active?2*p:0,trades:active?2:0,takerQuote:buy?p:0};
  });onProgress({completed:1,total:1,message:'fixture loaded'});return rows;
}};
const server=createServer({client,now:()=>now});server.listen(0,'127.0.0.1',()=>console.log(server.address().port));
process.on('SIGTERM',()=>{server.close();server.closeAllConnections();});
''')
        process=subprocess.Popen(['node',str(runner)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            port=process.stdout.readline().strip()
            if not port.isdigit():raise RuntimeError('Fixture server startup failed: '+process.stderr.read())
            base='http://127.0.0.1:'+port
            async with async_playwright() as pw:
                browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
                page=await browser.new_page(viewport={'width':1500,'height':900},device_scale_factor=1)
                page.on('pageerror',lambda e:errors.append(str(e)))
                requests=[];page.on('request',lambda r:requests.append(r.url))
                external=[];page.on('request',lambda r:external.append(r.url) if not r.url.startswith(base) else None)
                await page.add_init_script("window.drawWidths=[];const width=Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype,'lineWidth');Object.defineProperty(CanvasRenderingContext2D.prototype,'lineWidth',{...width,set(v){window.drawWidths.push(v);width.set.call(this,v)}})")
                await page.add_init_script("window.multiplePatterns=[];const originalDash=CanvasRenderingContext2D.prototype.setLineDash;CanvasRenderingContext2D.prototype.setLineDash=function(pattern){if(pattern.length===2&&pattern[0]===1&&pattern[1]===3)window.multiplePatterns.push({cap:this.lineCap,color:this.strokeStyle});return originalDash.call(this,pattern)}")
                await page.goto(base);await page.wait_for_function('() => (document.querySelector("#at").value!=="")')
                await page.locator('#symbol').fill('牛来');await page.locator('#at').fill('2026-09-15T08:00')
                await page.locator('#query').click();await page.wait_for_function('() => (window.liveViewer.data!==null)')
                await page.wait_for_timeout(100)
                check('decay and state selectors share row',await page.evaluate('Math.abs(document.querySelector("#score-decay").getBoundingClientRect().top-document.querySelector("#state-window").getBoundingClientRect().top)<1'))
                check('strength selectors share row',await page.evaluate('Math.abs(document.querySelector("#strength-window").getBoundingClientRect().top-document.querySelector("#strength-half-life").getBoundingClientRect().top)<1'))
                await page.evaluate('window.visibilityData=liveViewer.data;window.visibilityView=JSON.stringify(liveViewer.charts.view);window.priceHeight=document.querySelector(".price-card").getBoundingClientRect().height;window.originalHeights=Object.fromEntries([...document.querySelectorAll(".chart-card")].map(e=>[e.className,e.getBoundingClientRect().height]))')
                for key,selector in [('score','.score-card'),('state','.state-card'),('uw','.uw-card'),('strength','.buy-activity-card')]:
                    await page.locator('#visible-'+key).uncheck();await page.wait_for_timeout(50)
                    check('hide '+key+' card',not await page.locator(selector).is_visible())
                    check('remaining card heights stay fixed after hiding '+key,await page.evaluate('[...document.querySelectorAll(".chart-card:not([hidden])")].every(e=>Math.abs(e.getBoundingClientRect().height-window.originalHeights[e.className])<1)'))
                    check('remaining cards close gaps after hiding '+key,await page.evaluate('(()=>{const a=[...document.querySelectorAll(".chart-card:not([hidden])")];return a.every((e,i)=>i===0||Math.abs(e.getBoundingClientRect().top-a[i-1].getBoundingClientRect().bottom-10)<1)})()'))
                check('only K-line remains at original height',await page.locator('#price-chart').is_visible() and not await page.locator('#uw-screen').is_visible() and await page.evaluate('document.querySelector(".price-card").getBoundingClientRect().height===window.priceHeight'))
                check('visibility changes preserve data and time view',await page.evaluate('liveViewer.data===window.visibilityData&&JSON.stringify(liveViewer.charts.view)===window.visibilityView'))
                for key in ['score','state','uw','strength']:
                    await page.locator('#visible-'+key).check();await page.wait_for_timeout(40)
                    check('restored '+key+' keeps original card heights',await page.evaluate('[...document.querySelectorAll(".chart-card:not([hidden])")].every(e=>Math.abs(e.getBoundingClientRect().height-window.originalHeights[e.className])<1)'))
                await page.wait_for_timeout(80)
                check('actual Node job completes with Chinese symbol and Beijing timestamp',await page.evaluate('liveViewer.data.symbol==="牛来USDT"&&liveViewer.data.at===Date.UTC(2026,8,15)'))
                check('two charts fit on one desktop screen',await page.locator('#score-chart').evaluate('c=>c.getBoundingClientRect().bottom<=innerHeight') and await page.locator('#price-chart').evaluate('c=>c.getBoundingClientRect().top>0'))
                check('three charts fit inside the desktop viewport',await page.locator('#state-chart').evaluate('c=>c.getBoundingClientRect().bottom<=innerHeight&&c.getBoundingClientRect().height>70'))
                check('state defaults to C3 and six hour trailing occupancy',await page.evaluate('liveViewer.data.meta.stateSettings.continuityWindow===3&&liveViewer.data.meta.stateSettings.windowMinutes===360&&liveViewer.data.states.some(r=>r.buyHigh!==null)'))
                await page.locator('#state-chart').hover(position={'x':500,'y':50})
                check('state hover shows three percentages and common cursor','异常买入高档' in await page.locator('#tooltip').inner_text() and '异常买入低档' in await page.locator('#tooltip').inner_text())
                for value in ['180','720','1440','360']:
                    await page.locator('#state-window').select_option(value)
                    await page.wait_for_function('(v)=>liveViewer.data.meta.stateSettings.windowMinutes===v&&!document.querySelector("#query").disabled',arg=int(value))
                    check('state window '+value+' applies',str(int(value)//60)+'小时' in await page.locator('#state-title').inner_text())
                await page.evaluate('window.centerBeforeDrag=liveViewer.charts.center;window.spanBeforeDrag=liveViewer.charts.span;window.timeBeforeDrag=JSON.stringify(liveViewer.charts.view)')
                drag_rect=await page.locator('#price-chart').bounding_box()
                px=drag_rect['x']+drag_rect['width']*.5;py=drag_rect['y']+drag_rect['height']*.45
                await page.mouse.move(px,py);await page.mouse.down();await page.mouse.move(px,py+35);await page.mouse.up();await page.wait_for_timeout(60)
                check('dragging inside candle plot vertically pans centre with fixed span and times',await page.evaluate('liveViewer.charts.center>window.centerBeforeDrag&&liveViewer.charts.span===window.spanBeforeDrag&&JSON.stringify(liveViewer.charts.view)===window.timeBeforeDrag'))
                await page.locator('#anchor').click()
                check('UW comparison is placed below the first screen',await page.locator('.uw-card').evaluate('e=>e.getBoundingClientRect().top>=innerHeight-1'))
                check('upper UW follows selected-period candles and remains inside zero to one',await page.evaluate('liveViewer.data.uw.length===liveViewer.data.candles.length&&liveViewer.data.uw.every((r,i)=>r.time===liveViewer.data.candles[i].time)&&liveViewer.data.uw.some(r=>r.zeroRate!==null)&&liveViewer.data.uw.every(r=>r.zeroRate===null||r.zeroRate>=0&&r.zeroRate<=1)'))
                check('upper UW fixture contains both zero and nonzero states',await page.evaluate('liveViewer.data.uw.some(r=>r.zeroInput===1)&&liveViewer.data.uw.some(r=>r.zeroInput===0)'))
                check('UW metadata uses only upper shadows of three selected candles',await page.evaluate('liveViewer.data.meta.uwSettings.wickBars===3&&liveViewer.data.meta.uwSettings.shadow==="upper"&&liveViewer.data.uw.some(r=>r.uw3>0)'))
                await page.evaluate('window.firstScreenCore=JSON.stringify([liveViewer.data.candles,liveViewer.data.scores,liveViewer.data.states]);window.firstView=[...liveViewer.charts.view]')
                await page.locator('#go-uw').click();await page.wait_for_timeout(700)
                check('only upper UW chart remains on second screen',await page.locator('#uw-three-chart').evaluate('c=>c.getBoundingClientRect().top>0&&c.getBoundingClientRect().bottom<=innerHeight+1') and await page.locator('#uw-single-chart,#uw-soft-chart,#uw-soft-scale').count()==0)
                await page.locator('#uw-three-chart').hover(position={'x':500,'y':60})
                check('upper UW tooltip shows smoothed zero rate and UW3','上影零值占比（EMA）' in await page.locator('#tooltip').inner_text() and '上影比例均值 UW3' in await page.locator('#tooltip').inner_text() and '无上影状态' in await page.locator('#tooltip').inner_text())
                check('UW card height matches continuity state card',await page.evaluate('Math.abs(document.querySelector(".uw-card").getBoundingClientRect().height-document.querySelector(".state-card").getBoundingClientRect().height)<1'))
                check('UW axis is fixed zero to one',await page.locator('#uw-three-chart').evaluate('c=>Number(c.dataset.yMin)===0&&Number(c.dataset.yMax)===1'))
                check('upper UW legend restored and combined shadows removed','影线偏向度' not in await page.locator('#uw-screen').inner_text() and 'UW3零值占比 · 上影' in await page.locator('#uw-three-title').inner_text() and '上下影合并' not in await page.locator('#uw-screen').inner_text())
                await page.locator('#uw-half-life').select_option('120');await page.wait_for_function('()=>liveViewer.data.meta.uwSettings.halfLifeMinutes===120&&!document.querySelector("#query").disabled')
                check('UW parameter changes preserve the first screen data and time view',await page.evaluate('JSON.stringify([liveViewer.data.candles,liveViewer.data.scores,liveViewer.data.states])===window.firstScreenCore&&JSON.stringify(liveViewer.charts.view)===JSON.stringify(window.firstView)'))
                await page.locator('#uw-half-life').select_option('60');await page.wait_for_function('()=>liveViewer.data.meta.uwSettings.halfLifeMinutes===60&&!document.querySelector("#query").disabled')
                await page.locator('#go-uw').click();await page.wait_for_timeout(700);await page.screenshot(path=str(output/'uw.png'))
                check('relative strength replaces former median-count chart',await page.evaluate('liveViewer.data.relativeStrength.length===liveViewer.data.scores.length&&liveViewer.data.relativeStrength.some(r=>r.buyStrength!==null)&&!("buyActivity" in liveViewer.data)') and '相对强度' in await page.locator('#buy-title').inner_text() and '异常买入额超中位数' not in await page.locator('body').inner_text())
                check('relative defaults use three minutes and twenty four hour EMA',await page.evaluate('liveViewer.data.meta.strengthSettings.windowMinutes===3&&liveViewer.data.meta.strengthSettings.halfLifeMinutes===1440&&liveViewer.data.meta.strengthSettings.baselineMinutes===10080'))
                check('activity card matches UW height',await page.evaluate('Math.abs(document.querySelector(".buy-activity-card").getBoundingClientRect().height-document.querySelector(".uw-card").getBoundingClientRect().height)<1'))
                await page.locator('#buy-activity-chart').hover(position={'x':500,'y':60})
                await page.wait_for_timeout(60)
                strength_readout=await page.locator('#buy-readout').inner_text()
                check('relative hover has no tooltip and retains shared cursor',await page.locator('#tooltip').is_hidden() and await page.evaluate('liveViewer.charts.cursor!==null'))
                check('relative readout compact and omits timestamp',all(x in strength_readout for x in ['买/交','强度','分位','金额','中位','倍数']) and '北京时间' not in strength_readout and len(strength_readout)<180)
                check('strength axis fixed zero to one hundred',await page.locator('#buy-activity-chart').evaluate('c=>Number(c.dataset.yMin)===0&&Number(c.dataset.yMax)===100'))
                check('multiple curves share EMA and use independent log1p right scale',await page.locator('#buy-activity-chart').evaluate('c=>c.dataset.multipleScale==="log1p"&&c.dataset.multipleLines==="2"&&Number(c.dataset.multipleMax)===100') and await page.evaluate('liveViewer.data.relativeStrength.some(r=>r.buyMultipleEMA!==null&&r.tradeMultipleEMA!==null)'))
                check('multiple curves are round dotted lines in both colors',await page.evaluate('multiplePatterns.some(p=>p.cap==="round"&&p.color==="#5caaff")&&multiplePatterns.some(p=>p.cap==="round"&&p.color==="#efc15d")'))
                check('new positive-only multiple baseline is identified',await page.evaluate('liveViewer.data.meta.strengthSettings.multipleBaseline==="positive_window_median"&&liveViewer.data.relativeStrength.some(r=>r.buyPositiveMedian>0&&r.buyPositiveSamples>0)') and '正中位' in await page.locator('#buy-readout').inner_text())
                await page.evaluate("""()=>{const row=liveViewer.data.relativeStrength.find(r=>r.time===liveViewer.charts.cursor);window.capRow=row;window.capSaved=[row.buyMultipleEMA,row.tradeMultipleEMA];row.buyMultipleEMA=250;row.tradeMultipleEMA=125;window.capY={buy:Infinity,trade:Infinity};const original={};for(const name of ['moveTo','lineTo']){original[name]=CanvasRenderingContext2D.prototype[name];CanvasRenderingContext2D.prototype[name]=function(x,y){if(this.canvas.id==='buy-activity-chart'&&this.lineCap==='round'&&this.getLineDash().join(',')==='1,3'){const key=this.strokeStyle==='#5caaff'?'buy':this.strokeStyle==='#efc15d'?'trade':null;if(key)window.capY[key]=Math.min(window.capY[key],y);}return original[name].call(this,x,y);};}window.stopCapCapture=()=>{for(const name in original)CanvasRenderingContext2D.prototype[name]=original[name];};liveViewer.charts.schedule();}""")
                await page.wait_for_timeout(80)
                check('both multiple curves over 100 draw at upper boundary',await page.evaluate('Math.abs(capY.buy-8)<1e-8&&Math.abs(capY.trade-8)<1e-8&&document.querySelector("#buy-activity-chart").dataset.multipleMax==="100"'))
                check('hover keeps actual multiple values above 100',await page.evaluate('capRow.buyMultipleEMA===250&&capRow.tradeMultipleEMA===125') and '250/125' in await page.locator('#buy-readout').inner_text())
                await page.evaluate('()=>{stopCapCapture();[capRow.buyMultipleEMA,capRow.tradeMultipleEMA]=capSaved;liveViewer.charts.schedule();}')
                await page.locator('#show-multiples').uncheck();await page.wait_for_timeout(60)
                check('multiple overlay can hide independently',await page.locator('#buy-activity-chart').evaluate('c=>c.dataset.multipleLines==="0"&&c.dataset.yMax==="100"'))
                await page.locator('#show-multiples').check();await page.wait_for_timeout(60)
                await page.locator('#strength-half-life').select_option('15');await page.wait_for_function('()=>liveViewer.data.meta.strengthSettings.halfLifeMinutes===15&&!document.querySelector("#query").disabled')
                check('strength smoothing leaves original charts unchanged',await page.evaluate('JSON.stringify([liveViewer.data.candles,liveViewer.data.scores,liveViewer.data.states])===window.firstScreenCore'))
                await page.locator('#strength-window').select_option('15');await page.wait_for_function('()=>liveViewer.data.meta.strengthSettings.windowMinutes===15&&!document.querySelector("#query").disabled')
                check('strength remains within zero to hundred',await page.evaluate('liveViewer.data.relativeStrength.every(r=>r.buyStrength===null||r.buyStrength>=0&&r.buyStrength<=100)'))
                for value in ['3','5']:
                    await page.locator('#strength-window').select_option(value);await page.wait_for_function('(v)=>liveViewer.data.meta.strengthSettings.windowMinutes===v&&!document.querySelector("#query").disabled',arg=int(value))
                    check('short strength window '+value+' minutes applies','近'+value+'分钟' in await page.locator('#buy-title').inner_text())
                for value in ['240','1440']:
                    await page.locator('#strength-half-life').select_option(value);await page.wait_for_function('(v)=>liveViewer.data.meta.strengthSettings.halfLifeMinutes===v&&!document.querySelector("#query").disabled',arg=int(value))
                    check('long strength EMA '+value+' minutes applies',str(int(value)//60)+'小时' in await page.locator('#buy-title').inner_text())
                await page.locator('#strength-window').select_option('30');await page.wait_for_function('()=>liveViewer.data.meta.strengthSettings.windowMinutes===30&&!document.querySelector("#query").disabled')
                await page.locator('#strength-half-life').select_option('30');await page.wait_for_function('()=>liveViewer.data.meta.strengthSettings.halfLifeMinutes===30&&!document.querySelector("#query").disabled')
                await page.evaluate('window.strengthBeforePeriod=JSON.stringify(liveViewer.data.relativeStrength)')
                check('no raw trade requests are made',not any('/api/trade-jobs' in url for url in requests))
                await page.locator('#go-uw').click();await page.wait_for_timeout(700);await page.screenshot(path=str(output/'buy_activity.png'))
                await page.locator('#go-first').click();await page.wait_for_timeout(700)
                check('returning to first screen keeps original three charts visible',await page.locator('#price-chart').evaluate('c=>c.getBoundingClientRect().top>=0') and await page.locator('#state-chart').evaluate('c=>c.getBoundingClientRect().bottom<=innerHeight'))
                check('default price span is fixed fifty percent',await page.locator('#price-chart').evaluate('c=>Math.abs(Number(c.dataset.yMax)/Number(c.dataset.yMin)-1.5)<1e-10'))
                check('outlying wick does not force the fixed axis to expand',await page.locator('#price-chart').evaluate('c=>Number(c.dataset.yMax)<500') and await page.evaluate('liveViewer.data.candles.some(c=>c.high===500)'))
                check('EMA computed by Node appears in candles and legend',await page.evaluate('liveViewer.data.candles.some(c=>Number.isFinite(c.emaFast)&&Number.isFinite(c.emaMid)&&Number.isFinite(c.emaSlow))') and await page.locator('#fast-label').inner_text()=='EMA快9')
                check('score data has two known native minute channels',await page.evaluate('liveViewer.data.scores.some(s=>Number.isFinite(s.buyScore)&&Number.isFinite(s.tradeScore))&&liveViewer.data.scores[1].time-liveViewer.data.scores[0].time===60000'))
                check('requested future truncates at current closed minute',await page.evaluate('liveViewer.data.end===Date.UTC(2026,8,18)&&liveViewer.data.end<liveViewer.data.meta.requestedEnd') and '最近已收盘分钟' in await page.locator('#warnings').inner_text())
                await page.locator('#y-span').fill('20');await page.locator('#y-span').dispatch_event('change');await page.wait_for_timeout(50)
                check('manual price range changes to twenty percent',await page.locator('#price-chart').evaluate('c=>Math.abs(Number(c.dataset.yMax)/Number(c.dataset.yMin)-1.2)<1e-10'))
                await page.locator('#y-center').fill('150');await page.locator('#y-center').dispatch_event('change')
                await page.locator('#zoom-in').click();await page.wait_for_timeout(50)
                check('time zoom is shared across both charts',await page.locator('#price-chart').evaluate('c=>c.dataset.timeStart===document.querySelector("#score-chart").dataset.timeStart&&c.dataset.timeEnd===document.querySelector("#score-chart").dataset.timeEnd') and await page.evaluate('liveViewer.charts.view[1]-liveViewer.charts.view[0]<liveViewer.data.end-liveViewer.data.start'))
                await page.locator('#query').click();await page.wait_for_function('() => (!document.querySelector("#query").disabled)')
                check('refresh preserves manual span centre and time view',await page.locator('#y-span').input_value()=='20' and await page.locator('#y-center').input_value()=='150' and await page.evaluate('liveViewer.charts.view[1]-liveViewer.charts.view[0]<liveViewer.data.end-liveViewer.data.start'))
                await page.locator('#show-fast').uncheck()
                check('EMA visibility toggle changes rendered series',await page.evaluate('!liveViewer.charts.ema[0]'))
                await page.locator('#price-chart').hover(position={'x':500,'y':100})
                check('price hover includes OHLC change and EMA','Change' in await page.locator('#tooltip').inner_text() and 'EMA快' in await page.locator('#tooltip').inner_text())
                await page.locator('#score-chart').hover(position={'x':500,'y':100})
                check('score hover includes both scores and coverage','历史覆盖' in await page.locator('#tooltip').inner_text() and '异常买入' in await page.locator('#tooltip').inner_text())
                await page.locator('#ema-fast').fill('60');await page.locator('#query').click()
                check('invalid EMA ordering has a readable validation message','快线 < 中线 < 慢线' in await page.locator('#status').inner_text())
                await page.locator('#ema-fast').fill('9');await page.locator('#show-fast').check();await page.locator('#y-span').fill('50');await page.locator('#y-span').dispatch_event('change');await page.locator('#anchor').click();await page.locator('#fit').click();await page.mouse.move(1,1)
                await page.locator('#query').click();await page.wait_for_function('() => (!document.querySelector("#query").disabled)')
                await page.screenshot(path=str(output/'browser.png'),full_page=True)
                check('scores follow initial three minute period by default',await page.evaluate('liveViewer.data.meta.scoreSettings.mode==="follow"&&liveViewer.data.meta.scoreSettings.continuityWindow===3') and 'C3' in await page.locator('#score-title').inner_text())
                check('legacy mode dropdowns removed',await page.locator('#score-mode,#state-mode').count()==0)
                check('symbol and period share one row',await page.evaluate('Math.abs(document.querySelector("#symbol").getBoundingClientRect().top-document.querySelector("#period").getBoundingClientRect().top)<1'))
                check('old buying terminology removed from visible UI','主动买入' not in await page.locator('body').inner_text())
                await page.evaluate('window.weeklyScore=JSON.stringify(liveViewer.data.scores);window.weeklyCandles=JSON.stringify(liveViewer.data.candles)')
                for days in ['1','3','14','7']:
                    await page.locator('#score-decay').select_option(days)
                    await page.wait_for_function('(d)=>liveViewer.data.meta.scoreSettings.transitionDays===d&&!document.querySelector("#query").disabled',arg=int(days))
                    check('decay '+days+' days recalculates actual scores',await page.evaluate('((d)=>{const old=JSON.parse(window.weeklyScore);const delta=Math.max(...liveViewer.data.scores.map((r,i)=>Math.abs((r.buyScore??0)-(old[i].buyScore??0))));return (d===7?delta<.00001:delta>.01)&&JSON.stringify(liveViewer.data.candles)===window.weeklyCandles})('+days+')'))
                check('two week warmup remains available after switching back',await page.evaluate('liveViewer.data.meta.historyDays===56&&liveViewer.data.meta.scoreSettings.warmupDays===14'))
                await page.evaluate('window.strengthBeforePeriod=JSON.stringify(liveViewer.data.relativeStrength)')
                for period in ['1','5','15','30','60','3']:
                    await page.locator('#period').select_option(period);await page.wait_for_function('(p)=>liveViewer.data.period===p&&!document.querySelector("#query").disabled',arg=int(period))
                    check('follow mode maps period '+period+' to C'+period,await page.evaluate('(p)=>liveViewer.data.meta.scoreSettings.continuityWindow===p&&liveViewer.data.meta.stateSettings.continuityWindow===p&&liveViewer.data.meta.uwSettings.period===p&&liveViewer.data.uw.length===liveViewer.data.candles.length&&liveViewer.data.meta.strengthSettings.windowMinutes===30&&JSON.stringify(liveViewer.data.relativeStrength)===window.strengthBeforePeriod',int(period)) and 'C'+period in await page.locator('#score-title').inner_text())
                await page.evaluate('window.scoreBeforePeriod=JSON.stringify(liveViewer.data.scores)')
                old_start=await page.evaluate('liveViewer.data.start')
                old_view=await page.evaluate('JSON.stringify(liveViewer.charts.view)')
                rect=await page.locator('#price-chart').bounding_box()
                await page.mouse.move(rect['x']+rect['width']*.4,rect['y']+80);await page.mouse.down();await page.mouse.move(rect['x']+rect['width']*.65,rect['y']+80);await page.mouse.up()
                await page.wait_for_function('(start)=>liveViewer.data.start<start&&!document.querySelector("#query").disabled',arg=old_start)
                check('dragging past left edge loads older history without changing visible times',await page.evaluate('JSON.stringify(liveViewer.charts.view)')==old_view and await page.evaluate('liveViewer.data.start')==old_start-7*86400000)
                check('left extension leaves previous score values unchanged',await page.evaluate('(()=>{const start=JSON.parse(window.scoreBeforePeriod)[0].time;return JSON.stringify(liveViewer.data.scores.filter(r=>r.time>=start))===window.scoreBeforePeriod})()'))
                await page.locator('#at').fill('2026-09-05T08:00');await page.locator('#query').click()
                await page.wait_for_function('()=>liveViewer.data.at===Date.UTC(2026,8,5)&&!document.querySelector("#query").disabled')
                old_end=await page.evaluate('liveViewer.data.end')
                rect=await page.locator('#price-chart').bounding_box()
                await page.mouse.move(rect['x']+rect['width']*.65,rect['y']+80);await page.mouse.down();await page.mouse.move(rect['x']+rect['width']*.4,rect['y']+80);await page.mouse.up()
                await page.wait_for_function('(end)=>liveViewer.data.end>end&&!document.querySelector("#query").disabled',arg=old_end)
                check('dragging past right edge loads later available history',await page.evaluate('liveViewer.data.end')==min(old_end+7*86400000,1789689600000))
                check('extension keeps price axis fixed and time axes aligned',await page.locator('#price-chart').evaluate('c=>Math.abs(Number(c.dataset.yMax)/Number(c.dataset.yMin)-1.5)<1e-10&&c.dataset.timeStart===document.querySelector("#score-chart").dataset.timeStart'))
                await page.locator('#symbol').fill('ERROR');await page.locator('#query').click();await page.wait_for_function('() => (document.querySelector("#status").classList.contains("error"))')
                check('API failures show errors without substituting data','fixture API unavailable' in await page.locator('#status').inner_text() and await page.evaluate('liveViewer.data.symbol==="牛来USDT"'))
                await page.locator('#symbol').fill('SLOW');await page.locator('#query').click();await page.wait_for_function('() => (document.querySelector("#status").textContent.includes("fixture loading"))')
                await page.locator('#cancel').click()
                check('in-flight query can be cancelled',await page.locator('#query').is_enabled() and '已取消' in await page.locator('#status').inner_text())
                await page.set_viewport_size({'width':1100,'height':760});await page.wait_for_timeout(100)
                check('resized activity card matches UW height',await page.evaluate('Math.abs(document.querySelector(".buy-activity-card").getBoundingClientRect().height-document.querySelector(".uw-card").getBoundingClientRect().height)<1'))
                check('resized UW card still matches state card height',await page.evaluate('Math.abs(document.querySelector(".uw-card").getBoundingClientRect().height-document.querySelector(".state-card").getBoundingClientRect().height)<1'))
                check('compact desktop keeps state chart inside the viewport',await page.locator('#state-chart').evaluate('c=>c.getBoundingClientRect().bottom<=innerHeight&&c.getBoundingClientRect().height>40'))
                check('compact desktop keeps both charts inside the viewport',await page.locator('#score-chart').evaluate('c=>c.getBoundingClientRect().bottom<=innerHeight'))
                check('all lines are at most one CSS pixel',await page.evaluate('drawWidths.length>0&&Math.max(...drawWidths)<=1'))
                check('no external API or CDN requests in isolated fixture',not external)
                await page.locator('#visible-state').uncheck();await page.reload();await page.wait_for_function('()=>document.querySelector("#at").value!==""')
                check('chart visibility preference persists on reload',not await page.locator('#visible-state').is_checked() and not await page.locator('.state-card').is_visible() and await page.locator('#price-chart').is_visible())
                check('no browser runtime errors',not errors)
                await browser.close()
        finally:
            process.terminate()
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:process.kill();process.wait()
    (output/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
    if not all(c['passed'] for c in checks):raise SystemExit(1)

if __name__=='__main__':asyncio.run(run(sys.argv[1] if len(sys.argv)>1 else '/tmp/live-viewer-browser'))
