import test from 'node:test';
import assert from 'node:assert/strict';
import {buySettings,computeBuyActivity} from '../lib/buy-activity.js';
import {computeView} from '../lib/metrics.js';
const M=60000,T=Date.UTC(2026,8,1);
function candle(i,period,amount){return {time:T+i*period*M,takerQuote:amount};}
function median(values){values.sort((a,b)=>a-b);return values.length%2?values[(values.length-1)/2]:(values[values.length/2-1]+values[values.length/2])/2;}
test('all periods and bar-window settings match independent weekly medians counts and EMA',()=>{
 for(const period of [1,3,5,15,30,60])for(const buyWindow of [15,30,60])for(const buyHalfLife of [5,10,20]){
  const settings=buySettings({period,buyWindow,buyHalfLife}),B=settings.baselineBars,W=settings.windowBars;
  const rows=Array.from({length:B+W+8},(_,i)=>candle(i,period,i%7===0?0:i%31*10));
  const result=computeBuyActivity(rows,settings);let ema=null;
  for(let i=B+W-1;i<rows.length;i++){
   const m=median(rows.slice(i-W-B+1,i-W+1).map(r=>r.takerQuote)),count=rows.slice(i-W+1,i+1).filter(r=>r.takerQuote>m).length;
   ema=ema===null?count:ema+settings.alpha*(count-ema);
   assert.equal(result[i].median,m);assert.equal(result[i].count,count);assert.equal(result[i].baselineCount,B);assert.ok(Math.abs(result[i].smoothedCount-ema)<1e-12);
  }
  assert.equal(result[B+W-2].count,null);assert.equal(settings.windowMinutes,period*W);assert.equal(settings.halfLifeMinutes,period*buyHalfLife);
 }
});
test('current bars never enter baseline, equal amounts are excluded, valid zeros enter median',()=>{
 const s=buySettings({period:60,buyWindow:15}),rows=Array.from({length:s.baselineBars+15},(_,i)=>candle(i,60,i<s.baselineBars?0:100));
 const r=computeBuyActivity(rows,s).at(-1);assert.equal(r.median,0);assert.equal(r.count,15);assert.equal(r.aboveMedian,true);
 assert.equal(computeBuyActivity(rows.map(r=>({...r,takerQuote:10})),s).at(-1).count,0);
});
test('unknown current bars blank the count and reset EMA; baseline coverage never treats gaps as zero',()=>{
 const s=buySettings({period:60,buyWindow:15}),rows=Array.from({length:s.baselineBars+45},(_,i)=>candle(i,60,i%2?20:10));
 const i=s.baselineBars+15;rows[i].takerQuote=null;const output=computeBuyActivity(rows,s);assert.equal(output[i].count,null);assert.equal(output[i+14].smoothedCount,null);assert.notEqual(output[i+15].count,null);assert.equal(output[i+15].smoothedCount,output[i+15].count);
 const broken=rows.map(r=>({...r}));broken[10].takerQuote=null;broken[11].takerQuote=null;const r=computeBuyActivity(broken,s)[s.baselineBars+14];assert.ok(r.baselineCoverage<.99);assert.equal(r.median,null);assert.equal(r.count,null);
});
test('future values and prefix cropping cannot change already computed counts or EMA',()=>{
 const s=buySettings({period:60}),rows=Array.from({length:400},(_,i)=>candle(i,60,i%23)),a=computeBuyActivity(rows,s),prefix=computeBuyActivity(rows.slice(0,300),s);
 assert.deepEqual(prefix,a.slice(0,300));const changed=computeBuyActivity(rows.map((r,i)=>i>=300?{...r,takerQuote:1e9}:r),s);assert.deepEqual(prefix,changed.slice(0,300));
});
test('aggregated period uses summed taker-buy USDT and pre-window history without extra data',()=>{
 const period=60,s=buySettings({period}),historyStart=T+M,end=T+12*1440*M;
 const rows=Array.from({length:(end-historyStart)/M+1},(_,i)=>({time:historyStart+i*M,open:100,high:101,low:99,close:100,volume:1,quote:100,trades:1,takerQuote:(i%11)*2}));
 const q={period,historyStart,start:T+10*1440*M,at:T+11*1440*M,end},view=computeView(rows,q),candles=[];
 for(let i=0;i<rows.length;i+=period){const group=rows.slice(i,i+period);candles.push({time:group.at(-1).time,takerQuote:group.reduce((a,r)=>a+r.takerQuote,0)});}
 assert.deepEqual(view.buyActivity,computeBuyActivity(candles,s).filter(r=>r.time>=q.start));assert.equal(view.metaMetrics.buySettings.period,60);assert.equal(view.metaMetrics.buySettings.baselineBars,168);
 assert.throws(()=>buySettings({buyWindow:1}));assert.throws(()=>buySettings({buyHalfLife:1}));
});
