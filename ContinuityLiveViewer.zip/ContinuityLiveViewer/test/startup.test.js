import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {getEventListeners} from 'node:events';
import {combineSignals} from '../lib/signals.js';
import {BinanceClient} from '../lib/binance.js';
const {launchOptions}=createRequire(import.meta.url)('../start.cjs');
test('unsupported proxy flags are never sent to older Node versions',()=>{
  for(const version of ['18.17.0','20.0.0','22.0.0','24.0.0']){
    const result=launchOptions(version,new Set(),{});
    assert.equal(result.args.length,1);assert.ok(result.args[0].endsWith('server.js'));assert.equal(result.warning,null);
  }
  assert.throws(()=>launchOptions('16.20.0',new Set(),{}),/18.17/);
  assert.throws(()=>launchOptions('18.16.0',new Set(),{}),/18.17/);
});
test('explicit proxy transport needs no environment-proxy runtime flag',()=>{
 const result=launchOptions('24.19.0',new Set(['--use-env-proxy']),{HTTPS_PROXY:'http://localhost:7890'});assert.equal(result.args.length,1);assert.equal(result.warning,null);
});
test('older runtimes without AbortSignal.any can cancel and dispose listeners',()=>{
  const original=AbortSignal.any;AbortSignal.any=undefined;
  try{
    const a=new AbortController(),b=new AbortController();
    const combined=combineSignals([a.signal,b.signal]);
    assert.equal(getEventListeners(a.signal,'abort').length,1);
    b.abort(Error('cancelled'));assert.equal(combined.signal.aborted,true);assert.equal(combined.signal.reason.message,'cancelled');
    assert.equal(getEventListeners(a.signal,'abort').length,0);
    const another=combineSignals([a.signal]);another.dispose();assert.equal(getEventListeners(a.signal,'abort').length,0);
    assert.equal(combineSignals([b.signal]).signal.aborted,true);
  }finally{AbortSignal.any=original;}
});
test('API pagination works with the abort compatibility implementation',async()=>{
  const original=AbortSignal.any;AbortSignal.any=undefined;
  try{
    const at=Date.UTC(2026,8,15),controller=new AbortController();
    const client=new BinanceClient({spacing:0,fetchImpl:async()=>new Response(JSON.stringify([[at,'10','11','9','10','1',at+59999,'10',1,'1','5']]))});
    const rows=await client.load({symbol:'BTCUSDT',historyStart:at+60000,end:at+60000},{signal:controller.signal});
    assert.equal(rows.length,1);assert.equal(getEventListeners(controller.signal,'abort').length,0);
  }finally{AbortSignal.any=original;}
});
