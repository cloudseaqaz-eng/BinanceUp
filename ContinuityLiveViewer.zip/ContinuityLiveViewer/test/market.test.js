import test from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {BinanceClient,parseQuery} from '../lib/binance.js';
import {plan} from '../lib/sessions.js';
import {createServer} from '../server.js';
import {computeView} from '../lib/metrics.js';
const M=60000,D=1440*M,at=Date.UTC(2026,8,15);
const bar=(t,future)=>[t,future?'20':'10',future?'21':'11',future?'19':'9',future?'20':'10','2',t+59999,future?'200':'20',future?10:2,'1',future?'160':'5','0'];
test('spot and futures use correct API and field mapping with separate caches',async()=>{
 const calls=[],client=new BinanceClient({spacing:0,fetchImpl:async url=>{calls.push(url.href);return new Response(JSON.stringify([bar(at,url.pathname==='/fapi/v1/klines')]));}});
 const spot=await client.page('BTCUSDT',at,at,null,'spot'),future=await client.page('BTCUSDT',at,at,null,'futures');
 assert.equal(spot[0].close,10);assert.equal(future[0].close,20);assert.equal(future[0].quote,200);assert.equal(future[0].takerQuote,160);
 assert.equal(new URL(calls[0]).pathname,'/api/v3/uiKlines');assert.equal(new URL(calls[1]).pathname,'/fapi/v1/klines');assert.equal(new URL(calls[1]).origin,process.env.BINANCE_FUTURES_API_BASE||'https://fapi.binance.com');
 await client.page('BTCUSDT',at,at,null,'spot');await client.page('BTCUSDT',at,at,null,'futures');assert.equal(calls.length,2);
 const query={market:'futures',symbol:'BTCUSDT',historyStart:at+M,end:at+1003*M};const pages=[];
 const c=new BinanceClient({spacing:0,fetchImpl:async url=>{pages.push(url);const start=Number(url.searchParams.get('startTime')),end=Number(url.searchParams.get('endTime'));return new Response(JSON.stringify(Array.from({length:(end-start)/M+1},(_,i)=>bar(start+i*M,true))));}});
 const rows=await c.load(query);assert.equal(rows.length,1003);assert.ok(pages.every(u=>u.pathname==='/fapi/v1/klines'&&u.searchParams.get('interval')==='1m'));
});
test('unsupported contracts fail once without silently querying spot',async()=>{
 let calls=0;const c=new BinanceClient({spacing:0,fetchImpl:async url=>{calls++;assert.equal(url.pathname,'/fapi/v1/klines');return new Response(JSON.stringify({code:-1121,msg:'Invalid symbol'}),{status:400});}});
 await assert.rejects(c.page('NOSUCHUSDT',at,at,null,'futures'),/没有可查询的这个USDT合约/);assert.equal(calls,1);
});
test('market defaults to spot and sessions cannot switch market in place',()=>{
 const input={symbol:'BTC',at:new Date(at).toISOString()},spot=parseQuery(input,at+D),future=parseQuery({...input,market:'futures'},at+D);
 assert.equal(spot.market,'spot');assert.equal(future.market,'futures');assert.throws(()=>parseQuery({...input,market:'coinm'},at+D));
 assert.throws(()=>plan({action:'period',market:'futures'},{query:spot},at+D),/切换市场须重新查询/);
 assert.equal(plan({action:'period',period:60},{query:future},at+D).query.market,'futures');
 assert.equal(plan({...input,market:'futures',action:'query'},{query:spot},at+D).previous,null);
});
function rows(q){return Array.from({length:Math.floor((q.end-q.historyStart)/M)+1},(_,i)=>{const time=q.historyStart+i*M,f=q.market==='futures',p=f?20:10;return {time,open:p,high:p+1,low:p-1,close:p,volume:1,quote:f?200:100,trades:f?5:1,takerQuote:f?(i%7<5?160:0):(i%5===0?50:0)};});}
test('HTTP market switch fully recomputes every series and extension keeps selected market',async()=>{
 const calls=[],client={base:'isolated fixture',load:async q=>{calls.push({...q});if(q.symbol==='NOFUTUREUSDT'&&q.market==='futures')throw Error('没有可查询的这个USDT合约');return rows(q);}};
 const s=createServer({client,now:()=>at+30*D});s.listen(0,'127.0.0.1');await once(s,'listening');const base='http://127.0.0.1:'+s.address().port;
 async function job(body){const res=await fetch(base+'/api/jobs',{method:'POST',body:JSON.stringify(body)});assert.equal(res.status,202);const {id}=await res.json();for(let i=0;i<200;i++){const r=await(await fetch(base+'/api/jobs/'+id)).json();if(r.status==='error')throw Error(r.error);if(r.status==='done')return r.result;await new Promise(r=>setTimeout(r,10));}assert.fail('timeout');}
 try{
  const spot=await job({symbol:'BTC',at:new Date(at).toISOString()});
  // A supplied old session id on a fresh query must never merge spot rows.
  const future=await job({symbol:'BTC',at:new Date(at).toISOString(),market:'futures',sessionId:spot.sessionId});
  assert.equal(spot.market,'spot');assert.equal(future.market,'futures');assert.notDeepEqual(spot.scores,future.scores);
  const q=calls[1],expected=computeView(rows(q),q);for(const key of ['candles','scores','states','uw','relativeStrength','buyPressure','bbw','amountZ','volumePersistence'])assert.deepEqual(future[key],expected[key]);
  const changed=await job({action:'period',sessionId:future.sessionId,period:60});assert.equal(calls.length,2);assert.equal(changed.market,'futures');
  const extended=await job({action:'extend',sessionId:changed.sessionId,direction:'after'});assert.equal(calls.at(-1).market,'futures');assert.equal(extended.market,'futures');
  await assert.rejects(job({symbol:'NOFUTURE',at:new Date(at).toISOString(),market:'futures'}),/没有可查询/);
 }finally{s.closeAllConnections();await new Promise(r=>s.close(r));}
});
