import test from 'node:test';
import assert from 'node:assert/strict';
import {createStateCalculator,stateSettings} from '../lib/continuity-state.js';
import {computeView} from '../lib/metrics.js';
const row=(i)=>i%397===0?null:{trades:i%7<5?1:0,takerQuote:i%11<5?20:0};
test('all CN state channels match independently counted trailing windows',()=>{
 for(const period of [1,3,5,15,30,60]){
  const calculator=createStateCalculator(stateSettings({period,stateWindow:180})),raw=[],conditions=[];
  for(let i=0;i<1000;i++){
   const r=row(i);raw.push(r);const recent=raw.slice(-period);
   let condition=null;if(recent.length===period&&recent.every(Boolean)){const b=recent.filter(r=>r.takerQuote>0).length/period,t=recent.filter(r=>r.trades>0).length/period;condition={buyHigh:Number(b>=.8),tradeHigh:Number(t>=.8),buyLow:Number(b<=.2)};}
   conditions.push(condition);const last=conditions.slice(-180),actual=calculator.push(r);
   for(const k of ['buyHigh','tradeHigh','buyLow'])assert.equal(actual[k],last.length===180&&last.every(Boolean)?last.reduce((s,r)=>s+r[k],0)/180:null);
  }
 }
});
test('state begins after N plus W minus one valid minutes, missing resets full state window',()=>{
 for(const stateWindow of [360,1440,4320]){
 const c=createStateCalculator(stateSettings({period:60,stateWindow}));const r={trades:1,takerQuote:50};
 for(let i=0;i<stateWindow+58;i++)assert.equal(c.push(r).buyHigh,null);assert.deepEqual(c.push(r),{buyHigh:1,tradeHigh:1,buyLow:0});assert.equal(c.push(null).buyHigh,null);
 for(let i=0;i<stateWindow+58;i++)assert.equal(c.push(r).buyHigh,null);assert.equal(c.push(r).buyHigh,1);
 }
});
test('state settings distinguish fixed C5 from period, reject invalid windows',()=>{
 assert.equal(stateSettings({period:60,stateMode:'fixed5'}).continuityWindow,5);
 for(const stateWindow of [180,360,720,1440,4320])assert.equal(stateSettings({stateWindow}).windowMinutes,stateWindow);
 assert.throws(()=>stateSettings({stateMode:'bad'}));assert.throws(()=>stateSettings({stateWindow:60}));
});
test('state has no weekly warmup and future/period changes respect chosen state mode',()=>{
 const start=Date.UTC(2026,8,1),raw=Array.from({length:1500},(_,i)=>({time:start+i*60000,open:100,high:100,low:100,close:100,volume:1,quote:100,trades:i%3===0?1:0,takerQuote:i%7===0?30:0}));
 const options={at:start+1000*60000,start,historyStart:start,end:raw.at(-1).time,stateMode:'fixed5',stateWindow:180};
 const a=computeView(raw,{...options,period:3}),b=computeView(raw,{...options,period:60});assert.deepEqual(a.states,b.states);assert.ok(a.states.some(r=>r.buyHigh!==null));assert.ok(a.scores.every(r=>r.buyScore===null));
 const short=computeView(raw,{...options,period:3,end:options.at});assert.deepEqual(short.states,a.states.filter(r=>r.time<=options.at));
 const followed=computeView(raw,{...options,stateMode:'follow',period:60});assert.notDeepEqual(followed.states,b.states);assert.deepEqual(followed.candles,b.candles);assert.deepEqual(followed.scores,b.scores);
});
