import test from 'node:test';
import assert from 'node:assert/strict';
import {frequencySettings,frequencyRange,verifyTrades,computeFrequency} from '../lib/trade-frequency.js';
const M=60000,D=1440*M,T=Date.UTC(2026,8,15);
function query(start=T,end=T+60*M,opts={}){const settings=frequencySettings(opts);return {symbol:'BTCUSDT',start,end,settings,loadStart:start-(7*1440+settings.windowMinutes+settings.warmupMinutes)*M};}
function trade(id,time,amount,isBuyerMaker=false){return {id,time,amount,isBuyerMaker};}
function median(a){a.sort((a,b)=>a-b);return a.length%2?a[(a.length-1)/2]:(a[a.length/2-1]+a[a.length/2])/2;}
test('rolling weekly median excludes the current window and counts strictly larger buys',async()=>{
 const q=query(T,T);const rows=[trade(1,T-31*M,50),trade(2,T-31*M+1,150),trade(3,T-29*M,100),trade(4,T-20*M,101),trade(5,T-M,1000,true)];
 const r=(await computeFrequency(rows,q))[0];assert.equal(r.median,100);assert.equal(r.baselineCount,2);assert.equal(r.count,1);assert.equal(r.buyCount,2);assert.equal(r.rate,1/30);
});
test('Fenwick medians counts and causal EMA match independent brute force for every setting',async()=>{
 for(const tradeWindow of [15,30,60])for(const tradeHalfLife of [5,10,20]){
  const q=query(T,T+90*M,{tradeWindow,tradeHalfLife}),rows=[];let id=0;
  for(let t=q.loadStart;t<q.end;t+=11*M)rows.push(trade(id++,t,10+(id%23)*5,id%4===0));
  const actual=await computeFrequency(rows,q);let ema=null;
  for(let t=q.loadStart+7*D+tradeWindow*M;t<=q.end;t+=M){
   const edge=t-tradeWindow*M,h=rows.filter(r=>!r.isBuyerMaker&&r.time>=edge-7*D&&r.time<edge),c=rows.filter(r=>!r.isBuyerMaker&&r.time>=edge&&r.time<t),m=h.length?median(h.map(r=>r.amount)):null,count=m===null?null:c.filter(r=>r.amount>m).length,rate=m===null?null:count/tradeWindow;
   ema=rate===null?null:ema===null?rate:ema+q.settings.alpha*(rate-ema);
   if(t>=q.start){const r=actual[(t-q.start)/M];assert.equal(r.median,m);assert.equal(r.count,count);assert.equal(r.buyCount,c.length);assert.equal(r.baselineCount,h.length);assert.equal(r.rate,rate);assert.ok(Math.abs(r.smoothedRate-ema)<1e-12);}
  }
 }
});
test('known no-buy windows count zero; unknown baseline stays blank; future trades cannot alter past',async()=>{
 const q=query(T,T+60*M),rows=[trade(0,T-2*D,10),trade(1,T+M,20)];
 const a=await computeFrequency(rows,q);assert.equal(a[0].rate,0);assert.equal(a[0].count,0);assert.equal(a[0].smallSample,true);
 const empty=await computeFrequency([],q);assert.ok(empty.every(r=>r.rate===null&&r.smoothedRate===null&&r.median===null));
 const b=await computeFrequency([...rows,trade(2,T+40*M,1e9)],q);assert.deepEqual(a.filter(r=>r.time<=T+40*M),b.filter(r=>r.time<=T+40*M));
 const prefix=await computeFrequency(rows,{...q,end:T+20*M});assert.deepEqual(prefix,a.filter(r=>r.time<=T+20*M));
});
test('complete raw trades are checked against every native-minute count',()=>{
 const rows=[{time:T+M,trades:2},{time:T+2*M,trades:0}],trades=[trade(10,T+1000,1),trade(11,T+2000,2)];
 verifyTrades(trades,rows,T,T+2*M);
 assert.throws(()=>verifyTrades(trades.slice(1),rows,T,T+2*M),/不一致/);
 assert.throws(()=>verifyTrades([trades[0],trades[0]],rows,T,T+2*M),/异常/);
 assert.throws(()=>verifyTrades(trades,rows.slice(0,1),T,T+2*M),/缺少/);
});
test('range validation uses existing session bounds and includes weekly history and warmup',()=>{
 const session={query:{symbol:'BTCUSDT',start:T,end:T+D}},q=frequencyRange({},session);assert.equal(q.loadStart,T-(7*1440+30+240)*M);assert.throws(()=>frequencyRange({start:T-M},session));assert.throws(()=>frequencySettings({tradeWindow:5}));assert.throws(()=>frequencySettings({tradeHalfLife:1}));
});
