import test from 'node:test';
import assert from 'node:assert/strict';
import {buyPressureSettings,computeBuyPressure,createBuyPressureSignal} from '../lib/buy-pressure.js';
import {computeView} from '../lib/metrics.js';
import {parseQuery} from '../lib/binance.js';
import {plan} from '../lib/sessions.js';
const M=60000,near=(a,b,tol=1e-8)=>assert.ok(Math.abs(a-b)<tol,`${a} != ${b}`);
const settings=()=>({...buyPressureSettings(),fastAlpha:.08,slowAlpha:.015,baselineMinutes:120});
function input(n){return Array.from({length:n},(_,i)=>{const q=100+(i%31)*10,share=.5+.1*Math.sin(i/40)+.03*Math.sin(i/11);return {time:i*M,quote:q,takerQuote:q*share};});}
test('amount-weighted ratios and prior-window Z match independent recursive and direct statistics',()=>{
 const s=settings(),rows=input(1800),out=computeBuyPressure(rows,s),raws=[];let fq=0,fb=0,sq=0,sb=0,fc=0,sc=0;
 for(let i=0;i<rows.length;i++){
  const r=rows[i];fq=(1-s.fastAlpha)*fq+s.fastAlpha*r.quote;fb=(1-s.fastAlpha)*fb+s.fastAlpha*r.takerQuote;sq=(1-s.slowAlpha)*sq+s.slowAlpha*r.quote;sb=(1-s.slowAlpha)*sb+s.slowAlpha*r.takerQuote;fc=(1-s.fastAlpha)*fc+s.fastAlpha;sc=(1-s.slowAlpha)*sc+s.slowAlpha;
  const a=fb/fq,b=sb/sq;near(out[i].fastShare,a);near(out[i].slowShare,b);
  const raw=fc>=.99&&sc>=.99?a-b:null;assert.equal(out[i].raw,raw);
  const past=raws.slice(-s.baselineMinutes).filter(x=>x!==null);
  if(i>=s.baselineMinutes&&past.length>=Math.ceil(s.baselineMinutes*.99)){
   const mean=past.reduce((a,v)=>a+v,0)/past.length,std=Math.sqrt(past.reduce((a,v)=>a+(v-mean)**2,0)/past.length);near(out[i].mean,mean);near(out[i].std,std);
   if(raw!==null&&std>=s.minimumStd){near(out[i].z,(raw-mean)/std,1e-7);near(out[i].score,50+50*Math.tanh(out[i].z/3));}
  }else assert.equal(out[i].z,null);
  raws.push(raw);
 }
});
test('future data and monetary scale do not affect historical Z',()=>{
 const s=settings(),rows=input(1400),all=computeBuyPressure(rows,s);
 assert.deepEqual(computeBuyPressure(rows.slice(0,1100),s),all.slice(0,1100));
 const scaled=computeBuyPressure(rows.map(r=>({...r,quote:r.quote*1000,takerQuote:r.takerQuote*1000})),s);
 for(let i=0;i<all.length;i++)if(all[i].z!==null)near(all[i].z,scaled[i].z,1e-7);
});
test('zero variance, missing data and prolonged inactivity cannot create signals',()=>{
 const s=settings(),constant=Array.from({length:1500},(_,i)=>({time:i*M,quote:100,takerQuote:50}));
 const c=computeBuyPressure(constant,s);assert.equal(c.at(-1).reason,'基线波动不足');assert.ok(c.every(r=>r.z===null&&r.event===null));
 const rows=input(1800);rows[1000]={time:1000*M,quote:null,takerQuote:null};for(let i=1400;i<rows.length;i++)rows[i]={time:i*M,quote:0,takerQuote:0};
 const out=computeBuyPressure(rows,s);assert.equal(out[1000].z,null);assert.equal(out[1000].reason,'当前数据缺失');assert.ok(out.slice(1430).every(r=>r.z===null&&r.event===null));
 const tiny=[{time:0,quote:.001,takerQuote:.001},{time:M,quote:1000,takerQuote:0}];assert.ok(computeBuyPressure(tiny,s)[1].fastShare<.00001);
});
test('confirmation occurs at sixth qualifying minute, exit and cooldown prevent repeated signals',()=>{
 const s=buyPressureSettings(),c=createBuyPressureSignal(s);
 c.push(1,.01,1);assert.equal(c.push(2.1,.01,1).event,'candidate');
 for(let j=0;j<4;j++)assert.equal(c.push(2.2,.01,1).event,null);
 assert.equal(c.push(2.3,.01,1).event,'confirmed');assert.equal(c.push(2.4,.01,-1).status,'active');
 assert.equal(c.push(.9,.01,-1).event,'exit');
 for(let j=0;j<59;j++)assert.equal(c.push(j%2?2.2:1.5,.01,1).event,null);
 c.push(1,.01,1);assert.equal(c.push(2.2,.01,1).event,'candidate');
});
test('negative raw, falling slope and gaps cannot confirm a bullish signal',()=>{
 const s=buyPressureSettings();
 for(const [raw,slope] of [[-.01,1],[.01,-1]]){const c=createBuyPressureSignal(s);c.push(1,raw,slope);assert.equal(c.push(3,raw,slope).event,null);}
 const c=createBuyPressureSignal(s);c.push(1,.1,1);c.push(3,.1,1);c.push(null,null,null);for(let i=0;i<10;i++)assert.equal(c.push(3,.1,1).event,null);
});
test('minute-based Z is independent of K-line period and settings validate through query/session',()=>{
 const start=Date.UTC(2026,7,1),rows=input(1200).map((r,i)=>({...r,time:start+i*M,open:10,high:10,low:10,close:10,volume:r.quote/10,trades:2})),q={at:rows.at(-1).time,start,historyStart:start,end:rows.at(-1).time};
 const a=computeView(rows,{...q,period:3});assert.deepEqual(computeView(rows,{...q,period:60}).buyPressure,a.buyPressure);
 const query=parseQuery({symbol:'BTC',at:new Date(q.at).toISOString()},q.at+M);assert.equal(query.buyFastHours,3);assert.equal(query.buySlowHours,24);
 const p=plan({action:'period',buyFastHours:4,buySlowHours:48},{query},q.at+M);assert.equal(p.load,null);assert.equal(p.query.buySlowHours,48);
 assert.throws(()=>buyPressureSettings({buyFastHours:1}));assert.throws(()=>buyPressureSettings({buySlowHours:12}));
});
