import test from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {createServer} from '../server.js';
const M=60000,at=Date.UTC(2026,8,15),now=at+8*1440*M;
async function serve(client,action){const s=createServer({client,now:()=>now});s.listen(0,'127.0.0.1');await once(s,'listening');try{await action('http://127.0.0.1:'+s.address().port);}finally{s.closeAllConnections();await new Promise(r=>s.close(r));}}
test('HTTP jobs compute API-only result, retain closed bars and expose progress/errors',async()=>{
 let called=0;const client={base:'fixture',load:async(q,{onProgress})=>{called++;onProgress({completed:1,total:1,message:'fixture'});return Array.from({length:Math.floor((q.end-q.historyStart)/M)+1},(_,i)=>({time:q.historyStart+i*M,open:10,high:11,low:9,close:10,volume:2,quote:20,trades:2,takerQuote:10}));}};
 await serve(client,async base=>{
  const c=await (await fetch(base+'/api/config')).json();assert.equal(c.defaults.interval,'3m');
  const response=await fetch(base+'/api/jobs',{method:'POST',body:JSON.stringify({symbol:'BTC',at:new Date(at).toISOString()})});assert.equal(response.status,202);const {id}=await response.json();
  let job;for(let i=0;i<30;i++){job=await(await fetch(base+'/api/jobs/'+id)).json();if(job.status==='done')break;await new Promise(r=>setTimeout(r,20));}
  assert.equal(job.status,'done');assert.equal(called,1);assert.equal(job.result.meta.anchorPrice,10);assert.ok(job.result.scores.some(x=>x.buyScore>99));assert.ok(job.result.candles.every(x=>x.time%180000===0&&x.time<=job.result.end));assert.equal(job.result.meta.source,'fixture');
  const bad=await fetch(base+'/api/jobs',{method:'POST',body:JSON.stringify({symbol:'BTC',at:'no'})});assert.equal(bad.status,400);
  assert.equal((await fetch(base+'/lib/metrics.js')).status,404);
  const page=await fetch(base+'/');assert.equal(page.status,200);assert.ok((await page.text()).includes('price-chart'));
 });
});
test('failed upstream job cannot report a fabricated result',async()=>{
 await serve({load:async()=>{throw Error('API unavailable');}},async base=>{const {id}=await(await fetch(base+'/api/jobs',{method:'POST',body:JSON.stringify({symbol:'BTC',at:new Date(at).toISOString()})})).json();const job=await(await fetch(base+'/api/jobs/'+id)).json();assert.equal(job.status,'error');assert.equal(job.error,'API unavailable');assert.equal(job.result,undefined);});
});
