import test from 'node:test';
import assert from 'node:assert/strict';
import {amountZScore} from '../public/charts.js';
test('amount score keeps a fixed midpoint and symmetric bounded monotonic scale for all coins',()=>{
 assert.equal(amountZScore(0),50);
 assert.ok(Math.abs(amountZScore(2)-79.1391472674)<1e-8);
 assert.ok(Math.abs(amountZScore(-2)-20.8608527326)<1e-8);
 let previous=-1;
 for(const z of [-1e6,-100,-10,-3,-2,-1,0,1,2,3,10,100,1e6]){
  const score=amountZScore(z);assert.ok(score>=0&&score<=100);assert.ok(score>=previous);assert.ok(Math.abs(score+amountZScore(-z)-100)<1e-12);previous=score;
 }
 for(const value of [null,undefined,NaN,Infinity,-Infinity,'2'])assert.equal(amountZScore(value),null);
});
