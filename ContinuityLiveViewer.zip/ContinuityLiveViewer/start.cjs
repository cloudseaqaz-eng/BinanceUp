const {spawn}=require('node:child_process');
const path=require('node:path');

function launchOptions(version,flags,env){
  const [major,minor]=version.replace(/^v/,'').split('.').map(Number);
  if(!(major>18||major===18&&minor>=17))throw Error('需要 Node.js 18.17 或更新版本。当前版本：'+version);
  const proxySupported=flags.has('--use-env-proxy');
  const proxyConfigured=['HTTPS_PROXY','https_proxy','HTTP_PROXY','http_proxy','ALL_PROXY','all_proxy'].some(k=>env[k]);
  return {args:[...(proxySupported?['--use-env-proxy']:[]),path.join(__dirname,'server.js')],
    warning:proxyConfigured&&!proxySupported?'提示：当前Node.js不支持环境代理自动读取，本次使用直连。如需使用HTTP(S)_PROXY，请升级到支持该功能的Node.js版本（推荐24.5或更新）。':null};
}
module.exports={launchOptions};
if(require.main===module){
  try{
    const options=launchOptions(process.version,process.allowedNodeEnvironmentFlags,process.env);
    if(options.warning)console.warn(options.warning);
    const child=spawn(process.execPath,options.args,{stdio:'inherit',env:process.env});
    for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>child.kill(signal));
    child.on('error',e=>{console.error('无法启动服务：'+e.message);process.exitCode=1;});
    child.on('exit',(code,signal)=>{process.exitCode=code??(signal==='SIGINT'?0:1);});
  }catch(e){console.error(e.message);process.exitCode=1;}
}
