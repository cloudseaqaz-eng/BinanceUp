const {spawn}=require('node:child_process');
const path=require('node:path');

function launchOptions(version,flags,env){
  const [major,minor]=version.replace(/^v/,'').split('.').map(Number);
  if(!(major>18||major===18&&minor>=17))throw Error('需要 Node.js 18.17 或更新版本。当前版本：'+version);
  return {args:[path.join(__dirname,'server.js')],warning:null};
}
module.exports={launchOptions};
if(require.main===module){
  try{
    const options=launchOptions(process.version,process.allowedNodeEnvironmentFlags,process.env);
    console.log('币安请求代理：'+(process.env.BINANCE_PROXY||'http://127.0.0.1:7890'));
    if(options.warning)console.warn(options.warning);
    const child=spawn(process.execPath,options.args,{stdio:'inherit',env:process.env});
    for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>child.kill(signal));
    child.on('error',e=>{console.error('无法启动服务：'+e.message);process.exitCode=1;});
    child.on('exit',(code,signal)=>{process.exitCode=code??(signal==='SIGINT'?0:1);});
  }catch(e){console.error(e.message);process.exitCode=1;}
}
