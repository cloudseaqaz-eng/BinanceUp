> 本包移植位置：算法快照在 `../lib/volume-chart-models.mjs`，接入在 `../lib/recognition.js`、`../lib/recognition-worker.js`，绘图在 `../public/recognition-charts.js`。下文的 SpotMonitor 源码路径与 portable 路径属于导出来源项目。

# 持续放量识别、持续放量识别 v3、资金方向：算法与绘图移植说明

版本：2026-11-17。以 SpotMonitor 提交 `d3eb901f50fc8f3462208c43fb2183ebb1826722` 的实际实现为准。

本文用于在其他项目复现以下三张图，包括计算、状态、颜色、标记和联动。文末附完整、无第三方计算依赖的 ES2022 JavaScript；也可直接复制同目录的 [volume-chart-models.mjs](portable/volume-chart-models.mjs)。计算代码可运行在 Node.js 或浏览器，绘图库可以替换。

## 1. 三张图的关系

| 图表                      | 核心输入/输出                             | 用途                                                      |
| ------------------------- | ----------------------------------------- | --------------------------------------------------------- |
| 持续放量识别（本文称 v2） | 长基准成交额 Z 分 → 正向 CUSUM `S`        | 识别相对较长历史的持续放量，并标记符合条件的“吸筹”        |
| 持续放量识别 v3           | 长基准、短基准 Z 分 → `S长`、`S短`、`S缩` | 识别“缩量 → 布防 → 再放量预警 → 升级”，同时保留长基准确认 |
| 资金方向                  | v3 输出的 `imb`、`absorb`、`drift`        | 柱状图展示主动买卖不平衡，黄色线展示吸收强度              |

这些计算使用成交额与价格，不依赖 UW3 零值占比、级联 EMA 或活跃分。“持续放量积分”是另一套指标，不包含在本文中。

**旧版 v2 与 v3 不是简单共用同一条长分数线：v3 增加了市场过滤历史样本覆盖率要求。** 要复现现有页面，分别调用两个计算函数；资金方向使用 v3 的结果。

## 2. 数据与时间约定

每条输入为一根已经收盘的原生 15 分钟 K 线：

```ts
type RecognitionBar = {
  time: number; // Unix 毫秒，采用这根 K 线的收盘边界时间
  total: number | null; // quoteVolume，成交额，例如 USDT
  takerBuy: number | null; // takerBuyQuote，主动买入成交额，同一计价单位
  close: number | null; // 收盘价
  market?: number | null; // 同一时刻 BTCUSDT 的 quoteVolume，可缺失
};
```

Binance `/api/v3/uiKlines` 数组下标：`[0]` 开盘时间、`[4]` 收盘价、`[7]` 成交额、`[10]` 主动买入成交额。项目存储的 `time = openTime + 15 × 60 × 1000`，不是 Binance 的 `closeTime = openTime + STEP - 1`。例如 10:00～10:15 的 K 线，标签时间为 10:15。

移植时应保证：

1. 输入按时间升序，时间对齐到 15 分钟边界，同一时间只保留一条。
2. 金额字符串转换为有限数值；空字符串、非法值、负数转为 `null`。价格必须大于 0，不能以 0 代替缺失值。
3. 使用**成交额**和**主动买入成交额**，不要混用币数量字段 `volume`、`takerBuyBase`。
4. BTC 参考数据按相同收盘时间精确关联；不存在就填 `null`，不前向填充。
5. 计算 BTCUSDT 本身时不做自身市场过滤，将 `market` 全部置空。
6. 使用完整连续时间网格。计算器会在首末输入之间补出缺失的 15 分钟槽，所有原始字段填 `null`，不会补成零成交额。末尾也需要延伸至选中时刻时，可显式追加该时刻的空输入。

计算器不负责下载、校验或排序输入。不要向它传入字符串、`undefined` 代替金额、未收盘 K 线或乱序数组。

存储/计算始终使用真实 Unix 时间。前端传给 Lightweight Charts 时除以 1000，显示标签再按 `Asia/Shanghai` 格式化；不要给时间戳加 8 小时。

## 3. 公共数学定义与参数

15 分钟频率下：每天 96 根，每小时 4 根。以下窗口均按完整时间网格计数。

| 参数                            |            默认值 | 含义                                   |
| ------------------------------- | ----------------: | -------------------------------------- |
| `stepMin`                       |                15 | K 线周期（分钟）；本文复现以此频率为准 |
| `lagDays`                       |                 7 | 长基准与当前时刻之间隔离 7 天          |
| `baseDays`                      |                28 | 长基准样本窗口 28 天                   |
| `minCoverage`                   |               0.8 | 基准有效样本最低覆盖率                 |
| `zClip`                         |                 4 | CUSUM 每根输入截断至 −4～4             |
| `cusumK`                        |               0.5 | 长 CUSUM 每根扣减量                    |
| `cusumH`                        |                12 | 长 CUSUM 确认门槛                      |
| `cusumCap`                      |                36 | 长 CUSUM 累计上限，独立参数            |
| `dutyHours / dutyZ / dutyTh`    |      72 / 1 / 0.5 | 72 小时内 Z > 1 的占比，入场要求 > 50% |
| `floorHours / floorQ / floorTh` |   48 / 0.1 / −0.3 | 48 小时 Z 的 10% 分位，入场要求 > −0.3 |
| `flowHours`                     |                72 | 资金统计窗口                           |
| `absorbTh / driftTh / imbTh`    | 1.5 / 0.15 / 0.02 | 吸筹判定门槛                           |
| `refreshBars`                   |                 0 | 0 表示季节性基准每 96 根刷新           |
| `useMarket`                     |              true | 启用 BTC 成交额共同因素过滤            |

### 3.1 分位数、中位数与缺失

忽略非有限值，排序后用线性插值分位数：`h = (n−1)q`，取 `floor(h)` 与 `ceil(h)` 两项插值。中位数为 `q=0.5`；没有有效值返回 `NaN`，输出 JSON 时转为 `null`。

所有下文滚动窗口都包含当前根：`[t−W+1, t]`。至少有 `0.8 × W` 个有效值才输出，否则缺失。当前实现滚动窗口的 80% 是固定值，修改 `minCoverage` 不会同步修改它。

### 3.2 去日内季节性、稳健 Z 分

先对成交额变换：

```text
x[t] = ln(1 + total[t])
P = 96
L = lagDays × P
B = baseDays × P
基准区间 = [t−L−B, t−L)      // 不包含右端点
```

每次刷新基准时：

1. 按 `j % P` 分为一天内的 96 个时段，每个时段取基准中 `x[j]` 的中位数，得到 `profile[slot]`。
2. 求残差 `r[j] = x[j] − profile[j % P]`。
3. `m = median(r)`，`scale = 1.4826 × median(|r−m|)`。
4. 有效残差不足 `minCoverage × B`，或 `scale ≤ 1e−6`，本次基准无效。

输出：

```text
zRaw[t] = (x[t] − profile[t % P] − m) / scale
```

从 `t=L+B` 开始尝试输出；基准默认每 96 根刷新一次，在两次刷新之间复用。刷新相位以输入序列起点为锚，不保证恰逢自然日零点。Z 分本身不截断，仅累计 CUSUM 时截断。

### 3.3 可选 BTC 共同因素过滤

BTC 成交额同样经过 `ln(1+成交额)`、季节性校正、稳健 Z 分，得到 `zMarket`。在对应的滞后基准窗口中，仅取本币与 BTC 都有效的配对：

```text
beta = clip(Σ(zCoin × zMarket) / Σ(zMarket²), 0, 2)
e[j] = zCoin[j] − beta × zMarket[j]
em = median(e)
es = 1.4826 × median(|e−em|)
zAdjusted[t] = (zCoin[t] − beta × zMarket[t] − em) / es
```

分母为 0 时 `beta=0`；`es ≤ 1e−6` 或当前任一 Z 缺失时不输出。回归是不带截距的，再对残差做中位数/MAD 标准化。有效 `beta` 默认每 96 根重估一次；`beta` 无效时逐根重试。

**两版差异：**

| 调用                                             | 配对历史覆盖率限制                              |
| ------------------------------------------------ | ----------------------------------------------- |
| `detectSustainedVolume(raw, options)`，原 v2 图  | 不额外要求配对满 80%；仍要求残差尺度有效        |
| `detectReexpansion(raw, options)`，v3 及资金方向 | 长、短市场过滤都要求有效配对数 ≥ 80% 的基准窗口 |

市场模式按时间向前切换：某根之前从未见过有效 BTC 成交额时，使用本币原始 Z；第一次出现有效 BTC 成交额后使用过滤 Z，预热不足时保留缺失，**不回退原始 Z**。`marketApplied=true` 表示已经切入过滤模式，不代表当前根一定有有效分数。不能因为整段数据末尾存在 BTC，就把更早的历史也切入过滤模式。

### 3.4 单边 CUSUM

```text
S[-1] = 0
S[t] = min(cap, max(0, S[t−1] + clip(z[t], −4, 4) − K))
```

缺失 Z 时保持上一累计值，不清零、不扣减。累计由 0 转为正数时记录候选起点；回到 0 时清除。该起点是 `changeAt`，不是确认信号发生时间。

## 4. 图一：持续放量识别（v2）

采用长基准 Z，参数为滞后 7 天、基准 28 天。

```text
S = CUSUM(z, K=0.5, cap=36)
duty = 最近 72 小时有效 Z 中，Z > 1 的数量 / 有效 Z 数量
floor = 最近 48 小时有效 Z 的 10% 分位数
```

`duty` 分母是有效样本数，不是固定的 288；有效样本不足 80% 时结果缺失。

### 4.1 放量状态的进入与保持

```text
之前不在放量状态：
  regime = S > 12 AND duty > 0.5 AND floor > −0.3

之前已经在放量状态：
  regime = S > 6
```

进入后通过半门槛保持，避免频繁切换；保持阶段不再检查 duty、floor。比较均为严格大于。Z 缺失时 CUSUM 保持，因此已进入的状态也可能保持，不能把状态持续理解为每根都具备完整原始数据。

### 4.2 吸筹判定

使用第 6 节的资金统计：

```text
accumulate = regime
             AND absorb > 1.5
             AND abs(drift) < 0.15
             AND imb > 0.02
```

这里是“持续放量、价格位移有限、单位成交额价格冲击下降、主动买入偏多”的规则标签，不是对某个账户实际持仓行为的直接观测。`drift` 为对数收益，±0.15 对应普通涨跌幅约 −13.93%～+16.18%，不等于严格的 ±15%。

### 4.3 绘制规格

| 元素     | 绘制方式                                                                 |
| -------- | ------------------------------------------------------------------------ |
| 主线     | `S`，蓝色 `#3977ce`，2px                                                 |
| Y 轴     | 固定 `0～cusumCap`，默认 0～36                                           |
| 参考线   | `cusumH`（默认 12，“确认”）、`cusumH/2`（默认 6，“保持”）点虚线          |
| 背景     | `regime=true` 时淡绿 `rgba(35,167,111,0.10)`                             |
| 确认标记 | `regime` 从 false 变 true 的根，绿色“确认”                               |
| 吸筹标记 | `accumulate` 从 false 变 true 的根，紫色“吸筹”；与确认同根时优先显示吸筹 |
| 高度     | 图表画布 150px，标题/参数栏在画布之外                                    |

标记位置：`S > 2/3 × cusumCap` 时放在线下、箭头向上；否则放在线上、箭头向下，以减少边缘裁切。关闭主线终值横线和终值轴标签。

裁剪显示区间时，保留显示起点前一根 `priorPoint`，用于判断状态边沿，避免把显示区间内第一根误画成新确认/吸筹。

`events` 中的 `confirmAt` 是进入状态的实际时间；`changeAt` 是候选累计起点。`endAt` 在当前实现中是该段**最后一根放量根**，不是首根退出时间，正在进行的段也有 `endAt`。段级 `peakS`、`accumulate` 会随该段后续数据更新，回测应读取当时的逐根状态/事件，不能把最终段级汇总倒灌到早先时刻。

## 5. 图二：持续放量识别 v3

### 5.1 三条 CUSUM

| 变量          | Z 分基准                              | 累计方式                     | 阈值/上限                    |
| ------------- | ------------------------------------- | ---------------------------- | ---------------------------- |
| `S`，S长      | 滞后 7 天、基准 28 天，严格市场覆盖率 | 正向 `CUSUM(zLong, cusumK)`  | `cusumH=12`、`cusumCap=36`   |
| `Sshort`，S短 | 滞后 0 天、基准 7 天，严格市场覆盖率  | 正向 `CUSUM(zShort, shortK)` | `shortH=12`、上限 `3×shortH` |
| `Sdn`，S缩    | 同一条长 Z                            | 正向 `CUSUM(−zLong, dnK)`    | `dnH=12`、上限 `3×dnH`       |

三个 K 默认都是 0.5。**`Sdn` 的计算结果本身非负，只是在图中向下绘制。** 不能直接对 `null` 取负号，否则 JavaScript 会将 `−null` 当成 0。

短周期辅助量：

```text
dutyS = 最近 48 小时有效 zShort > 1 的比例
floorS = 最近 24 小时 zShort 的 10% 分位数
zl24 = 最近 24 小时 zLong 的中位数
```

注意 `zl24` 是标准化成交额长 Z 的中位数，不是 UW3 图的“30 天中位数”，也不是原始成交额中位数。

### 5.2 缩量、布防、预警、升级的逐根状态机

按时间升序执行，初始所有标志为 false，`lastContraction=−Infinity`、`low=Infinity`：

```text
1. contraction = Sdn > 12

2. 若 contraction：
     如果距上一根 contraction 超过 5 天（480 根）：
       alerted=false；upgraded=false；low=Infinity
     lastContraction = 当前索引

3. armed = 当前索引 − lastContraction <= 480
   若 armed 且 zl24 有效：low = min(low, zl24)

4. 原先 shortOn=false：
     shortOn = Sshort > 12 AND dutyS > 0.5 AND floorS > −0.3
   原先 shortOn=true：
     shortOn = Sshort > 6

5. alert = false
   若 armed AND shortOn AND NOT alerted：
     alert=true；alerted=true

6. rise = zl24 − low
   upgrade = false
   若 alerted AND NOT upgraded AND shortOn
      AND rise >= 0.7 AND imb > 0.02：
     upgrade=true；upgraded=true
```

还原当前实现时必须保留这些细节：

- 缩量判断只有 `Sdn > dnH`，不另加 duty、floor。
- 布防截止为**最后一根满足缩量条件之后** 5 天，包含边界。持续缩量会持续刷新最后时间。
- `low` 在所有布防根上更新，不局限于紫色缩量区间。
- 预警不要求当前根恰好是短放量状态的上升沿：已处于 `shortOn`，随后进入布防，也能触发。
- `alert`、`upgrade` 是单根事件；`alerted`、`upgraded` 是记忆标志，短放量暂时结束或布防到期不会自动清除它们。只有新的缩量段与上一次缩量间隔超过 5 天时才重置。
- 当前升级条件没有再次要求 `armed=true`。之前预警过、未升级且后来重新满足其他条件时，布防到期后仍可能升级；不能擅自补上条件，否则结果会改变。
- 预警先执行，升级后执行，所以同一根可以同时预警和升级。`rise` 门槛为 `>=`，`imb` 门槛为严格 `>`。

### 5.3 长确认与吸筹事件

v3 的长放量状态及吸筹布尔条件沿用第 4 节，但长 Z 使用严格覆盖率版本。

```text
longConfirm = 当前 regime=true AND 前一根 regime=false

每次 longConfirm 将 accShown=false
accumulateSignal = accumulate AND NOT accShown
触发 accumulateSignal 后将 accShown=true
```

因此 v3 每个长放量段最多标记一次“吸筹”；原 v2 图可以在同一段内反复标记吸筹条件的 false→true 边沿。这是有意保留的显示差异。

### 5.4 绘制规格

```text
S短显示值 = clip(Sshort / shortH, −3, 3)
S长显示值 = clip(S / cusumH, −3, 3)
S缩显示值 = clip(−Sdn / dnH, −3, 3)
```

| 元素   | 绘制方式                                                  |
| ------ | --------------------------------------------------------- |
| S短    | 蓝色 `#2f6fde`，2px                                       |
| S长    | 灰色 `#9aa3ae`，1px                                       |
| S缩    | 紫色 `#8e5bd6`，1px，向负方向显示                         |
| Y 轴   | 固定 −3～3；数值为阈值倍数，不是 Z 分、百分比或原始累计值 |
| 参考线 | +1“放量”、+0.5“保持”、−1“缩量”，点虚线                    |
| 高度   | 150px                                                     |

背景互斥，按以下优先级选择：

```text
regime                  → 绿 rgba(39,174,96,0.14)
否则 contraction        → 紫 rgba(142,91,214,0.12)
否则 armed              → 黄 rgba(242,183,5,0.16)
否则                    → 无背景
```

不要将三层直接叠加，否则颜色与当前项目不同。背景对应的是状态，不等同于文字状态名称的全部细分。

| 事件布尔值         | 图形         | 颜色      | 位置 |
| ------------------ | ------------ | --------- | ---- |
| `alert`            | 上箭头“预警” | `#f2a900` | 上侧 |
| `upgrade`          | 上箭头“升级” | `#e5484d` | 上侧 |
| `longConfirm`      | 圆形“长确认” | `#27ae60` | 下侧 |
| `accumulateSignal` | 方形“吸筹”   | `#8e5bd6` | 下侧 |

当前页面将上下标记附着在两条值恒为 0 的透明载体线上，用 `aboveBar` / `belowBar` 区分；标记 `autoScale:false`。这些载体不是指标，不能显示成数据读数。所有主线关闭 `priceLineVisible`、`lastValueVisible`。

文字状态按顺序匹配：长放量 → 短放量且已预警（根据 `upgraded` 显示“已升级/预警”）→ 缩量中 → 布防中 → 短期放量但未布防 → 基准预热/数据不足（长短 Z 都缺失）→ 正常。代码附录提供 `reexpansionState()`，可直接复用。

## 6. 图三：资金方向

本图复用 **v3 输出**，不另建放量状态机。

### 6.1 主动买卖不平衡 imb：柱状图

每根主动卖出成交额近似为 `total − takerBuy`：

```text
net[t] = 2 × takerBuy[t] − total[t]
W = 72 × 4 = 288
imb[t] = Σ net[t−W+1 … t] / Σ total[t−W+1 … t]
```

这是窗口成交额加权的不平衡，**不是**每根不平衡比例的简单平均，也不是账户净充值/资金净流入。

完整数据下 `imb ∈ [−1,1]`，`imb=0.02` 表示主动买入占总成交额 51%、主动卖出 49%。`imb>0.02` 不是主动买入占比超过 2%。

当前实现从索引 `t=W` 开始计算，要求窗口总成交额有效根数 ≥ 80%、合计 >0。前缀和忽略缺失的 net；**没有单独要求主动买入字段覆盖率满 80%**。移植时若增加该门槛，缺失行情下结果会与现版不同。

绘图传值为 `100 × imb`：非负绿色 `rgba(38,166,91,0.75)`，负值红色 `rgba(229,72,77,0.75)`。绑定左侧百分比轴，以 0 为中心对称自动缩放，边界绝对值至少为 1（即 ±1%），不是固定 ±100%。

### 6.2 illiq 与 absorb：黄色吸收强度线

```text
absLogReturn[t] = |ln(close[t] / close[t−1])|
illiq[t] = Σ absLogReturn[t−W+1 … t] / Σ total[t−W+1 … t]
```

`illiq` 表示单位成交额对应的绝对价格变化。用历史基准确定正常水平：

```text
历史区间 = [t−7天−28天, t−7天)
每隔 4 小时取一个历史 illiq 值
ref[t] = 这些有限值的中位数
absorb[t] = ref[t] / illiq[t]
```

`ref` 默认每 96 根更新一次，尚无有效 ref 时逐根重试；抽样步长为 16 根。它是对**滚动 72 小时 illiq** 每 4 小时抽样，不是把每 4 小时行情先聚合再计算。`illiq≤0` 或基准无效时不输出 absorb。当前实现不额外对收益率样本数、ref 样本数加 80% 门槛，只有成交额窗口门槛。

解释：`absorb>1` 表示当前单位成交额引发的价格变化小于历史常态；`absorb=2` 表示约为历史的一半。它本身没有买卖方向，买入/卖出偏向要看 imb；高 absorb 并不单独等于吸筹。

绘图：黄色 `#e08a00`、1px，使用右轴固定 0～5，画 `min(absorb,5)`。工具提示/读数始终保留原始值，比如真实值 8 应读作 8，图中封顶为 5；不修改计算结果，也不把它乘 100。

**缺口不能连线：**将 absorb 按连续有效时段拆成多条线，遇 `null` 或缺失时刻就结束当前线段；孤立有效点画点。当前使用的 Lightweight Charts 不应仅靠 whitespace 期待自动断线。

### 6.3 drift：读数和判定，当前不画线

```text
drift[t] = ln(close[t] / close[t−288])
```

这是 72 小时起终点对数收益，读数显示 `100 × drift` 加 `%`；它与 absorb、imb 一起用于吸筹判定。实际页面不是第三条资金曲线。

### 6.4 空数据与双轴

当前资金图在两侧轴各放一条覆盖完整时间网格的透明零值载体，以便全空/预热窗口也能平移、联动；左轴载体不扩张有效数据的范围，右轴载体固定 0～5。它们不能显示成“资金值为 0”。

三张图画布各 150px，资金图位于 v3 下方。要严格对齐绘图区，独立项目可以给其他图也预留同样左侧轴宽度；当前资金图多一个左轴，因此只对齐时间范围不一定等于所有绘图像素边界完全相同。

## 7. 可直接移植的计算调用

将附录复制为 `volume-chart-models.mjs` 后：

```js
import {
  detectSustainedVolume,
  detectReexpansion,
  reexpansionState,
} from "./volume-chart-models.mjs";

// allBars 为已排序、已校验、包含充分前置历史的 RecognitionBar[]。
// end 是选中时刻；只在明确展示后续走势时才传入更晚的数据。
const input = allBars.filter((b) => b.time <= end);
const legacy = detectSustainedVolume(input, {
  cusumH: 12,
  dutyTh: 0.5,
  floorTh: -0.3,
  useMarket: true,
});
const v3 = detectReexpansion(input, {
  cusumK: 0.5,
  shortK: 0.5,
  dnK: 0.5,
  upgradeRise: 0.7,
  upgradeImb: 0.02,
  useMarket: true,
});

// 先完整计算，再裁剪展示。不要先切成 90 天再计算。
const recognitionPoints = legacy.rows.filter((p) => p.time >= start);
const priorPoint = legacy.rows.find((p) => p.time === start - 900_000) ?? null;
const statePoints = v3.rows.filter((p) => p.time >= start);
const stateSeries = statePoints.map((p) => ({
  time: p.time / 1000,
  short: Math.min(3, p.Sshort / v3.options.shortH),
  long: Math.min(3, p.S / v3.options.cusumH),
  down: Math.max(-3, -p.Sdn / v3.options.dnH),
  label: reexpansionState(p),
}));
const flowSeries = statePoints.map((p) => ({
  time: p.time / 1000,
  imbPercent: p.imb === null ? null : 100 * p.imb,
  absorbPlot: p.absorb === null ? null : Math.min(5, p.absorb),
  absorbActual: p.absorb,
  drift: p.drift,
}));
```

返回的缺失统计字段为 `null`，累计值为数值，状态/事件字段为布尔值。v2 返回 `{rows, events}`；v3 返回 `{rows, events, options}`。`events` 中 v3 的类型为 `alert`、`upgrade`、`longConfirm`、`accumulate`，`time` 为实际触发时间，不回填到历史候选点。完整字段含义见前文和附录中的返回对象。

两组参数应独立保存：修改旧图的 H、duty、floor 不要悄悄改变 v3。按现有 UI，旧图可调 H、duty、floor、市场过滤；v3 可调三个 K、升级 rise/imb 门槛和市场过滤。

## 8. 历史长度、因果性和重现

展示起点为选中时刻往前 3 个自然月。若允许选中最近 3 个月内的历史时刻，原始行情至少覆盖最近 6 个月；**还需在最早展示点前预留计算预热数据**。

当前项目在 6 个自然月前额外保留 73 天，支持长基准原始 Z 与市场残差二次基准及 72 小时资金窗口预热。它是工程预留，不保证缺失严重、MAD 为零或 BTC 历史不足时必有有效指标。不能认为“读 35 天原始数据”就能直接得到完整市场过滤长分数。

算法逐根计算，基准窗口、滚动窗口、状态记忆都不读取该根之后的数据；预警/升级画在当时满足条件的根。未来扩展数据不应改变同一输入起点、同一参数、同一历史数据的既有逐根结果。

以下变化仍会改变重算结果：补齐/修正历史行情、切换参数或市场过滤、改变输入序列起点、改变保留窗口。特别是基准刷新相位与 CUSUM 初始状态都由输入起点决定。正式回测应固定原始数据版本、起点、参数、已收盘时间和成交额单位；不应每次拖动视窗都重新从视窗左端开始计算。

## 9. 绘图实现与联动注意事项

当前前端使用 `lightweight-charts@5.3.0`。替换为 ECharts、Canvas 等也可，计算逻辑不变。

### 9.1 固定纵轴与基础序列

Lightweight Charts v5 示例：

```js
const series = chart.addSeries(LineSeries, {
  priceLineVisible: false,
  lastValueVisible: false,
  autoscaleInfoProvider: () => ({
    priceRange: { minValue: -3, maxValue: 3 }, // v3
  }),
});
// 同时将价格轴 scaleMargins 设为 {top:0,bottom:0}。
// v2 使用 [0,cusumCap]；absorb 右轴使用 [0,5]。
```

背景应在图表画布底层按时间区间填矩形，不要让 DOM 遮罩挡住鼠标事件。连续 active 根合并成区段，左右边界各扩展半根 K 线宽，随时间缩放和拖动实时重新投影。项目的 `ChartBands.ts` 为 Lightweight Charts primitive 实现。

### 9.2 左右拖动与缩放

所有子图都需要建立相同的完整 15 分钟时间网格，缺失时保留时间槽；不同图指标开始有效的时间不同，不能只提交有效值而丢掉前置时间槽。

使用 `subscribeVisibleLogicalRangeChange` 同步**浮点逻辑范围**，不要仅同步 `getVisibleRange()` 的离散时间戳，否则拖动、缩放、右侧留白会出现跳动或不同步。

```text
STEP = 900000 毫秒
广播的 fromMs = 本图网格起点 + logical.from × STEP
广播的 toMs   = 本图网格起点 + logical.to × STEP

接收方 logical.from = (fromMs − 接收方网格起点) / STEP
接收方 logical.to   = (toMs − 接收方网格起点) / STEP
调用 setVisibleLogicalRange({from,to})
```

必须用 applying 标志及最近已应用范围去重，防止图 A 更新 B 后 B 再广播回 A；新数据异步加载时应用当前共享范围，不要重置已经拖动的其他图。鼠标离开、组件卸载时清理订阅。当前完整实现见 `web/src/components/chart-link.ts`。

### 9.3 十字光标

广播真实用户事件的时间；程序设置光标时不再次广播。每张图根据同一时间查自己的数据并更新读数，不能拿 v3 的 S 值直接设置资金图的 Y 值。

Lightweight Charts 5.3 的双轴资金图尤其要注意：程序光标按面板默认右轴解释纵坐标，即使传入左轴柱状序列也可能错位。当前实现先从左轴转成屏幕 Y，再转成右轴价格：

```js
const y =
  row.imb !== null
    ? imbSeries.priceToCoordinate(100 * row.imb)
    : row.absorb !== null
      ? absorbSeries.priceToCoordinate(Math.min(row.absorb, 5))
      : null;
const rightValue = y === null ? null : rightZeroAnchor.coordinateToPrice(y);
if (rightValue === null) flowChart.clearCrosshairPosition();
else
  flowChart.setCrosshairPosition(rightValue, row.time / 1000, rightZeroAnchor);
```

`rightZeroAnchor` 是右轴透明载体，完整时间网格每根值为 0，轴固定 0～5。即使 absorb 全部缺失，也能避免空轴转换抛错、进而中断其他图的联动。

## 10. 移植验收要点

- 同一数据与参数逐根比较 `z/S/duty/floor/imb/absorb/drift`，以及 v3 的 `zShort/Sshort/Sdn/zl24/rise` 和所有状态/事件；浮点值允许合理小误差。
- 市场过滤开/关分别比对；覆盖 BTC 完全缺失、很晚才开始出现、历史覆盖率不足的场景。
- 截取序列前缀重算，与完整序列相同前缀比较，验证没有使用未来数据。保持相同起点及历史版本。
- 检查无行情、零成交额、平坦 MAD、数据缺口：不应冒出伪造资金值、absorb 跨缺口连线或误将缺失当作缩量。
- 检查 150px 高度下标记不被裁切，确认颜色和轴单位正确，主线没有多余终值横虚线。
- 从三张图中的任一张发起拖动/缩放/十字光标操作，其他图跟随；验证空窗口和数据异步补齐后的行为。

## 11. 当前项目源码索引

以下路径相对于仓库根目录；它们用于追溯实现，附录计算器本身不依赖这些文件：

| 路径                                             | 内容                                  |
| ------------------------------------------------ | ------------------------------------- |
| `server/src/indicators/volume-recognition.ts`    | v2、稳健 Z、市场过滤、CUSUM、资金统计 |
| `server/src/indicators/volume-reexpansion.ts`    | v3 三累计与状态机                     |
| `shared/volume-recognition.ts`                   | v2 默认参数与数据类型                 |
| `shared/volume-reexpansion.ts`                   | v3 默认参数、事件、状态文字           |
| `server/src/indicators/volume-input.ts`          | 本币/BTC 数据关联                     |
| `web/src/components/VolumeRecognitionChart.tsx`  | v2 绘图                               |
| `web/src/components/VolumeReexpansionCharts.tsx` | v3 与资金方向绘图                     |
| `web/src/components/ChartBands.ts`               | 状态背景填色                          |
| `web/src/components/chart-link.ts`               | 联动范围和光标广播                    |

## 附录：完整可移植计算代码

以下代码为上述版本实际计算实现的无依赖 JavaScript 快照，不包含联网、数据库、React、Zod 或绘图库。复制整段保存为 `.mjs` 即可；输入须遵守第 2 节约定。默认参数已内置，两个算法分别保持其原有市场覆盖率规则。

```js
// SpotMonitor d3eb901f50fc8f3462208c43fb2183ebb1826722
// Exact calculation snapshot, exported as dependency-free ES2022 JavaScript.
// Inputs: sorted 15-minute closed bars, timestamps in ms, missing values null.
export const recognitionDefaults = {
  cusumH: 12,
  dutyTh: 0.5,
  floorTh: -0.3,
  useMarket: true,
  stepMin: 15,
  lagDays: 7,
  baseDays: 28,
  minCoverage: 0.8,
  zClip: 4,
  cusumK: 0.5,
  cusumCap: 36,
  dutyHours: 72,
  dutyZ: 1,
  floorHours: 48,
  floorQ: 0.1,
  flowHours: 72,
  absorbTh: 1.5,
  driftTh: 0.15,
  imbTh: 0.02,
  refreshBars: 0,
};
export const reexpansionDefaults = {
  cusumH: 12,
  dutyTh: 0.5,
  floorTh: -0.3,
  useMarket: true,
  stepMin: 15,
  lagDays: 7,
  baseDays: 28,
  minCoverage: 0.8,
  zClip: 4,
  cusumK: 0.5,
  cusumCap: 36,
  dutyHours: 72,
  dutyZ: 1,
  floorHours: 48,
  floorQ: 0.1,
  flowHours: 72,
  absorbTh: 1.5,
  driftTh: 0.15,
  imbTh: 0.02,
  refreshBars: 0,
  shortK: 0.5,
  dnK: 0.5,
  upgradeRise: 0.7,
  upgradeImb: 0.02,
  shortDays: 7,
  shortH: 12,
  shortDutyHours: 48,
  shortDutyTh: 0.5,
  shortFloorHours: 24,
  shortFloorTh: -0.3,
  dnH: 12,
  armDays: 5,
};
const v2 = (() => {
  const RECOGNITION_VERSION = "sustained-volume-recognition-v2-2026-11-16";
  const fin = (v) => typeof v === "number" && Number.isFinite(v);
  const quantile = (a, q) => {
    const v = a.filter(fin).sort((a, b) => a - b);
    if (!v.length) return NaN;
    const p = (v.length - 1) * q,
      lo = Math.floor(p),
      hi = Math.ceil(p);
    return v[lo] + (v[hi] - v[lo]) * (p - lo);
  };
  const median = (a) => quantile(a, 0.5);
  const clip = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  const nullable = (v) => (fin(v) ? v : null);
  function align(raw, stepMin) {
    if (!raw.length) return [];
    const step = stepMin * 60000,
      first = Math.floor(raw[0].time / step) * step,
      n = Math.floor((raw.at(-1).time - first) / step) + 1;
    const out = Array.from({ length: n }, (_, i) => ({
      time: first + i * step,
      total: null,
      takerBuy: null,
      close: null,
      market: null,
    }));
    for (const b of raw) {
      const i = Math.floor((b.time - first) / step);
      out[i] = { ...out[i], ...b, time: out[i].time };
    }
    return out;
  }
  function prefix(arr) {
    const s = new Float64Array(arr.length + 1),
      c = new Float64Array(arr.length + 1);
    arr.forEach((x, i) => {
      s[i + 1] = s[i] + (fin(x) ? x : 0);
      c[i + 1] = c[i] + (fin(x) ? 1 : 0);
    });
    return (a, b) => ({ sum: s[b] - s[a], cnt: c[b] - c[a] });
  }
  function seasonalRobustZ(x, o) {
    const per = Math.round(1440 / o.stepMin),
      lag = o.lagDays * per,
      base = o.baseDays * per,
      refresh = o.refreshBars || per,
      z = Array(x.length).fill(NaN);
    let profile = null,
      med = NaN,
      scale = NaN;
    for (let t = lag + base; t < x.length; t++) {
      if (profile === null || (t - lag - base) % refresh === 0) {
        const a = t - lag - base,
          b = t - lag;
        profile = new Float64Array(per);
        for (let slot = 0; slot < per; slot++) {
          const v = [];
          for (let j = a + ((slot - (a % per) + per) % per); j < b; j += per)
            v.push(x[j]);
          profile[slot] = median(v);
        }
        const r = [];
        for (let j = a; j < b; j++)
          if (fin(x[j])) r.push(x[j] - profile[j % per]);
        med = median(r);
        scale = 1.4826 * median(r.map((v) => Math.abs(v - med)));
        if (r.length < o.minCoverage * base || !(scale > 1e-6)) scale = NaN;
      }
      if (fin(x[t]) && fin(profile[t % per]) && fin(scale))
        z[t] = (x[t] - profile[t % per] - med) / scale;
    }
    return z;
  }
  function removeMarket(zc, zm, o, requireCoverage = false) {
    const per = Math.round(1440 / o.stepMin),
      lag = o.lagDays * per,
      base = o.baseDays * per,
      out = Array(zc.length).fill(NaN);
    let beta = NaN,
      med = NaN,
      scale = NaN;
    for (let t = 0; t < zc.length; t++) {
      const a = t - lag - base,
        b = t - lag;
      if (a < 0) continue;
      if (!fin(beta) || a % per === 0) {
        // As in the supplied implementation, use only jointly valid lagged Zs.
        // Early/negative indices are absent, never samples from the array's end.
        let product = 0,
          square = 0;
        const pairs = [];
        for (let j = a; j < b; j++)
          if (fin(zc[j]) && fin(zm[j])) {
            pairs.push([zc[j], zm[j]]);
            product += zc[j] * zm[j];
            square += zm[j] ** 2;
          }
        if (requireCoverage && pairs.length < o.minCoverage * base) {
          beta = NaN;
          continue;
        }
        beta = square > 0 ? clip(product / square, 0, 2) : 0;
        const e = pairs.map(([z, m]) => z - beta * m);
        med = median(e);
        scale = 1.4826 * median(e.map((v) => Math.abs(v - med)));
      }
      if (fin(zc[t]) && fin(zm[t]) && scale > 1e-6)
        out[t] = (zc[t] - beta * zm[t] - med) / scale;
    }
    return out;
  }
  function recognitionCusum(z, o = recognitionDefaults) {
    const S = Array(z.length).fill(NaN),
      start = Array(z.length).fill(-1);
    let s = 0,
      st = -1;
    for (let t = 0; t < z.length; t++) {
      if (!fin(z[t])) {
        S[t] = s;
        start[t] = st;
        continue;
      }
      const previous = s;
      s = Math.min(
        o.cusumCap,
        Math.max(0, s + clip(z[t], -o.zClip, o.zClip) - o.cusumK),
      );
      if (s === 0) st = -1;
      else if (previous === 0) st = t;
      S[t] = s;
      start[t] = st;
    }
    return { S, start };
  }
  function rolling(z, win, fn) {
    const out = Array(z.length).fill(NaN);
    for (let t = win - 1; t < z.length; t++) {
      const w = z.slice(t - win + 1, t + 1).filter(fin);
      if (w.length >= 0.8 * win) out[t] = fn(w);
    }
    return out;
  }
  function flowStats(bars, o) {
    const per = Math.round(60 / o.stepMin),
      w = o.flowHours * per,
      day = 24 * per,
      lag = o.lagDays * day,
      base = o.baseDays * day,
      net = bars.map((b) =>
        fin(b.takerBuy) && fin(b.total) ? 2 * b.takerBuy - b.total : NaN,
      ),
      tot = bars.map((b) => (fin(b.total) ? b.total : NaN)),
      lr = bars.map((b, i) =>
        i && fin(b.close) && fin(bars[i - 1].close)
          ? Math.abs(Math.log(b.close / bars[i - 1].close))
          : NaN,
      ),
      N = prefix(net),
      T = prefix(tot),
      L = prefix(lr),
      n = bars.length,
      imb = Array(n).fill(NaN),
      illiq = imb.slice(),
      absorb = imb.slice(),
      drift = imb.slice();
    for (let t = w; t < n; t++) {
      const total = T(t - w + 1, t + 1);
      if (total.cnt < 0.8 * w || !(total.sum > 0)) continue;
      imb[t] = N(t - w + 1, t + 1).sum / total.sum;
      illiq[t] = L(t - w + 1, t + 1).sum / total.sum;
      const p0 = bars[t - w].close,
        p1 = bars[t].close;
      if (fin(p0) && fin(p1)) drift[t] = Math.log(p1 / p0);
    }
    let ref = NaN;
    for (let t = lag + base; t < n; t++) {
      if (!fin(ref) || t % day === 0) {
        const v = [];
        for (let j = t - lag - base; j < t - lag; j += 4 * per)
          v.push(illiq[j]);
        ref = median(v);
      }
      if (fin(ref) && illiq[t] > 0) absorb[t] = ref / illiq[t];
    }
    return { imb, absorb, drift };
  }
  function detectSustainedVolume(
    raw,
    options = {},
    requireMarketCoverage = false,
  ) {
    const o = { ...recognitionDefaults, ...options },
      bars = align(raw, o.stepMin),
      per = Math.round(60 / o.stepMin),
      lx = (v) => (fin(v) && v >= 0 ? Math.log1p(v) : NaN),
      rawZ = seasonalRobustZ(
        bars.map((b) => lx(b.total)),
        o,
      ),
      adjusted = o.useMarket
        ? removeMarket(
            rawZ,
            seasonalRobustZ(
              bars.map((b) => lx(b.market)),
              o,
            ),
            o,
            requireMarketCoverage,
          )
        : [],
      marketApplied = [];
    let marketSeen = false;
    const z = rawZ.map((value, i) => {
      // Unlike a whole-array `some(market)` check, future market availability
      // cannot retroactively switch earlier points into market-adjusted mode.
      marketSeen ||= o.useMarket && fin(bars[i].market);
      marketApplied.push(marketSeen);
      return marketSeen ? adjusted[i] : value;
    });
    const { S, start } = recognitionCusum(z, o),
      duty = rolling(
        z,
        o.dutyHours * per,
        (w) => w.filter((v) => v > o.dutyZ).length / w.length,
      ),
      floor = rolling(z, o.floorHours * per, (w) => quantile(w, o.floorQ)),
      { imb, absorb, drift } = flowStats(bars, o);
    let on = false;
    const rows = bars.map((b, t) => {
      if (!on)
        on = S[t] > o.cusumH && duty[t] > o.dutyTh && floor[t] > o.floorTh;
      else on = S[t] > o.cusumH / 2;
      return {
        time: b.time,
        z: nullable(z[t]),
        S: S[t],
        duty: nullable(duty[t]),
        floor: nullable(floor[t]),
        imb: nullable(imb[t]),
        absorb: nullable(absorb[t]),
        drift: nullable(drift[t]),
        regime: on,
        accumulate:
          on &&
          absorb[t] > o.absorbTh &&
          Math.abs(drift[t]) < o.driftTh &&
          imb[t] > o.imbTh,
        changeAt: start[t] >= 0 ? bars[start[t]].time : null,
        marketApplied: marketApplied[t],
      };
    });
    const events = [];
    rows.forEach((r, t) => {
      const previous = t ? rows[t - 1].regime : false;
      if (r.regime && !previous)
        events.push({
          changeAt: r.changeAt,
          confirmAt: r.time,
          endAt: null,
          accumulate: false,
          peakS: 0,
        });
      if (r.regime) {
        const e = events.at(-1);
        e.endAt = r.time;
        e.peakS = Math.max(e.peakS, r.S);
        if (r.accumulate) e.accumulate = true;
      }
    });
    return { rows, events };
  }
  // v3 reuses the v2 math with its stricter market-coverage gate. Existing v2
  // callers retain the original gate and therefore their original chart values.
  const volumeRecognitionInternals = {
    align,
    seasonalRobustZ,
    removeMarket,
    rolling,
    median,
    quantile,
  };

  return {
    detectSustainedVolume,
    recognitionCusum,
    volumeRecognitionInternals,
    RECOGNITION_VERSION,
  };
})();
export const { detectSustainedVolume, recognitionCusum, RECOGNITION_VERSION } =
  v2;
const I = v2.volumeRecognitionInternals;
const v3 = (() => {
  const REEXPANSION_VERSION = "sustained-volume-reexpansion-v3-2026-11-16";
  const valid = (v) => typeof v === "number" && Number.isFinite(v);
  const nullable = (v) => (valid(v) ? v : null);
  function detectReexpansion(raw, options = {}) {
    const o = { ...reexpansionDefaults, ...options },
      per = Math.round(60 / o.stepMin),
      v2 = detectSustainedVolume(raw, o, true),
      bars = I.align(raw, o.stepMin),
      lx = (v) => (valid(v) && v >= 0 ? Math.log1p(v) : NaN),
      so = { ...o, lagDays: 0, baseDays: o.shortDays },
      shortRaw = I.seasonalRobustZ(
        bars.map((b) => lx(b.total)),
        so,
      ),
      shortAdjusted = o.useMarket
        ? I.removeMarket(
            shortRaw,
            I.seasonalRobustZ(
              bars.map((b) => lx(b.market)),
              so,
            ),
            so,
            true,
          )
        : [];
    let seenMarket = false;
    const shortMarketApplied = [],
      zs = shortRaw.map((z, i) => {
        seenMarket ||= o.useMarket && valid(bars[i].market);
        shortMarketApplied.push(seenMarket);
        return seenMarket ? shortAdjusted[i] : z;
      });
    // Public JSON nulls are missing samples, never the valid zero in -null.
    const zl = v2.rows.map((r) => r.z ?? NaN),
      Sshort = recognitionCusum(zs, {
        ...o,
        cusumK: o.shortK,
        cusumCap: 3 * o.shortH,
      }).S,
      Sdn = recognitionCusum(
        zl.map((v) => -v),
        { ...o, cusumK: o.dnK, cusumCap: 3 * o.dnH },
      ).S,
      dutyS = I.rolling(
        zs,
        o.shortDutyHours * per,
        (w) => w.filter((v) => v > o.dutyZ).length / w.length,
      ),
      floorS = I.rolling(zs, o.shortFloorHours * per, (w) =>
        I.quantile(w, o.floorQ),
      ),
      zl24 = I.rolling(zl, 24 * per, I.median),
      armBars = o.armDays * 24 * per;
    let lastContraction = -Infinity,
      alerted = false,
      upgraded = false,
      shortOn = false,
      low = Infinity,
      accShown = false;
    const rows = v2.rows.map((r, t) => {
      const contraction = Sdn[t] > o.dnH;
      if (contraction) {
        if (t - lastContraction > armBars) {
          alerted = false;
          upgraded = false;
          low = Infinity;
        }
        lastContraction = t;
      }
      const armed = t - lastContraction <= armBars;
      if (armed && valid(zl24[t])) low = Math.min(low, zl24[t]);
      if (!shortOn)
        shortOn =
          Sshort[t] > o.shortH &&
          dutyS[t] > o.shortDutyTh &&
          floorS[t] > o.shortFloorTh;
      else shortOn = Sshort[t] > o.shortH / 2;
      let alert = false,
        upgrade = false;
      if (armed && shortOn && !alerted) {
        alert = true;
        alerted = true;
      }
      if (
        alerted &&
        !upgraded &&
        shortOn &&
        zl24[t] - low >= o.upgradeRise &&
        r.imb !== null &&
        r.imb > o.upgradeImb
      ) {
        upgrade = true;
        upgraded = true;
      }
      const longConfirm = r.regime && !(t && v2.rows[t - 1].regime);
      if (longConfirm) accShown = false;
      const accumulateSignal = r.accumulate && !accShown;
      if (accumulateSignal) accShown = true;
      return {
        ...r,
        zShort: nullable(zs[t]),
        Sshort: Sshort[t],
        Sdn: Sdn[t],
        dutyS: nullable(dutyS[t]),
        floorS: nullable(floorS[t]),
        zl24: nullable(zl24[t]),
        rise: nullable(zl24[t] - low),
        contraction,
        armed,
        shortOn,
        alert,
        upgrade,
        alerted,
        upgraded,
        longConfirm,
        accumulateSignal,
        shortMarketApplied: shortMarketApplied[t],
      };
    });
    const events = rows.flatMap((r) => {
      const events = [];
      if (r.alert) events.push({ type: "alert", time: r.time });
      if (r.upgrade) events.push({ type: "upgrade", time: r.time });
      if (r.longConfirm) events.push({ type: "longConfirm", time: r.time });
      if (r.accumulateSignal) events.push({ type: "accumulate", time: r.time });
      return events;
    });
    return { rows, events, options: o };
  }

  return { detectReexpansion, REEXPANSION_VERSION };
})();
export const { detectReexpansion, REEXPANSION_VERSION } = v3;
export function reexpansionState(p) {
  if (p.regime) return "长基准持续放量";
  if (p.shortOn && p.alerted)
    return p.upgraded ? "再放量・已升级" : "再放量・预警";
  if (p.contraction) return "缩量中";
  if (p.armed) return "布防中";
  return p.shortOn
    ? "短期放量（未布防）"
    : p.zShort === null && p.z === null
      ? "基准预热 / 数据不足"
      : "正常";
}
```
