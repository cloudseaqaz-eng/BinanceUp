import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {resolve} from 'node:path';
import {BinanceClient,parseQuery} from './lib/binance.js';
import {computeView} from './lib/metrics.js';

const publicDir=new URL('./public/',import.meta.url);
const defaults={symbol:'BTCUSDT',beforeDays:21,afterDays:7,interval:'3m',emaPeriods:[9,21,55]};
export function createServer({client=new BinanceClient(),now=Date.now}={}){
  const jobs=new Map();
  const cleanup=setInterval(()=>{for(const [id,job] of jobs)if(Date.now()-job.updated>15*60000){job.controller.abort();jobs.delete(id);}},60000);cleanup.unref();
  const server=http.createServer(async(req,res)=>{
    const send=(status,value,type='application/json; charset=utf-8')=>{res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'"});res.end(type.startsWith('application/json')?JSON.stringify(value):value);};
    try{
      const url=new URL(req.url,'http://localhost');
      if(req.method==='GET'&&url.pathname==='/api/config')return send(200,{defaults,now:now()});
      if(req.method==='POST'&&url.pathname==='/api/jobs'){
        if(req.headers.origin&&req.headers.origin!==`http://${req.headers.host}`)return send(403,{error:'仅允许从本机页面查询。'});
        let body='';for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>4096)return send(413,{error:'请求过大'});}
        const query=parseQuery(JSON.parse(body),now());
        if([...jobs.values()].filter(j=>j.status==='running').length>=2)return send(429,{error:'已有两项查询正在运行，请取消或等待完成。'});
        for(const [id,j] of jobs)if(j.status!=='running')jobs.delete(id);
        const id=randomUUID(),job={status:'running',progress:{completed:0,total:0,message:'准备API查询…'},controller:new AbortController(),updated:Date.now()};jobs.set(id,job);
        send(202,{id});
        (async()=>{
          try{
            const rows=await client.load(query,{signal:job.controller.signal,onProgress:p=>{job.progress=p;job.updated=Date.now();}});
            job.controller.signal.throwIfAborted();
            if(!rows.length)throw Error('这个时段没有可用的币安现货K线，请检查交易对和上市时间。');
            job.progress={...job.progress,message:'正在计算3分钟K线、EMA和活跃积分…'};
            const view=computeView(rows,query);
            const warnings=[];
            if(query.end<query.requestedEnd)warnings.push('后窗超出当前时间，已截到最近已收盘分钟。');
            if(view.metaMetrics.missingMinutes)warnings.push('API历史中存在缺失或无效分钟，相关曲线留空。');
            if(!view.metaMetrics.anchorPrice)warnings.push('观察时间之前没有有效价格，请手动设置纵轴中心价，或选择上市后的观察时间。');
            if(!view.scores.some(s=>s.buyScore!==null||s.tradeScore!==null))warnings.push('有效历史不足，积分暂无法显示：需要至少14天预热及99%加权覆盖率。');
            if(!view.candles.some(c=>Number.isFinite(c.close)))throw Error('显示窗口内没有完整的3分钟K线。');
            job.result={symbol:query.symbol,at:query.at,start:query.start,end:query.end,interval:'3m',candles:view.candles,scores:view.scores,meta:{...view.metaMetrics,source:client.base||'Binance API',requestedEnd:query.requestedEnd,latestClosedMinute:query.latestClosedMinute,historyDays:28,emaPeriods:query.emaPeriods,warnings}};
            job.status='done';job.progress={...job.progress,message:'查询完成'};
          }catch(e){job.status='error';job.error=job.controller.signal.aborted?'查询已取消。':e.message||'查询失败';}
          job.updated=Date.now();
        })();return;
      }
      const match=/^\/api\/jobs\/([a-f0-9-]+)$/.exec(url.pathname);
      if(match){const job=jobs.get(match[1]);if(!job)return send(404,{error:'查询已过期，请重新查询。'});if(req.method==='DELETE'){job.controller.abort();jobs.delete(match[1]);return send(200,{ok:true});}if(req.method==='GET')return send(200,{status:job.status,progress:job.progress,...(job.result?{result:job.result}:{}),...(job.error?{error:job.error}:{})});}
      if(req.method!=='GET')return send(405,{error:'不支持的方法'});
      const file=url.pathname==='/'?'index.html':url.pathname.slice(1);
      const types={'index.html':'text/html; charset=utf-8','app.css':'text/css; charset=utf-8','app.js':'text/javascript; charset=utf-8','charts.js':'text/javascript; charset=utf-8'};
      if(file==='favicon.ico'){res.writeHead(204);res.end();return;}
      if(!types[file])return send(404,{error:'不存在的路径'});
      send(200,await readFile(new URL(file,publicDir)),types[file]);
    }catch(e){send(400,{error:e.message||'请求失败'});}
  });
  server.on('close',()=>{clearInterval(cleanup);for(const j of jobs.values())j.controller.abort();});
  return server;
}
if(process.argv[1]&&fileURLToPath(import.meta.url)===resolve(process.argv[1])){
  const port=Number(process.env.PORT||8769);const server=createServer();
  server.listen(port,'127.0.0.1',()=>console.log(`打开 http://127.0.0.1:${port} · 币安连续性观察台（API实时读取）`));
  server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'端口被占用，可设置PORT后重新启动。':e.message);process.exitCode=1;});
  process.on('SIGINT',()=>{server.close();server.closeAllConnections();});
}
