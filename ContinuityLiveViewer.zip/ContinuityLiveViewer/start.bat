@echo off
cd /d "%~dp0"
node --use-env-proxy server.js
pause
