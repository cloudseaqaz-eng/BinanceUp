import {themeColor} from './theme.js';
const finite=Number.isFinite;
const stepFor=data=>(data?.recognitionMeta?.stepMinutes||data?.period||15)*60000;
const num=(v,n=2)=>finite(v)?v.toLocaleString('en-US',{maximumFractionDigits:n}):'—';
const pct=v=>finite(v)?num(v*100)+'%':'—';
const fmt=new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false});
export const isRecognition=id=>['recognition-chart','reexpansion-chart','flow-chart'].includes(id);
export function recognitionRow(data,id,t){
 const rows=(id==='recognition-chart'?data?.volumeRecognition:data?.volumeReexpansion)||[],target=Math.floor(t/stepFor(data))*stepFor(data);
 let a=0,b=rows.length;while(a<b){const m=(a+b)>>1;if(rows[m].time<target)a=m+1;else b=m;}return rows[a]?.time===target?rows[a]:null;
}
export function recognitionText(data,id,r){
 if(!r)return '该时刻无对应周期已收盘数据';
 const mode=r.marketApplied?'BTC过滤':'本币基准';
 if(id==='recognition-chart')return `S ${num(r.S)} · Z ${num(r.z)} · 高位占比 ${pct(r.duty)} · 底部 ${num(r.floor)} · ${r.regime?'持续放量':'观察'}${r.accumulate?' · 吸筹条件':''} · ${mode}`;
 if(id==='flow-chart')return `主动买卖不平衡 ${pct(r.imb)} · 吸收强度 ${num(r.absorb)}× · 72小时对数位移 ${pct(r.drift)}`;
 const label=r.regime?'长基准持续放量':r.shortOn&&r.alerted?(r.upgraded?'再放量・已升级':'再放量・预警'):r.contraction?'缩量中':r.armed?'布防中':r.shortOn?'短期放量（未布防）':r.zShort===null&&r.z===null?'基准预热 / 数据不足':'正常';
 return `${label} · S短/长/缩 ${num(r.Sshort)}/${num(r.S)}/${num(r.Sdn)} · Z短/长 ${num(r.zShort)}/${num(r.z)} · 回升 ${num(r.rise)} · ${mode}`;
}
export function drawRecognition(chart,canvas,g,ctx){
 const {w,h,L,R,T,B}=g,id=canvas.id,flow=id==='flow-chart',legacy=id==='recognition-chart',data=chart.data,STEP=stepFor(data);
 const rows=(legacy?data.volumeRecognition:data.volumeReexpansion)||[],meta=data.recognitionMeta||{},o=legacy?meta.recognition:meta.reexpansion;
 if(!o)return;
 const pw=w-L-R,ph=h-T-B,x=t=>L+(t-chart.view[0])/(chart.view[1]-chart.view[0])*pw;
 const low=flow?-100:legacy?0:-3,high=flow?100:legacy?o.cusumCap:3,y=v=>T+(high-v)/(high-low)*ph,yr=v=>T+(1-Math.min(5,Math.max(0,v))/5)*ph;
 Object.assign(canvas.dataset,{yMin:String(low),yMax:String(high),timeStart:String(chart.view[0]),timeEnd:String(chart.view[1]),period:String(STEP/60000),series:flow?'imb,drift,absorb':legacy?'S':'Sshort,S,Sdn',axisMode:flow?'percent-left-absorb-right':legacy?'cusum':'threshold-multiples'});
 if(flow)Object.assign(canvas.dataset,{rightMin:'0',rightMax:'5',absorbCap:'5',driftAxis:'left',driftScale:'percent'});
 ctx.font='11px system-ui';ctx.fillStyle=themeColor('#95a9bc');ctx.strokeStyle=themeColor('#293c4e');ctx.setLineDash([]);
 for(let i=0;i<=4;i++){const v=high-(high-low)*i/4,yy=y(v);ctx.beginPath();ctx.moveTo(L,yy);ctx.lineTo(w-R,yy);ctx.stroke();ctx.textAlign=flow?'right':'left';ctx.fillText(num(v)+(flow?'%':''),flow?L-5:w-R+7,yy+4);if(flow){ctx.textAlign='left';ctx.fillText(num(5*(1-i/4))+'×',w-R+7,yy+4);}}
 const ticks=w>900?4:w>550?3:2;for(let i=0;i<=ticks;i++){const t=chart.view[0]+(chart.view[1]-chart.view[0])*i/ticks;ctx.textAlign=i===0?'left':i===ticks?'right':'center';ctx.fillText(fmt.format(t),x(t),h-6);}ctx.textAlign='left';
 ctx.save();ctx.beginPath();ctx.rect(L,T,pw,ph);ctx.clip();
 const visible=rows.filter(r=>r.time>=chart.view[0]-STEP&&r.time<=chart.view[1]+STEP);
 if(!flow)for(const r of visible){const color=legacy?(r.regime?'rgba(35,167,111,0.10)':null):r.regime?'rgba(39,174,96,0.14)':r.contraction?'rgba(142,91,214,0.12)':r.armed?'rgba(242,183,5,0.16)':null;if(color){ctx.fillStyle=color;ctx.fillRect(x(r.time-STEP/2),T,x(r.time+STEP/2)-x(r.time-STEP/2),ph);}}
 const references=flow?[[0,'0']]:legacy?[[o.cusumH,'确认'],[o.cusumH/2,'保持']]:[[1,'放量'],[.5,'保持'],[-1,'缩量']];
 for(const [v,label] of references){ctx.strokeStyle=themeColor('#94a8bd88');ctx.setLineDash([2,4]);ctx.beginPath();ctx.moveTo(L,y(v));ctx.lineTo(w-R,y(v));ctx.stroke();if(!flow){ctx.fillStyle=themeColor('#94a8bd');ctx.fillText(label,L+3,y(v)-3);}}
 function line(key,color,width,transform=v=>v,toY=y){
  ctx.strokeStyle=themeColor(color);ctx.fillStyle=themeColor(color);ctx.lineWidth=width;ctx.setLineDash([]);let previous=null,points=[];
  const flush=()=>{if(!points.length)return;ctx.beginPath();ctx.moveTo(...points[0]);for(let i=1;i<points.length;i++)ctx.lineTo(...points[i]);if(flow&&points.length===1){ctx.arc(...points[0],1.3,0,2*Math.PI);ctx.fill();}else ctx.stroke();points=[];};
  for(const r of visible){if(!finite(r[key])){flush();previous=null;continue;}if(previous!==null&&r.time-previous!==STEP)flush();points.push([x(r.time),toY(transform(r[key]))]);previous=r.time;}flush();
 }
 if(flow){const width=Math.max(1,Math.min(14,STEP/(chart.view[1]-chart.view[0])*pw*.75));for(const r of visible)if(finite(r.imb)){ctx.fillStyle=themeColor(r.imb>=0?'rgba(38,166,91,0.75)':'rgba(229,72,77,0.75)');ctx.fillRect(x(r.time)-width/2,Math.min(y(0),y(r.imb*100)),width,Math.max(.7,Math.abs(y(0)-y(r.imb*100))));}line('drift',themeColor('#bc95f9'),1,v=>100*v);line('absorb',themeColor('#e08a00'),1,v=>v,yr);}
 else if(legacy)line('S',themeColor('#3977ce'),2);
 else{line('Sshort',themeColor('#2f6fde'),2,v=>Math.min(3,v/o.shortH));line('S',themeColor('#9aa3ae'),1,v=>Math.min(3,v/o.cusumH));line('Sdn',themeColor('#8e5bd6'),1,v=>Math.max(-3,-v/o.dnH));}
 let markerCount=0;const counts={alert:0,upgrade:0,longConfirm:0,accumulate:0};
 function marker(r,label,color,shape,above,baseY){markerCount++;const xx=x(r.time),yy=baseY+(above?-12:12);ctx.fillStyle=color;ctx.strokeStyle=color;ctx.lineWidth=1;ctx.setLineDash([]);ctx.beginPath();if(shape==='circle')ctx.arc(xx,yy,3,0,2*Math.PI);else if(shape==='square')ctx.rect(xx-3,yy-3,6,6);else{const direction=shape==='down'?-1:1;ctx.moveTo(xx,yy-4*direction);ctx.lineTo(xx-3,yy+3*direction);ctx.lineTo(xx+3,yy+3*direction);ctx.closePath();}ctx.fill();ctx.font='9px system-ui';ctx.textAlign='center';ctx.fillText(label,xx,yy+(above?-6:13));ctx.textAlign='left';}
 if(!flow)for(const r of visible){if(r.time<chart.view[0]||r.time>chart.view[1])continue;if(legacy){const index=rows.indexOf(r),prev=index?rows[index-1]:meta.priorPoint,acc=r.accumulate&&!prev?.accumulate,confirm=r.regime&&!prev?.regime,above=r.S<=o.cusumCap*2/3;if(acc||confirm)marker(r,acc?'吸筹':'确认',acc?themeColor('#8e5bd6'):themeColor('#27ae60'),above?'down':'arrow',above,y(r.S));}
  else{let top=0,bottom=0;for(const [key,label,color,shape,above] of [['alert','预警',themeColor('#f2a900'),'arrow',true],['upgrade','升级',themeColor('#e5484d'),'arrow',true],['longConfirm','长确认',themeColor('#27ae60'),'circle',false],['accumulateSignal','吸筹',themeColor('#8e5bd6'),'square',false]])if(r[key]){counts[key==='accumulateSignal'?'accumulate':key]++;marker(r,label,color,shape,above,y(0)+(above?-16*top++:16*bottom++));}}}
 Object.assign(canvas.dataset,{markers:String(markerCount),eventCounts:JSON.stringify(counts)});
 ctx.lineWidth=1;for(const [t,color] of [[data.at,themeColor('#5caaff')],[chart.cursor,themeColor('#cbd8e7')]]){if(t===null||t<chart.view[0]||t>chart.view[1])continue;ctx.strokeStyle=color;ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(x(t),T);ctx.lineTo(x(t),h-B);ctx.stroke();}ctx.restore();ctx.lineWidth=1;
}
