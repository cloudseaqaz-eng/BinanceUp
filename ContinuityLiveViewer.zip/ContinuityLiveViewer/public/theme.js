const lightColors={
 '#95a9bc':'#52657e','#293c4e':'#dce3ec','#94a8bd':'#65758a','#cbd8e7':'#52657e',
 '#5caaff':'#2463c5','#efc15d':'#9b6500','#f3be58':'#a16a00','#bc95f9':'#8050c7',
 '#6bd7cb':'#007f70','#22c68e':'#139369','#ef5b6a':'#d94455','#c1d5eb':'#2563eb',
 '#3977ce':'#2c69b9','#2f6fde':'#2563eb','#9aa3ae':'#697586','#8e5bd6':'#7c3dbd',
 '#27ae60':'#15803d','#e5484d':'#cc3442','#f2a900':'#9a6500','#e08a00':'#ad6500',
};
export function themeColor(value){
 if(document.documentElement.dataset.theme==='dark')return value;
 if(value==='#c1d5eb05')return '#2563eb08';
 if(value==='rgba(38,166,91,0.75)')return 'rgba(16,133,77,0.75)';
 if(value==='rgba(229,72,77,0.75)')return 'rgba(205,48,66,0.75)';
 const match=/^(#[a-f\d]{6})([a-f\d]{2})?$/i.exec(value);
 return match&&lightColors[match[1].toLowerCase()]?lightColors[match[1].toLowerCase()]+(match[2]||''):value;
}
export function initializeTheme(redraw){
 const select=document.querySelector('#theme-select');
 const apply=(theme,persist)=>{
  const value=theme==='dark'?'dark':'light';document.documentElement.dataset.theme=value;select.value=value;
  if(persist)try{localStorage.setItem('viewer-theme',value);}catch{}
  redraw();
 };
 apply(document.documentElement.dataset.theme,false);
 select.addEventListener('change',()=>apply(select.value,true));
 window.addEventListener('storage',event=>{if(event.key==='viewer-theme')apply(event.newValue,false);});
}
