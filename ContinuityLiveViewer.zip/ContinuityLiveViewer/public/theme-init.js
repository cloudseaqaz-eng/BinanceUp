// Apply the saved preference before CSS paints. New visitors default to light.
(()=>{let theme='light';try{const saved=localStorage.getItem('viewer-theme');if(saved==='dark'||saved==='light')theme=saved;}catch{}document.documentElement.dataset.theme=theme;})();
