#!/bin/bash
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "请先安装 Node.js 18.17 或更新版本，然后重新运行。"
  read -r -p "按回车退出"
  exit 1
fi
node start.cjs
read -r -p "服务已停止，按回车退出"
