from pathlib import Path
import tempfile,unittest,hashlib
from unittest.mock import patch
import numpy as np,pandas as pd
from continuity_app.core import *


def candles(n=6000,start='2026-01-01T00:01Z'):
    ix=pd.date_range(start,periods=n,freq='min',name='time')
    return pd.DataFrame({'open':100.,'high':100.,'low':100.,'close':100.,'quote':0.,'trades':0.,'taker_quote':0.},index=ix)


def signal_data(n=6000,s=1600,length=200):
    r=candles(n);r.iloc[s:s+length,r.columns.get_loc('trades')]=1
    r.iloc[s:s+length,r.columns.get_loc('quote')]=1000
    r.iloc[s:s+length,r.columns.get_loc('taker_quote')]=500
    return r


class SignalTests(unittest.TestCase):
    def opt(self,**kwargs):return Options(holds=(5,15),**kwargs)
    def test_confirmation_duration_and_frozen_background(self):
        r=signal_data();runs,events,audit=analyze(r,'测试USDT',self.opt())
        hit=next(e for e in events if e['kind']=='buy' and e['hold']==15)
        self.assertEqual(hit['start_ms'],ms(r.index[1600]))
        self.assertEqual(hit['confirm_ms'],ms(r.index[1618]))
        self.assertEqual(hit['bg_mean'],0);self.assertEqual(hit['bg_full'],0)
        self.assertEqual(hit['bg_ok'],1)
        self.assertEqual(audit['invalid_minutes'],0)
    def test_high_not_close_and_reference_semantics(self):
        r=signal_data();r.iloc[1650,r.columns.get_loc('high')]=125
        r.iloc[1599,r.columns.get_loc('close')]=90;r.iloc[1599,r.columns.get_loc('low')]=90
        _,events,_=analyze(r,'TESTUSDT',self.opt())
        e=next(e for e in events if e['kind']=='buy' and e['hold']==15)
        self.assertEqual(e['price_before'],90);self.assertEqual(e['price_confirm'],100)
        self.assertEqual(e['hit_confirm_20'],1);self.assertEqual(e['hit_confirm_30'],0)
        self.assertEqual(e['hit_before_30'],1)
        self.assertEqual(e['future_max_close'],100)
        self.assertEqual(e['minutes20_confirm'],32)
    def test_signal_candle_high_is_excluded_and_future_boundary_included(self):
        r=signal_data();i=1618
        r.iloc[i,r.columns.get_loc('high')]=150
        _,events,_=analyze(r,'T',self.opt())
        e=next(e for e in events if e['hold']==15)
        self.assertEqual(e['hit_confirm_20'],0)
        r.iloc[i+1440,r.columns.get_loc('high')]=125
        _,events,_=analyze(r,'T',self.opt())
        self.assertEqual(next(e for e in events if e['hold']==15)['hit_confirm_20'],1)
    def test_missing_future_unknown_and_input_gap_resets(self):
        r=signal_data();r=r.drop(r.index[1700])
        runs,events,_=analyze(r,'T',self.opt())
        e=next(e for e in events if e['hold']==15)
        self.assertIsNone(e['hit_confirm_20']);self.assertEqual(e['future_complete'],0)
        self.assertEqual(max(x['end_ms'] for x in runs if x['start_ms']==ms(r.index[1600])),ms(pd.Timestamp('2026-01-02T04:20Z')))
        short=signal_data(n=1800)
        _,events,_=analyze(short,'T',self.opt())
        self.assertTrue(all(e['hit_confirm_20'] is None for e in events))
    def test_future_mutation_does_not_change_background_or_confirmation(self):
        r=signal_data();_,a,_=analyze(r,'T',self.opt())
        r.iloc[1800:,r.columns.get_loc('high')]=150
        _,b,_=analyze(r,'T',self.opt())
        for x,y in zip(a,b):
            for k in ['start_ms','confirm_ms','bg_mean','bg_full','bg_ok','r60','dd24']:self.assertEqual(x[k],y[k])
    def test_never_active_and_history_insufficient(self):
        r=candles();runs,events,_=analyze(r,'T',self.opt());self.assertEqual(runs,[])
        r=signal_data(s=10);_,events,_=analyze(r,'T',self.opt());self.assertTrue(all(not e['bg_ok'] for e in events))


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.data=self.root/'input';(self.data/'raw').mkdir(parents=True);self.output=self.root/'results'
        self.raw=signal_data();self.raw.iloc[1650,self.raw.columns.get_loc('high')]=125
        self.path=self.data/'raw/牛来USDT.parquet';self.raw.to_parquet(self.path)
        self.digest=hashlib.sha256(self.path.read_bytes()).hexdigest()
        self.meta=build(self.data,self.output,Options(holds=(15,)),progress=lambda s:None);self.store=Store(self.output)
    def tearDown(self):self.tmp.cleanup()
    def test_cache_reuse_and_readonly_inputs(self):
        with patch('continuity_app.core.read_raw',side_effect=RuntimeError('should reuse')):
            meta=build(self.data,self.output,Options(holds=(15,)),progress=lambda s:None)
        self.assertEqual(meta['errors'],[])
        self.assertEqual(hashlib.sha256(self.path.read_bytes()).hexdigest(),self.digest)
        with self.assertRaises(ValueError):build(self.data,self.data/'bad',Options())
    def test_snapshot_sorted_and_no_future_until_revealed(self):
        t=self.raw.index[1630]
        view=self.store.snapshot(t,hold=15)
        self.assertEqual(len(view['rows']),1);self.assertEqual(view['rows'][0]['duration'],27)
        self.assertNotIn('future',view['rows'][0])
        view2=self.store.snapshot(t,hold=15,reveal=True)
        self.assertTrue(view2['rows'][0]['future']['confirm']['hit20'])
        self.assertEqual(self.store.snapshot(self.raw.index[1617],hold=15)['rows'],[])
    def test_dedup_superset_types_and_outcomes(self):
        result=self.store.summary(15)
        self.assertEqual(result['candidates'],2);self.assertEqual(result['deduplicated'],1)
        self.assertEqual(set(result['events'][0]['kinds']),{'buy','trade'})
        cell=next(c for c in result['cells'] if c['target']==20)
        self.assertEqual(cell['success'],1);self.assertEqual(cell['n'],1)
        self.assertEqual(self.store.summary(15,kind='buy')['deduplicated'],1)
    def test_detail_windows_and_no_future_default(self):
        t=self.raw.index[1630]
        d=self.store.detail('牛来USDT',t,before=336,after=0,period=5)
        self.assertEqual(d['start_ms'],ms(t)-336*3600000)
        self.assertTrue(all(x['ms']<=ms(t) for x in d['candles']))
        d2=self.store.detail('牛来USDT',t,before=168,after=168,period=3)
        self.assertEqual(d2['end_ms'],ms(self.raw.index[-1]))
        self.assertTrue(any(x['ms']>ms(t) for x in d2['candles']))
        with self.assertRaises(ValueError):self.store.detail('../nope',t)
    def test_source_change_is_not_silently_reused(self):
        self.path.touch()
        with self.assertRaises(ValueError):self.store.snapshot(self.raw.index[1630],hold=15)

    def test_original_config_naive_dates_are_utc_and_cli_dates_are_beijing(self):
        (self.data/'config.json').write_text(json.dumps({'start':'2026-01-02','end':'2026-01-04'}))
        meta=build(self.data,self.output,Options(holds=(15,)),progress=lambda s:None)
        self.assertEqual(meta['start_ms'],ms('2026-01-02T00:00:00Z'))
        self.assertEqual(ms('2026-01-02 08:00'),ms('2026-01-02T00:00:00Z'))

    def test_cooldown_prevents_repeated_outcome_counting(self):
        # Add a new qualifying burst inside 24h; all confirmations remain auditable,
        # while the combined probability counts only the first event.
        data=signal_data(length=60)
        for start in (1800,3400):
            data.iloc[start:start+60,data.columns.get_loc('trades')]=1
            data.iloc[start:start+60,data.columns.get_loc('quote')]=1000
            data.iloc[start:start+60,data.columns.get_loc('taker_quote')]=500
        data.to_parquet(self.path)
        build(self.data,self.output,Options(holds=(15,),background_minutes=60),progress=lambda s:None)
        result=self.store.summary(15)
        self.assertEqual(result['candidates'],6)
        self.assertEqual(result['deduplicated'],2)

    def test_stat_source_rebuild_and_zero_freshness_unlimited(self):
        view=self.store.snapshot(self.raw.index[1650],hold=15,fresh_hours=0)
        self.assertEqual(len(view['rows']),1)
        self.raw.to_parquet(self.path)
        with self.assertRaises(ValueError):self.store.summary(15)

    def test_snapshot_does_not_reveal_or_depend_on_future_run_end(self):
        t=self.raw.index[1630]
        before=self.store.snapshot(t,hold=15)
        self.assertNotIn('end_ms',before['rows'][0])
        self.raw.iloc[1631:,self.raw.columns.get_loc('trades')]=0
        self.raw.iloc[1631:,self.raw.columns.get_loc('taker_quote')]=0
        self.raw.iloc[1631:,self.raw.columns.get_loc('high')]=200
        self.raw.to_parquet(self.path)
        build(self.data,self.output,Options(holds=(15,)),progress=lambda s:None)
        after=self.store.snapshot(t,hold=15)
        self.assertEqual(before,after)
        detail=self.store.detail('牛来USDT',t)
        self.assertTrue(all('end_ms' not in x for x in detail['signals']))

    def test_report_only_parameters_reuse_calculation_cache(self):
        with patch('continuity_app.core.read_raw',side_effect=RuntimeError('must reuse')):
            meta=build(self.data,self.output,Options(holds=(15,),cooldown_minutes=360,
                       fresh_hours=24,max_r60=.1,max_dd24=.2),progress=lambda s:None)
        self.assertEqual(meta['errors'],[])
        self.assertEqual(meta['options']['cooldown_minutes'],360)
