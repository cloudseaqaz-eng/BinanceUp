import unittest

import numpy as np
import pandas as pd

from continuity_app.score_speed import metrics, settings


def scores(length=400):
    index = pd.date_range('2026-09-01T00:00Z', periods=length, freq='min', name='time')
    return pd.DataFrame({'buy_score': 30.0, 'trade_score': 50.0}, index=index)


class ScoreSpeedTests(unittest.TestCase):
    def test_ramps_have_same_hourly_units_for_both_windows(self):
        source = scores()
        source.buy_score += np.arange(len(source)) * .01
        source.trade_score -= np.arange(len(source)) * .02
        original = source.copy(deep=True)
        for window in (30, 60):
            actual = metrics(source, window)
            self.assertTrue(actual.iloc[:window].isna().all().all())
            np.testing.assert_allclose(actual.buy_speed_raw.iloc[window:], .6, atol=1e-12)
            np.testing.assert_allclose(actual.buy_speed.iloc[window:], .6, atol=1e-12)
            np.testing.assert_allclose(actual.trade_speed.iloc[window:], -1.2, atol=1e-12)
        pd.testing.assert_frame_equal(source, original, check_exact=True)

    def test_constant_scores_including_boundaries_have_zero_speed(self):
        source = scores()
        source.buy_score = 100.0
        source.trade_score = 0.0
        actual = metrics(source)
        self.assertTrue(actual.iloc[30:].eq(0).all().all())

    def test_reversal_smoothing_matches_independent_weighted_history(self):
        source = scores()
        source.buy_score = 30.0 + .01 * np.abs(np.arange(len(source)) - 150)
        actual = metrics(source, 30, 5)
        alpha = 1 - 2 ** (-1 / 5)
        # Direct finite weighted sum, independent of pandas EWM/segment logic.
        for position in (30, 149, 165, 170, 180, 220):
            raw = actual.buy_speed_raw.iloc[30:position + 1].to_numpy()
            ages = np.arange(len(raw) - 1, -1, -1)
            weights = alpha * (1 - alpha) ** ages
            weights[0] = (1 - alpha) ** (len(raw) - 1)
            self.assertAlmostEqual(actual.buy_speed.iloc[position], float(np.dot(raw, weights)), places=12)
        first_raw_positive = np.flatnonzero(actual.buy_speed_raw.to_numpy() > 1e-10)[0]
        first_smooth_positive = np.flatnonzero(actual.buy_speed.to_numpy() > 1e-10)[0]
        self.assertGreater(first_smooth_positive, first_raw_positive)

    def test_five_minute_half_life_means_error_halves_in_five_minutes(self):
        source = scores()
        # Raw speed moves from 0 to 0.6 over 30 minutes, then stays 0.6.
        source.buy_score += np.maximum(np.arange(len(source)) - 100, 0) * .01
        actual = metrics(source)
        residual = .6 - actual.buy_speed.iloc[130]
        self.assertGreater(residual, 0)
        self.assertAlmostEqual(.6 - actual.buy_speed.iloc[135], residual / 2, places=12)

    def test_gap_invalidates_interior_and_resets_ema_at_recovery(self):
        source = scores()
        source.buy_score = 30.0 - .01 * np.minimum(np.arange(len(source)), 100)
        source.loc[source.index[101]:, 'buy_score'] = 29 + .02 * np.arange(len(source) - 101)
        source.loc[source.index[100], 'buy_score'] = np.nan
        actual = metrics(source)
        self.assertTrue(actual[['buy_speed_raw', 'buy_speed']].iloc[100:131].isna().all().all())
        self.assertAlmostEqual(actual.buy_speed.iloc[99], -.6, places=12)
        self.assertAlmostEqual(actual.buy_speed_raw.iloc[131], 1.2, places=12)
        self.assertEqual(actual.buy_speed.iloc[131], actual.buy_speed_raw.iloc[131])
        self.assertTrue(actual.trade_speed.iloc[30:].eq(0).all())

    def test_nonfinite_scores_are_unknown_not_zero(self):
        for bad in (np.nan, np.inf, -np.inf):
            with self.subTest(bad=bad):
                source = scores(150)
                source.loc[source.index[80], 'buy_score'] = bad
                actual = metrics(source, 30, 0)
                self.assertTrue(actual.buy_speed.iloc[80:111].isna().all())
                self.assertEqual(actual.buy_speed.iloc[111], 0)

    def test_zero_half_life_returns_raw_without_changes(self):
        source = scores()
        source.buy_score = 30 + np.sin(np.arange(len(source)) / 7)
        source.iloc[200:202] = np.nan
        actual = metrics(source, 60, 0)
        np.testing.assert_array_equal(actual.buy_speed, actual.buy_speed_raw)
        np.testing.assert_array_equal(actual.trade_speed, actual.trade_speed_raw)

    def test_future_extension_or_mutation_cannot_change_prior_values(self):
        source = scores(900)
        source.buy_score = 30 + np.sin(np.arange(len(source)) / 50)
        source.trade_score = 50 + np.cos(np.arange(len(source)) / 75)
        source.iloc[250:253] = np.nan
        for window in (30, 60):
            prefix = metrics(source.iloc[:600], window, 10)
            full = metrics(source, window, 10)
            pd.testing.assert_frame_equal(prefix, full.iloc[:600], check_exact=True)
            altered = source.copy()
            altered.iloc[600:] = [100, np.nan]
            pd.testing.assert_frame_equal(prefix, metrics(altered, window, 10).iloc[:600], check_exact=True)

    def test_channels_are_independent(self):
        source = scores()
        source.buy_score += np.arange(len(source)) * .01
        original = metrics(source)
        source.trade_score = np.nan
        changed = metrics(source)
        pd.testing.assert_frame_equal(original[['buy_speed', 'buy_speed_raw']], changed[['buy_speed', 'buy_speed_raw']], check_exact=True)
        self.assertTrue(changed[['trade_speed', 'trade_speed_raw']].isna().all().all())

    def test_empty_short_and_unknown_histories(self):
        self.assertTrue(metrics(scores(0)).empty)
        self.assertTrue(metrics(scores(30)).isna().all().all())
        source = scores()
        source.iloc[:] = np.nan
        self.assertTrue(metrics(source).isna().all().all())

    def test_parameters_and_minute_grid_are_validated(self):
        source = scores()
        for window, half_life in ((15, 5), (30, -1), (60, 15)):
            with self.assertRaises(ValueError):
                metrics(source, window, half_life)
        for invalid in (source.iloc[::2], source.iloc[::-1], source.reset_index(drop=True), source.drop(source.index[100])):
            with self.assertRaises(ValueError):
                metrics(invalid)
        self.assertEqual(settings(60, 10)['unit'], 'score_points_per_hour')


if __name__ == '__main__':
    unittest.main()
