"""Optional Chromium checks against isolated synthetic data, never real prediction evidence."""
import asyncio,json,sys,threading,tempfile
from pathlib import Path
from http.server import ThreadingHTTPServer
from urllib.parse import quote
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pandas as pd
from continuity_app.core import Options,build,Store
from continuity_app.server import handler


async def run(output):
    from playwright.async_api import async_playwright
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    checks=[];errors=[]
    def check(name,ok):
        checks.append({'check':name,'passed':bool(ok)});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);data=root/'input';(data/'raw').mkdir(parents=True);result=root/'result'
        ix=pd.date_range('2026-08-25T00:01Z',periods=35*1440,freq='min',name='time');at=ix[25000]
        for symbol,offset in [('AAAUSDT',60),('牛来USDT',120)]:
            r=pd.DataFrame({'open':100.,'high':100.,'low':100.,'close':100.,'quote':0.,'trades':0.,'taker_quote':0.},index=ix)
            a=25000-offset
            r.loc[ix[a:a+720],['quote','trades','taker_quote']]=[1000.,1.,500.]
            r.loc[ix[25300],'high']=125.
            r.to_parquet(data/'raw'/f'{symbol}.parquet')
        build(data,result,Options(start=ix[1440].isoformat(),end=ix[-1].isoformat()),progress=lambda s:None)
        server=ThreadingHTTPServer(('127.0.0.1',0),handler(Store(result)))
        threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}'
        try:
            async with async_playwright() as pw:
                browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
                page=await browser.new_page(viewport={'width':1500,'height':1000},device_scale_factor=2)
                page.on('pageerror',lambda e:errors.append(str(e)))
                external=[];page.on('request',lambda r:external.append(r.url) if not r.url.startswith(base) else None)
                await page.goto(base+'/?at='+quote(at.isoformat()))
                await page.wait_for_selector('#rows a')
                check('three target probabilities with sample counts',await page.locator('#stats .stat').count()==3 and '/' in await page.locator('#stats').inner_text())
                check('historical candidates include both input coins',await page.locator('#rows tr').count()==2)
                check('candidates sorted by uninterrupted duration',await page.locator('#rows tr').first.locator('td').first.inner_text()=='牛来USDT')
                check('future hidden until explicit reveal',await page.locator('#future-th').evaluate("e=>e.classList.contains('hidden')") and await page.locator('#rows .future').count()==0)
                await page.locator('#reveal').check();await page.wait_for_selector('#rows .future')
                check('revealed future uses high-price plus twenty definition',all('达到' in x for x in await page.locator('#rows .future').all_inner_texts()))
                await page.locator('#reference').select_option('before')
                await page.wait_for_timeout(200)
                check('three reference price options available',await page.locator('#reference option').count()==3)
                response=await page.request.get(base+'/api/events.csv?hold=15&kind=any&reference=confirm&price=1')
                check('event CSV exports UTF8 coin names',response.status==200 and '牛来USDT' in await response.text())
                await page.screenshot(path=str(output/'index.png'),full_page=True)
                await page.locator('#rows a').first.click();await page.wait_for_selector('#chart-candles')
                check('Chinese coin detail loads independently', '牛来USDT' in await page.locator('#title').inner_text())
                check('detail hides future initially',await page.evaluate('data.candles.every(r=>r.ms<=data.at_ms)'))
                check('default history is one week',await page.evaluate('data.at_ms-data.start_ms===168*3600000'))
                async with page.expect_response(lambda r:'/api/detail?' in r.url and 'before=336' in r.url):await page.locator('#before').select_option('336')
                await page.wait_for_function('data.at_ms-data.start_ms===336*3600000 && !document.querySelector("#reload").disabled')
                check('two week history supported',await page.evaluate('data.candles.length>=4032'))
                async with page.expect_response(lambda r:'/api/detail?' in r.url and 'after=168' in r.url):await page.locator('#after').select_option('168')
                await page.wait_for_function('data.end_ms-data.at_ms===168*3600000 && !document.querySelector("#reload").disabled')
                check('one week future reveals on demand',await page.evaluate('data.candles.some(r=>r.ms>data.at_ms)'))
                await page.locator('#chart-candles').hover(position={'x':380,'y':100})
                check('candle tooltip includes OHLC and change','Change' in await page.locator('#tooltip').inner_text())
                check('all chart cursor times align',await page.evaluate("document.querySelector('#read-candles').textContent.split(' · ')[0]===document.querySelector('#read-buy').textContent.split(' · ')[0]"))
                await page.mouse.move(1,1);await page.screenshot(path=str(output/'detail.png'),full_page=True)
                await page.set_viewport_size({'width':720,'height':1000});await page.wait_for_timeout(100)
                check('responsive canvas keeps bounded height',await page.locator('#chart-candles').evaluate('e=>e.getBoundingClientRect().height')==350)
                check('no external CDN or market requests',not external)
                check('no JavaScript runtime exceptions',not errors)
                await browser.close()
        finally:server.shutdown();server.server_close()
    (output/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
    if not all(c['passed'] for c in checks):raise SystemExit(1)

if __name__=='__main__':asyncio.run(run(sys.argv[1] if len(sys.argv)>1 else '/tmp/continuity-browser'))
