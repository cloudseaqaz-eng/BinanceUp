"""Optional Chromium checks against isolated synthetic data, never real prediction evidence."""
import asyncio,json,sys,threading,tempfile
from pathlib import Path
from http.server import ThreadingHTTPServer
from urllib.parse import quote
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pandas as pd
from continuity_app.core import Options,build,Store
from continuity_app.server import handler


async def run(output):
    from playwright.async_api import async_playwright
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    checks=[];errors=[]
    def check(name,ok):
        checks.append({'check':name,'passed':bool(ok)});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);data=root/'input';(data/'raw').mkdir(parents=True);result=root/'result'
        ix=pd.date_range('2026-08-25T00:01Z',periods=35*1440,freq='min',name='time');at=ix[25000]
        for symbol,offset in [('AAAUSDT',60),('牛来USDT',120)]:
            r=pd.DataFrame({'open':100.,'high':100.,'low':100.,'close':100.,'quote':0.,'trades':0.,'taker_quote':0.},index=ix)
            a=25000-offset
            r.loc[ix[a:a+720],['quote','trades','taker_quote']]=[1000.,1.,500.]
            r.loc[ix[25300],'high']=125.
            r.to_parquet(data/'raw'/f'{symbol}.parquet')
        # Synthetic MOVR is an exclusion regression fixture, not the user's real MOVR history.
        r=pd.DataFrame({'open':100.,'high':100.,'low':100.,'close':100.,'quote':0.,'trades':0.,'taker_quote':0.},index=ix)
        for i in range(24000,24800):
            if i%5!=3:r.loc[ix[i],['quote','trades','taker_quote']]=[1000.,1.,500.]
        r.loc[ix[24800:25720],['quote','trades','taker_quote']]=[1000.,1.,500.]
        r.loc[ix[25300],'high']=150.
        r.to_parquet(data/'raw'/'MOVRUSDT.parquet')
        build(data,result,Options(start=ix[1440].isoformat(),end=ix[-1].isoformat()),progress=lambda s:None)
        server=ThreadingHTTPServer(('127.0.0.1',0),handler(Store(result)))
        threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}'
        try:
            async with async_playwright() as pw:
                browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
                page=await browser.new_page(viewport={'width':1500,'height':1000},device_scale_factor=2)
                await page.add_init_script("window.drawWidths=[];const width=Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype,'lineWidth');Object.defineProperty(CanvasRenderingContext2D.prototype,'lineWidth',{...width,set(v){window.drawWidths.push(v);width.set.call(this,v)}})")
                page.on('pageerror',lambda e:errors.append(str(e)))
                external=[];page.on('request',lambda r:external.append(r.url) if not r.url.startswith(base) else None)
                await page.goto(base+'/?at='+quote(at.isoformat()))
                await page.wait_for_selector('#rows a')
                check('three target probabilities with sample counts',await page.locator('#stats .stat').count()==3 and '/' in await page.locator('#stats').inner_text())
                check('historical candidates include both input coins',await page.locator('#rows tr').count()==2)
                check('candidates sorted by uninterrupted duration',await page.locator('#rows tr').first.locator('td').first.inner_text()=='牛来USDT')
                check('future hidden until explicit reveal',await page.locator('#future-th').evaluate("e=>e.classList.contains('hidden')") and await page.locator('#rows .future').count()==0)
                await page.locator('#reveal').check();await page.wait_for_selector('#rows .future')
                check('revealed future uses high-price plus twenty definition',all('达到' in x for x in await page.locator('#rows .future').all_inner_texts()))
                await page.locator('#reference').select_option('before')
                await page.wait_for_timeout(200)
                check('three reference price options available',await page.locator('#reference option').count()==3)
                response=await page.request.get(base+'/api/events.csv?hold=15&kind=any&reference=confirm&price=1')
                check('event CSV exports UTF8 coin names',response.status==200 and '牛来USDT' in await response.text())
                check('page identifies strict-only statistics', '未纳入入选条件' in await page.locator('#method-note').inner_text())
                await page.locator('#diagnose-symbol').fill('牛来')
                await page.locator('#diagnose').click()
                await page.wait_for_function('diagnosis?.symbol==="牛来USDT" && !document.querySelector("#diagnose").disabled')
                check('eligible coin diagnosis agrees with replay','符合当前严格筛选' in await page.locator('#diagnose-result').inner_text() and await page.evaluate('diagnosis.selected'))
                await page.locator('#diagnose-symbol').fill('MOVR')
                await page.locator('#diagnose').click()
                await page.wait_for_function('diagnosis?.symbol==="MOVRUSDT" && !document.querySelector("#diagnose").disabled')
                check('excluded gradual activation names the background gate',await page.evaluate('!diagnosis.selected&&diagnosis.channels.every(c=>c.gates.filter(g=>!g.pass).map(g=>g.code).join()===\'background\')') and '激活前背景过于活跃' in await page.locator('#diagnose-result').inner_text())
                check('excluded coin still has a detail link and observed high state',await page.locator('#diagnose-result a').count()==1 and await page.evaluate('diagnosis.channels.every(c=>c.state6h.current.high===1)'))
                async with page.expect_download() as event:await page.locator('#diagnose-export').click()
                download=await event.value
                diagnosis_data=json.loads(Path(await download.path()).read_text())
                check('diagnosis JSON exports without future outcomes or run endpoints',download.suggested_filename.startswith('MOVRUSDT-diagnosis-') and all('end_ms' not in x and 'future_high' not in x for x in diagnosis_data['recent_confirmations']))
                await page.screenshot(path=str(output/'diagnosis.png'),full_page=True)
                async with page.expect_response(lambda r:'/api/snapshot?' in r.url and 'background=0' in r.url):await page.locator('#background').uncheck()
                await page.wait_for_function('document.querySelectorAll("#rows tr").length===3&&document.querySelector("#rows").textContent.includes("MOVRUSDT")')
                check('background switch includes the formerly excluded activation',await page.locator('#rows tr').count()==3)
                await page.locator('#diagnose').click()
                await page.wait_for_function('diagnosis?.selected===true && !document.querySelector("#diagnose").disabled')
                check('diagnosis respects disabled background filter',await page.evaluate('diagnosis.background_filter===false&&diagnosis.channels.every(c=>c.selected)'))
                response=await page.request.get(base+'/api/events.csv?hold=15&kind=any&reference=confirm&price=1&background=0')
                check('CSV export uses the same background filter','MOVRUSDT' in await response.text())
                async with page.expect_response(lambda r:'/api/snapshot?' in r.url and 'background=1' in r.url):await page.locator('#background').check()
                await page.wait_for_function('document.querySelectorAll("#rows tr").length===2&&!document.querySelector("#rows").textContent.includes("MOVRUSDT")')
                await page.screenshot(path=str(output/'index.png'),full_page=True)
                await page.locator('#rows a').first.click();await page.wait_for_selector('#chart-candles')
                check('Chinese coin detail loads independently', '牛来USDT' in await page.locator('#title').inner_text())
                check('detail hides future initially',await page.evaluate('data.candles.every(r=>r.ms<=data.at_ms)'))
                check('default history is one week',await page.evaluate('data.at_ms-data.start_ms===168*3600000'))
                check('weekly score chart has two curves on a fixed zero to hundred axis',await page.locator('#chart-score').evaluate("e=>e.dataset.yMin==='0'&&e.dataset.yMax==='100'&&e.closest('section').querySelectorAll('.legend span').length===2"))
                check('score hides warmup and displays known past minutes',await page.evaluate('data.score_series.every(r=>r.ms<=data.at_ms)&&data.score_series.some(r=>r.trade_score===null)&&data.score_series.some(r=>Number.isFinite(r.trade_score))'))
                await page.evaluate('window.scoreAtInput=JSON.stringify(data.score_series.find(r=>r.ms===data.at_ms))')
                score_width=await page.locator('#chart-score').evaluate('e=>e.getBoundingClientRect().width')
                await page.locator('#chart-score').hover(position={'x':score_width-100,'y':100})
                check('score tooltip shows values and weighted history coverage','活跃积分' in await page.locator('#tooltip').inner_text() and '加权覆盖' in await page.locator('#tooltip').inner_text())
                check('speed defaults to thirty minute difference and five minute EMA',await page.locator('#speed-window').input_value()=='30' and await page.locator('#speed-half-life').input_value()=='5' and await page.evaluate('data.speed_settings.window_minutes===30&&data.speed_settings.ema_half_life_minutes===5'))
                check('speed uses symmetric zero axis and native closed minutes',await page.locator('#chart-speed').evaluate("e=>+e.dataset.yMin===-Number(e.dataset.yMax)&&+e.dataset.yMax>0") and await page.evaluate('data.speed_series.every(r=>r.ms<=data.at_ms)&&data.speed_series[1].ms-data.speed_series[0].ms===60000'))
                await page.evaluate('window.speedAtInput=JSON.stringify(data.speed_series.find(r=>r.ms===data.at_ms))')
                speed_width=await page.locator('#chart-speed').evaluate('e=>e.getBoundingClientRect().width')
                await page.locator('#chart-speed').hover(position={'x':speed_width-100,'y':100})
                check('speed tooltip contains units and follows score time','分/小时' in await page.locator('#tooltip').inner_text() and await page.evaluate("document.querySelector('#read-score').textContent.split(' · ')[0]===document.querySelector('#read-speed').textContent.split(' · ')[0]"))
                await page.locator('#speed-raw').check()
                check('raw comparison adds two faint curves',await page.locator('#chart-speed').evaluate("e=>e.closest('section').querySelectorAll('.legend span').length===4"))
                for selector,value,param in [('#speed-window','60','speed_window=60'),('#speed-half-life','0','speed_half_life=0')]:
                    async with page.expect_response(lambda r:param in r.url and '/api/detail?' in r.url):await page.locator(selector).select_option(value)
                    await page.wait_for_function('!document.querySelector("#reload").disabled')
                check('sixty minute unsmoothed option returns raw speed',await page.evaluate('data.speed_settings.window_minutes===60&&data.speed_settings.ema_half_life_minutes===0&&data.speed_series.every(r=>r.buy_speed===r.buy_speed_raw&&r.trade_speed===r.trade_speed_raw)'))
                for selector,value,param in [('#speed-half-life','10','speed_half_life=10'),('#speed-window','30','speed_window=30'),('#speed-half-life','5','speed_half_life=5')]:
                    async with page.expect_response(lambda r:param in r.url and '/api/detail?' in r.url):await page.locator(selector).select_option(value)
                    await page.wait_for_function('!document.querySelector("#reload").disabled')
                check('restoring defaults preserves exact speed and raw comparison choice',await page.evaluate('JSON.stringify(data.speed_series.find(r=>r.ms===data.at_ms))===window.speedAtInput') and await page.locator('#speed-raw').is_checked())
                response=await page.request.get(base+'/api/detail?symbol=AAAUSDT&at='+quote(at.isoformat())+'&speed_window=10')
                check('API rejects invalid speed windows',response.status==400)
                check('state chart defaults to six hours and has three labelled curves',await page.locator('#chart-state').count()==1 and await page.locator('#state-window').input_value()=='360' and await page.locator('#chart-state').evaluate("e=>e.closest('section').querySelectorAll('.legend span').length===3"))
                check('native minute state includes expected occupancy without future',await page.evaluate("data.state_series.every(r=>r.ms<=data.at_ms)&&Math.abs(data.state_series.at(-1).buy_high-118/360)<1e-12&&Math.abs(data.state_series.at(-1).buy_low-240/360)<1e-12&&data.state_series[1].ms-data.state_series[0].ms===60000"))
                await page.locator('#chart-state').hover(position={'x':380,'y':100})
                check('state tooltip shows high and low shares', '主动买入高档占比' in await page.locator('#tooltip').inner_text() and '主动买入低档占比' in await page.locator('#tooltip').inner_text())
                async with page.expect_response(lambda r:'/api/detail?' in r.url and 'state_window=180' in r.url):await page.locator('#state-window').select_option('180')
                await page.wait_for_function('data.state_window===180 && !document.querySelector("#reload").disabled')
                check('three hour state switch updates title and values',await page.evaluate("document.querySelector('#chart-state').closest('section').querySelector('h2').textContent.includes('近3小时')&&Math.abs(data.state_series.at(-1).buy_high-118/180)<1e-12"))
                async with page.expect_response(lambda r:'/api/detail?' in r.url and 'state_window=360' in r.url):await page.locator('#state-window').select_option('360')
                await page.wait_for_function('data.state_window===360 && !document.querySelector("#reload").disabled')
                check('flat price chart has a fifty percent axis span',await page.evaluate("(()=>{const c=document.querySelector('#chart-candles'),lo=+c.dataset.yMin,hi=+c.dataset.yMax;return lo<100&&hi>100&&Math.abs(hi/lo-1-.5)<1e-12})()"))
                check('small range expands and large range keeps true extrema',await page.evaluate("(()=>{const saved=data;try{for(const [lo,hi] of [[99,101],[100,150],[80,160],[.00000001,.0000000101]]){data={...saved,candles:[{...saved.candles[0],open:lo,close:hi,low:lo,high:hi}]};drawAll();const c=document.querySelector('#chart-candles'),lower=+c.dataset.yMin,upper=+c.dataset.yMax;if(lower>lo||upper<hi||upper/lower-1<.5-1e-12)return false;if(hi/lo>=1.5&&(lower!==lo||upper!==hi))return false}return true}finally{data=saved;drawAll()}})()"))
                async with page.expect_response(lambda r:'/api/detail?' in r.url and 'before=336' in r.url):await page.locator('#before').select_option('336')
                await page.wait_for_function('data.at_ms-data.start_ms===336*3600000 && !document.querySelector("#reload").disabled')
                check('two week history supported',await page.evaluate('data.candles.length>=4032'))
                async with page.expect_response(lambda r:'/api/detail?' in r.url and 'before=504' in r.url):await page.locator('#before').select_option('504')
                await page.wait_for_function('data.at_ms-data.start_ms===504*3600000 && !document.querySelector("#reload").disabled')
                check('three week history supported with data gaps left empty',await page.evaluate('data.state_series[0].ms>=data.start_ms&&data.candles[0].ms>=data.start_ms'))
                async with page.expect_response(lambda r:'/api/detail?' in r.url and 'after=168' in r.url):await page.locator('#after').select_option('168')
                await page.wait_for_function('data.end_ms-data.at_ms===168*3600000 && !document.querySelector("#reload").disabled')
                check('one week future reveals on demand',await page.evaluate('data.candles.some(r=>r.ms>data.at_ms)'))
                async with page.expect_response(lambda r:'/api/detail?' in r.url and 'after=336' in r.url):await page.locator('#after').select_option('336')
                await page.wait_for_function('data.end_ms-data.at_ms===336*3600000 && !document.querySelector("#reload").disabled')
                check('two week future supported',await page.evaluate('data.candles.some(r=>r.ms>data.at_ms+168*3600000)&&data.state_series.at(-1).ms===data.end_ms'))
                check('future window recalculates axis from visible candle extremes',await page.evaluate("(()=>{const c=document.querySelector('#chart-candles'),lo=+c.dataset.yMin,hi=+c.dataset.yMax;return lo<=100&&hi>=125&&hi/lo>=1.5-1e-12&&document.querySelector('#candle-scale').textContent.includes('50%')})()"))
                async with page.expect_response(lambda r:'/api/detail?' in r.url and 'period=15' in r.url):await page.locator('#period').select_option('15')
                await page.wait_for_function('!document.querySelector("#reload").disabled')
                check('state keeps native minutes after candle period switch',await page.evaluate('data.state_series[1].ms-data.state_series[0].ms===60000&&data.state_series.length>data.candles.length'))
                check('weekly score at the input time is unchanged by history future and period switches',await page.evaluate('JSON.stringify(data.score_series.find(r=>r.ms===data.at_ms))===window.scoreAtInput&&data.score_series[1].ms-data.score_series[0].ms===60000'))
                check('speed is invariant under before after and candle period changes',await page.evaluate('JSON.stringify(data.speed_series.find(r=>r.ms===data.at_ms))===window.speedAtInput'))
                await page.locator('#chart-speed').locator('..').screenshot(path=str(output/'speed.png'))
                check('period switch preserves minimum axis span',await page.evaluate("(()=>{const c=document.querySelector('#chart-candles');return +c.dataset.yMax/+c.dataset.yMin>=1.5-1e-12})()"))
                await page.locator('#chart-candles').hover(position={'x':380,'y':100})
                check('candle tooltip includes OHLC and change','Change' in await page.locator('#tooltip').inner_text())
                check('all chart cursor times align',await page.evaluate("document.querySelector('#read-candles').textContent.split(' · ')[0]===document.querySelector('#read-buy').textContent.split(' · ')[0]"))
                await page.mouse.move(1,1);await page.screenshot(path=str(output/'detail.png'),full_page=True)
                await page.set_viewport_size({'width':720,'height':1000});await page.wait_for_timeout(100)
                check('responsive canvas keeps bounded height',await page.locator('#chart-candles').evaluate('e=>e.getBoundingClientRect().height')==350)
                check('resize preserves minimum axis span',await page.evaluate("(()=>{const c=document.querySelector('#chart-candles');return +c.dataset.yMax/+c.dataset.yMin>=1.5-1e-12})()"))
                check('no external CDN or market requests',not external)
                check('every chart line remains at most one CSS pixel',await page.evaluate('window.drawWidths.length>0&&Math.max(...window.drawWidths)<=1'))
                check('no JavaScript runtime exceptions',not errors)
                await browser.close()
        finally:server.shutdown();server.server_close()
    (output/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
    if not all(c['passed'] for c in checks):raise SystemExit(1)

if __name__=='__main__':asyncio.run(run(sys.argv[1] if len(sys.argv)>1 else '/tmp/continuity-browser'))
