import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd

from continuity_app.score_trend import metrics, settings


def scores(length=1800):
    index = pd.date_range('2026-09-01T00:00Z', periods=length, freq='min', name='time')
    return pd.DataFrame({'buy_score': 30., 'trade_score': 50.}, index=index)


class ScoreTrendTests(unittest.TestCase):
    def test_ols_matches_independent_polyfit_and_uses_all_points(self):
        source = scores()
        source.buy_score = 30 + np.sin(np.arange(len(source)) / 70) + np.arange(len(source)) * .002
        for window in (180, 360, 720):
            actual = metrics(source, window)
            self.assertTrue(actual.buy_trend.iloc[:window].isna().all())
            for pos in (window, window + 31, 1500):
                expected = np.polyfit(np.arange(window + 1) / 60, source.buy_score.iloc[pos-window:pos+1], 1)[0]
                self.assertAlmostEqual(actual.buy_trend.iloc[pos], expected, places=11)
            # In a curved window the regression differs from its endpoint slope.
            self.assertNotAlmostEqual(actual.buy_trend.iloc[1500], (source.buy_score.iloc[1500] - source.buy_score.iloc[1500-window]) * 60 / window, places=4)

    def test_hourly_units_signs_and_full_coverage(self):
        source = scores()
        source.buy_score += np.arange(len(source)) * .001
        source.trade_score -= np.arange(len(source)) * .002
        original = source.copy(deep=True)
        for window in (180, 360, 720):
            actual = metrics(source, window)
            np.testing.assert_allclose(actual.buy_trend.iloc[window:], .06, atol=1e-12)
            np.testing.assert_allclose(actual.trade_trend.iloc[window:], -.12, atol=1e-12)
            # 60 raw lookback plus W consecutive short speeds, first at 60+W-1.
            self.assertTrue(actual.buy_rising.iloc[:60+window-1].isna().all())
            self.assertTrue(actual.buy_rising.iloc[60+window-1:].eq(1).all())
            self.assertTrue(actual.trade_rising.iloc[60+window-1:].eq(0).all())
        pd.testing.assert_frame_equal(source, original, check_exact=True)

    def test_flat_zero_and_hundred_have_zero_slope_and_no_positive_share(self):
        source = scores()
        source.buy_score = 100.
        source.trade_score = 0.
        actual = metrics(source, threshold=0)
        self.assertTrue(actual[['buy_trend', 'trade_trend']].iloc[360:].eq(0).all().all())
        self.assertTrue(actual[['buy_rising', 'trade_rising']].iloc[419:].eq(0).all().all())

    def test_rising_share_matches_independent_recursive_ema(self):
        source = scores()
        source.buy_score = 30 + np.sin(np.arange(len(source)) / 40)
        actual = metrics(source, 180, .05)
        ema = []; previous = None; alpha = 1 - 2 ** (-1/10)
        for pos in range(60, len(source)):
            raw = source.buy_score.iloc[pos] - source.buy_score.iloc[pos-60]
            previous = raw if previous is None else alpha * raw + (1-alpha) * previous
            ema.append(previous)
        for pos in (239, 300, 700, 1500):
            reference = np.array(ema[pos-60-179:pos-60+1])
            self.assertEqual(len(reference), 180)
            self.assertAlmostEqual(actual.buy_rising.iloc[pos], np.mean(reference > .05), places=14)
            self.assertAlmostEqual(actual.buy_short_speed.iloc[pos], ema[pos-60], places=12)

    def test_strict_threshold_boundary_and_no_missing_denominator_shrink(self):
        source = scores(500)
        # Controlled short speeds isolate > vs >= and the fixed denominator.
        short = pd.DataFrame({'buy_speed': .02, 'trade_speed': .02}, index=source.index)
        short.iloc[100:190, 0] = .03
        with patch('continuity_app.score_trend.speed_metrics', return_value=short):
            actual = metrics(source, 180, .02)
        self.assertEqual(actual.buy_rising.iloc[199], .5)
        self.assertEqual(actual.trade_rising.iloc[199], 0)
        short.iloc[200, 0] = np.nan
        with patch('continuity_app.score_trend.speed_metrics', return_value=short):
            actual = metrics(source, 180, .02)
        self.assertTrue(actual.buy_rising.iloc[200:380].isna().all())
        self.assertEqual(actual.buy_rising.iloc[380], 0)

    def test_score_gap_invalidates_trend_and_share_until_full_recovery(self):
        source = scores()
        source.buy_score += np.arange(len(source)) * .001
        source.iloc[700, 0] = np.nan
        actual = metrics(source, 180)
        self.assertTrue(actual.buy_trend.iloc[700:881].isna().all())
        self.assertAlmostEqual(actual.buy_trend.iloc[881], .06, places=12)
        self.assertTrue(actual.buy_rising.iloc[700:940].isna().all())
        self.assertEqual(actual.buy_rising.iloc[940], 1)
        self.assertTrue(actual.trade_trend.iloc[180:].eq(0).all())

    def test_future_extension_and_mutation_cannot_change_past(self):
        source = scores()
        source.buy_score = 30 + np.sin(np.arange(len(source)) / 30)
        source.trade_score = 50 + np.cos(np.arange(len(source)) / 75)
        source.iloc[400:402] = np.nan
        for window in (180, 360, 720):
            prefix = metrics(source.iloc[:1200], window)
            pd.testing.assert_frame_equal(prefix, metrics(source, window).iloc[:1200], check_exact=True)
            changed = source.copy()
            changed.iloc[1200:] = [np.nan, 100.]
            pd.testing.assert_frame_equal(prefix, metrics(changed, window).iloc[:1200], check_exact=True)

    def test_channels_are_independent(self):
        source = scores()
        source.buy_score += np.sin(np.arange(len(source)) / 70)
        before = metrics(source)
        source.trade_score = np.nan
        after = metrics(source)
        pd.testing.assert_frame_equal(before.filter(like='buy_'), after.filter(like='buy_'), check_exact=True)
        self.assertTrue(after.filter(like='trade_').isna().all().all())

    def test_empty_short_nonfinite_and_parameter_validation(self):
        self.assertTrue(metrics(scores(0)).empty)
        self.assertTrue(metrics(scores(60)).isna().all().all())
        source = scores()
        source.iloc[:] = np.inf
        self.assertTrue(metrics(source).isna().all().all())
        for window, threshold in ((60, .02), (360., .02), (360, -.02), (360, np.nan), (360, .03)):
            with self.assertRaises(ValueError):metrics(scores(), window, threshold)
        for invalid in (scores().iloc[::2], scores().iloc[::-1], scores().reset_index(drop=True)):
            with self.assertRaises(ValueError):metrics(invalid)
        self.assertEqual(settings()['short_window_minutes'], 60)
        self.assertEqual(settings()['short_ema_half_life_minutes'], 10)


if __name__ == '__main__':
    unittest.main()
