import unittest

import numpy as np
import pandas as pd

from continuity_app.activity_score import metrics, weighted_sum


MINUTES_PER_DAY = 1440
WEEK = 7 * MINUTES_PER_DAY
FORTNIGHT = 14 * MINUTES_PER_DAY


def age_weights(ages):
    """Evaluate the specified age curve directly, without a recurrence."""
    ages = np.asarray(ages, dtype=float)
    return np.where(
        ages <= WEEK,
        2.0 ** (-ages / WEEK),
        0.5 * 2.0 ** (-(ages - WEEK) / MINUTES_PER_DAY),
    )


# At 90 days the omitted tail is below double-precision significance.
REFERENCE_TOTAL_WEIGHT = age_weights(np.arange(90 * MINUTES_PER_DAY)).sum()


def c5_frame(length, trade=1.0, buy=1.0):
    index = pd.date_range('2026-01-01T00:00Z', periods=length, freq='min', name='time')
    return pd.DataFrame({'trade5': trade, 'buy5': buy}, index=index)


def direct_metric(values, position):
    history = np.asarray(values[:position + 1], dtype=float)
    weights = age_weights(np.arange(position, -1, -1))
    known = np.isfinite(history) & (history >= 0) & (history <= 1)
    known_weight = weights[known].sum()
    score = 100 * np.dot(weights[known], history[known]) / known_weight
    return score, known_weight / REFERENCE_TOTAL_WEIGHT


class ActivityScoreTests(unittest.TestCase):
    def test_week_boundary_and_daily_tail_half_life(self):
        pulse = np.zeros(WEEK + 2 * MINUTES_PER_DAY + 1)
        pulse[0] = 1
        actual = weighted_sum(pulse)

        np.testing.assert_allclose(actual, age_weights(np.arange(len(pulse))), rtol=1e-11, atol=1e-12)
        self.assertEqual(actual[0], 1)
        self.assertGreater(actual[WEEK - 1], 0.5)
        self.assertAlmostEqual(actual[WEEK], 0.5, places=12)
        self.assertAlmostEqual(actual[WEEK + 1], 0.5 * 2 ** (-1 / MINUTES_PER_DAY), places=12)
        self.assertAlmostEqual(actual[WEEK + MINUTES_PER_DAY], 0.25, places=12)
        self.assertAlmostEqual(actual[WEEK + 2 * MINUTES_PER_DAY], 0.125, places=12)

    def test_sparse_pulses_add_without_losing_old_tail(self):
        length = FORTNIGHT + MINUTES_PER_DAY
        pulses = {0: 0.4, 17: 1.0, WEEK - 1: 0.2, WEEK: 0.8, WEEK + 1: 0.6}
        values = np.zeros(length)
        expected = np.zeros(length)
        for position, value in pulses.items():
            values[position] = value
            expected[position:] += value * age_weights(np.arange(length - position))

        np.testing.assert_allclose(weighted_sum(values), expected, rtol=1e-10, atol=1e-12)

    def test_scores_and_coverage_match_direct_history_weights(self):
        rng = np.random.default_rng(20261028)
        source = c5_frame(FORTNIGHT + MINUTES_PER_DAY + 1)
        for column in ('trade5', 'buy5'):
            source[column] = rng.integers(0, 6, len(source)) / 5
            source.loc[source.index[20::997], column] = np.nan
        actual = metrics(source)

        for position in (FORTNIGHT, FORTNIGHT + 60, len(source) - 1):
            for kind in ('trade', 'buy'):
                with self.subTest(position=position, kind=kind):
                    expected_score, expected_coverage = direct_metric(source[kind + '5'].to_numpy(), position)
                    self.assertAlmostEqual(actual[kind + '_score'].iloc[position], expected_score, places=9)
                    self.assertAlmostEqual(actual[kind + '_coverage'].iloc[position], expected_coverage, places=11)

    def test_warmup_is_fourteen_elapsed_days_from_first_known_c5(self):
        first_known = 63
        first_ready = first_known + FORTNIGHT
        source = c5_frame(first_ready + 2, trade=0.6, buy=0.6)
        source.iloc[:first_known] = np.nan
        actual = metrics(source)

        for kind in ('trade', 'buy'):
            with self.subTest(kind=kind):
                self.assertTrue(actual[kind + '_score'].iloc[:first_ready].isna().all())
                self.assertGreater(actual[kind + '_coverage'].iloc[first_ready - 1], 0.99)
                self.assertAlmostEqual(actual[kind + '_score'].iloc[first_ready], 60, places=9)
                self.assertAlmostEqual(actual[kind + '_coverage'].iloc[first_ready], 0.9990237312602, places=11)

    def test_constant_inputs_normalize_to_zero_twenty_and_one_hundred(self):
        for value in (0.0, 0.2, 1.0):
            with self.subTest(value=value):
                actual = metrics(c5_frame(FORTNIGHT + 16, trade=value, buy=value))
                for kind in ('trade', 'buy'):
                    self.assertTrue(actual[kind + '_score'].iloc[:FORTNIGHT].isna().all())
                    np.testing.assert_allclose(actual[kind + '_score'].iloc[FORTNIGHT:], value * 100, atol=1e-9)

    def test_short_gap_during_warmup_does_not_restart_or_extend_elapsed_gate(self):
        source = c5_frame(FORTNIGHT + 2, trade=0.4, buy=0.4)
        source.iloc[5 * MINUTES_PER_DAY:5 * MINUTES_PER_DAY + 5] = np.nan
        actual = metrics(source)

        for kind in ('trade', 'buy'):
            self.assertTrue(np.isnan(actual[kind + '_score'].iloc[FORTNIGHT - 1]))
            self.assertGreater(actual[kind + '_coverage'].iloc[FORTNIGHT], 0.99)
            self.assertAlmostEqual(actual[kind + '_score'].iloc[FORTNIGHT], 40, places=9)

    def test_unknown_values_are_excluded_and_current_score_resumes_without_reset(self):
        gap = FORTNIGHT + 100
        source = c5_frame(gap + 20, trade=0.2, buy=0.2)
        # Every nonfinite or out-of-range C5 is unknown, never inactivity.
        source.iloc[gap:gap + 5, source.columns.get_loc('trade5')] = [np.nan, np.inf, -np.inf, -0.2, 1.2]
        actual = metrics(source)

        self.assertAlmostEqual(actual.trade_score.iloc[gap - 1], 20, places=9)
        self.assertTrue(actual.trade_score.iloc[gap:gap + 5].isna().all())
        self.assertAlmostEqual(actual.trade_score.iloc[gap + 5], 20, places=9)
        self.assertLess(actual.trade_coverage.iloc[gap + 4], actual.buy_coverage.iloc[gap + 4])
        self.assertGreater(actual.trade_coverage.iloc[gap + 5], 0.99)
        for position in (gap, gap + 4, gap + 5, len(source) - 1):
            with self.subTest(position=position):
                expected_score, expected_coverage = direct_metric(source.trade5.to_numpy(), position)
                self.assertAlmostEqual(actual.trade_coverage.iloc[position], expected_coverage, places=11)
                if np.isfinite(source.trade5.iloc[position]) and 0 <= source.trade5.iloc[position] <= 1:
                    self.assertAlmostEqual(actual.trade_score.iloc[position], expected_score, places=9)

    def test_long_gap_requires_sufficient_coverage_even_after_elapsed_warmup(self):
        source = c5_frame(40 * MINUTES_PER_DAY + 1, trade=0.6, buy=0.2)
        gap_start = 21 * MINUTES_PER_DAY
        resumed = 23 * MINUTES_PER_DAY
        source.iloc[gap_start:resumed, source.columns.get_loc('trade5')] = np.nan
        actual = metrics(source)

        self.assertAlmostEqual(actual.trade_score.iloc[gap_start - 1], 60, places=9)
        self.assertTrue(actual.trade_score.iloc[gap_start:resumed].isna().all())
        self.assertLess(actual.trade_coverage.iloc[resumed], 0.99)
        self.assertTrue(np.isnan(actual.trade_score.iloc[resumed]))
        self.assertGreater(actual.trade_coverage.iloc[-1], 0.99)
        self.assertAlmostEqual(actual.trade_score.iloc[-1], 60, places=9)
        self.assertAlmostEqual(actual.buy_score.iloc[resumed], 20, places=9)
        first_covered = resumed + np.flatnonzero(actual.trade_coverage.iloc[resumed:].to_numpy() >= 0.99)[0]
        self.assertTrue(np.isnan(actual.trade_score.iloc[first_covered - 1]))
        self.assertAlmostEqual(actual.trade_score.iloc[first_covered], 60, places=9)

    def test_unknown_history_never_becomes_a_zero_score(self):
        actual = metrics(c5_frame(FORTNIGHT + 1, trade=np.nan, buy=np.nan))
        for kind in ('trade', 'buy'):
            self.assertTrue(actual[kind + '_score'].isna().all())
            self.assertTrue(actual[kind + '_coverage'].eq(0).all())

    def test_future_extension_and_mutation_do_not_change_history(self):
        source = c5_frame(21 * MINUTES_PER_DAY)
        source.trade5 = (np.arange(len(source)) % 6) / 5
        source.buy5 = (np.arange(len(source)) % 3) / 5
        source.iloc[13000:13005] = np.nan
        prefix_length = FORTNIGHT + MINUTES_PER_DAY
        prefix = metrics(source.iloc[:prefix_length])
        full = metrics(source)
        pd.testing.assert_frame_equal(prefix, full.iloc[:prefix_length], check_exact=True)

        source.iloc[prefix_length:] = np.nan
        source.iloc[prefix_length + 200:] = [0.0, 1.0]
        altered = metrics(source)
        pd.testing.assert_frame_equal(prefix, altered.iloc[:prefix_length], check_exact=True)

    def test_trade_and_buy_histories_are_independent(self):
        source = c5_frame(FORTNIGHT + 5, trade=1.0, buy=0.2)
        baseline = metrics(source)
        source.trade5 = 0.0
        changed_trade = metrics(source)
        pd.testing.assert_frame_equal(
            baseline[['buy_score', 'buy_coverage']], changed_trade[['buy_score', 'buy_coverage']], check_exact=True,
        )
        self.assertAlmostEqual(baseline.trade_score.iloc[-1], 100, places=9)
        self.assertEqual(changed_trade.trade_score.iloc[-1], 0)

        source.buy5 = np.nan
        changed_buy = metrics(source)
        pd.testing.assert_frame_equal(
            changed_trade[['trade_score', 'trade_coverage']], changed_buy[['trade_score', 'trade_coverage']], check_exact=True,
        )
        self.assertTrue(changed_buy.buy_score.isna().all())
        self.assertTrue(changed_buy.buy_coverage.eq(0).all())


if __name__ == '__main__':
    unittest.main()
