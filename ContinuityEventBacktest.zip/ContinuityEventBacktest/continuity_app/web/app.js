'use strict';
let meta=null,summaryGeneration=0,snapshotGeneration=0,diagnoseGeneration=0,diagnosis=null;
const queryParams=()=>new URLSearchParams({hold:$('#hold').value,kind:$('#kind').value,reference:$('#reference').value,price:$('#price').checked?'1':'0',background:$('#background').checked?'1':'0'});
const detailLink=(s,t)=>'/detail.html?'+new URLSearchParams({symbol:s,at:new Date(t).toISOString()});
async function summary(){
 const generation=++summaryGeneration;
 try{const q=queryParams(),r=await api('/api/summary?'+q);if(generation!==summaryGeneration)return;
 $('#stats').innerHTML=r.cells.map(c=>`<div class="stat">未来24h最高价 ＋${c.target}%<strong>${pct(c.probability)}</strong>${c.success} / ${c.n}，未知 ${c.unknown}<br><span class="muted">95%区间 ${pct(c.ci95[0])}～${pct(c.ci95[1])}${c.n<30?' · 样本较少':''}</span></div>`).join('');
 $('#summary-note').textContent=`原始确认记录${r.candidates} → ${r.background_filter?'背景通过'+r.cold:'背景过滤关闭，保留'+r.background_kept} → 价格通过${r.price_pass} → 去重${r.deduplicated}。${r.note}`;
 const o=meta.options;$('#method-note').textContent=`当前统计覆盖严格连续100%的事件，不代表所有连续性异动。${r.background_filter?`背景过滤开启：本轮开始前${o.background_minutes/60}小时C5均值≤${pct(o.background_mean)}且满值占比≤${pct(o.background_full)}。`:'背景过滤已关闭：近期已活跃的连续100%事件也可纳入。'}连续性状态高/低档占比只用于详情观察，未纳入入选条件。`;
 $('#export').href='/api/events.csv?'+q;
 const ref=r.reference;
 $('#events').innerHTML=r.events.slice(-200).reverse().map(e=>`<tr><td><a href="${detailLink(e.symbol,e.confirm_ms)}">${esc(e.symbol)}</a></td><td>${esc((e.kinds||[e.kind]).map(kindLabel).join('+'))}</td><td>${time(e.confirm_ms)}</td><td>${num(e.price_confirm,8)}</td><td>${e.future_complete?'完整':'未知'}</td><td>${pct(e['mfe_'+ref])}</td><td>${e['hit_'+ref+'_20']==null?'未知':e['hit_'+ref+'_20']?'达到':'未达到'}</td><td>${num(e['minutes20_'+ref],0)}</td><td>${pct(e['mae_'+ref])}</td></tr>`).join('');
 }catch(e){notice(e.message,true)}
}
async function snapshot(){
 ++diagnoseGeneration;diagnosis=null;$('#diagnose-result').textContent='';$('#diagnose-export').classList.add('hidden');$('#diagnose').disabled=false;
 const generation=++snapshotGeneration,reference=$('#reference').value;
 $('#query').disabled=true;
 try{const q=queryParams();q.set('at',atISO($('#at').value));q.set('fresh',$('#fresh').value);q.set('reveal',$('#reveal').checked?'1':'0');const r=await api('/api/snapshot?'+q);if(generation!==snapshotGeneration)return;
 $('#future-th').classList.toggle('hidden',!r.future_revealed);
 $('#snapshot-note').textContent=`${time(r.at_ms)}，${r.rows.length}币。${r.note}`+(r.errors.length?' 读取失败：'+r.errors.map(e=>e.symbol+': '+e.error).join('；'):'');
 const ref=reference;
 $('#rows').innerHTML=r.rows.map(e=>{const future=e.future?.[ref];return `<tr><td><a href="${detailLink(e.symbol,r.at_ms)}">${esc(e.symbol)}</a></td><td>${esc(e.kinds.map(kindLabel).join('+'))}</td><td>${num(e.duration,0)}<br><span class="muted">交易 ${num(e.durations.trade,0)} / 主动买 ${num(e.durations.buy,0)}</span></td><td>${time(e.confirm_ms)}</td><td>${num(e.age_minutes,0)}</td><td>${e.kinds.map(k=>esc(kindLabel(k))+' '+pct(e.backgrounds[k].mean)+' / '+pct(e.backgrounds[k].full)).join('<br>')}</td><td>${num(e.close,8)}</td><td>${pct(e.r60)}</td><td>${pct(e.r24)}</td><td>${pct(e.dd24)}</td><td>${num(e.quote24,0)}</td>${r.future_revealed?`<td class="future">${pct(future?.max_gain)} / ${future?.hit20==null?'未知':future.hit20?'达到':'未达到'}</td>`:''}</tr>`}).join('')||'<tr><td colspan="12">这个时间没有符合当前条件的币。可核查持续时长、背景阈值、新激活窗口和价格过滤。</td></tr>';
 notice('查询完成。数据只覆盖本地已下载币种；未完整下载全市场时，结果不是币安全市场概率。');
 }catch(e){notice(e.message,true)}finally{if(generation===snapshotGeneration)$('#query').disabled=false}
}
async function diagnose(){
 const generation=++diagnoseGeneration;
 $('#diagnose').disabled=true;$('#diagnose-result').textContent='正在读取该币的历史数据并核查…';$('#diagnose-export').classList.add('hidden');diagnosis=null;
 try{
 const q=queryParams();q.set('symbol',$('#diagnose-symbol').value);q.set('at',atISO($('#at').value));q.set('fresh',$('#fresh').value);
 const r=await api('/api/diagnose?'+q);if(generation!==diagnoseGeneration)return;diagnosis=r;
 $('#diagnose-export').classList.remove('hidden');
 const heading=`<p><strong>${esc(r.symbol)} · ${time(r.at_ms)}（北京时间）</strong> · ${r.selected?'符合当前严格筛选':'未进入当前严格筛选'} ${r.available?`<a href="${detailLink(r.symbol,r.at_ms)}">查看详情</a>`:''}</p>`;
 if(!r.available){$('#diagnose-result').innerHTML=heading+`<p>${esc(r.reason)}</p><pre>${esc(JSON.stringify(r.source_errors,null,2))}</pre>`;return}
 const o=r.thresholds;
 const criteria=`<p class="muted">规则：C5严格连续100%至少${r.hold}分钟；${r.background_filter?`本轮开始前${o.background_minutes/60}小时C5均值≤${pct(o.background_mean)}且满值占比≤${pct(o.background_full)}`:'背景过滤已关闭'}；确认时效${r.fresh_hours?num(r.fresh_hours)+'小时':'不限'}；${r.price_filter?`查询时1h涨幅≤${pct(o.max_r60)}且距24h低点≤${pct(o.max_dd24)}`:'价格过滤已关闭'}。实际1h ${pct(r.r60)}、距24h低点 ${pct(r.dd24)}。</p>`;
 const failedReason=g=>({valid:'查询分钟缺失或非法',duration:`严格连续100%不足${r.hold}分钟`,background:'激活前背景过于活跃，或背景数据不足',fresh:'尚未确认，或首次确认已超过时效',price:'查询时价格涨幅超限，或价格历史不足',kind:'当前未选择此信号类型',index:'构建索引无当时有效区间'})[g.code]||g.label;
 const channels=r.channels.map(c=>`<tr><td>${esc(kindLabel(c.kind))}</td><td>${pct(c.c5)}</td><td>${num(c.duration,0)}分钟<br><span class="muted">原始活跃 ${num(c.raw_active_minutes,0)}分钟</span></td><td>${time(c.start_ms)}<br><span class="muted">首次确认 ${time(c.confirm_ms)}</span></td><td>${c.bg_known?pct(c.bg_mean)+' / '+pct(c.bg_full):'历史不足或无当前活跃段'}<br><span class="muted">冻结于 ${time(c.bg_at_ms)}</span></td><td>${c.selected?'全部通过':c.gates.filter(g=>!g.pass).map(g=>esc(failedReason(g))).join('<br>')}</td></tr>`).join('');
 const states=r.channels.map(c=>`<tr><td>${esc(kindLabel(c.kind))}</td><td>${pct(c.state6h.current.high)}</td><td>${pct(c.state6h.previous.high)}</td><td>${pct(c.state6h.current.low)}</td><td>${pct(c.state6h.previous.low)}</td><td>${pct(c.state6h.current.mean)}</td><td>${pct(c.state6h.previous.mean)}</td></tr>`).join('');
 const recent=r.recent_confirmations.map(e=>`<tr><td>${esc(kindLabel(e.kind))}</td><td>${time(e.confirm_ms)}</td><td>${e.bg_ok?'通过':'未通过'}<br>${pct(e.bg_mean)} / ${pct(e.bg_full)}</td><td>${e.price_pass_at_confirm?'通过':'未通过'}</td><td>${e.selected_at_confirm?'当时符合':'当时未通过背景/价格/类型'}</td><td>${e.current_run_active?'仍连续':'已中断'}</td></tr>`).join('')||'<tr><td colspan="6">此前48小时没有达到当前持续时长的确认记录。</td></tr>';
 $('#diagnose-result').innerHTML=heading+criteria+`<div class="scroll"><table><thead><tr><th>类型</th><th>当前C5</th><th>严格连续100%时长</th><th>当前段开始 / 首次确认</th><th>冻结背景均值 / 满值占比</th><th>未通过的规则</th></tr></thead><tbody>${channels}</tbody></table></div><p class="muted">连续性状态对照：当前6小时与紧邻的此前6小时（两个窗口不重叠），仅用于观察变化。</p><div class="scroll"><table><thead><tr><th>类型</th><th>当前高档占比</th><th>此前高档占比</th><th>当前低档占比</th><th>此前低档占比</th><th>当前C5均值</th><th>此前C5均值</th></tr></thead><tbody>${states}</tbody></table></div><p class="muted">此前48小时最近40条确认记录。历史曾符合不代表输入时点仍符合；24小时冷却仅影响总体事件统计，不影响当前回放名单。</p><div class="scroll"><table><thead><tr><th>类型</th><th>确认时间</th><th>背景</th><th>确认时价格过滤</th><th>确认当时条件</th><th>输入时点仍连续</th></tr></thead><tbody>${recent}</tbody></table></div><p class="muted">${esc(r.note)}</p>`;
 }catch(e){if(generation===diagnoseGeneration)$('#diagnose-result').textContent=e.message}finally{if(generation===diagnoseGeneration)$('#diagnose').disabled=false}
}
$('#diagnose').onclick=diagnose;
$('#diagnose-export').onclick=()=>{if(!diagnosis)return;const url=URL.createObjectURL(new Blob([JSON.stringify(diagnosis,null,2)],{type:'application/json;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=diagnosis.symbol+'-diagnosis-'+diagnosis.at_ms+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)};
async function init(){try{
 meta=await api('/api/meta');$('#hold').innerHTML=meta.options.holds.map(n=>`<option value="${n}" ${n===15?'selected':''}>${n}分钟</option>`).join('');$('#fresh').value=meta.options.fresh_hours;
 const o=meta.options;$('#method-note').textContent=`当前统计只覆盖“严格连续100%＋背景过滤”的事件，不代表所有连续性异动。背景要求：本轮开始前${o.background_minutes/60}小时C5均值≤${pct(o.background_mean)}且满值占比≤${pct(o.background_full)}。连续性状态高/低档占比只用于详情观察，未纳入入选条件。`;
 $('#at').value=localInput(new URLSearchParams(location.search).get('at')||Math.max(meta.start_ms,meta.end_ms-86400000));
 const startMs=meta.start_ms,endMs=meta.end_ms;
 $('#at').min=localInput(startMs);$('#at').max=localInput(endMs);
 $('#config').textContent=JSON.stringify({起止北京时间:[time(startMs),time(endMs)],币种数:Object.keys(meta.sources).length,参数:meta.options,文件失败:meta.errors,各币质量:meta.audit},null,2);
 notice(`已加载${Object.keys(meta.sources).length}币，${time(startMs)}～${time(endMs)}。失败文件${meta.errors.length}。时间无时区时按北京时间。`);
 await summary();await snapshot();
 }catch(e){notice(e.message,true)}}
$('#refresh').onclick=summary;$('#query').onclick=snapshot;
for(const id of ['hold','kind','reference','price','background'])$('#'+id).onchange=()=>{summary();snapshot()};
$('#reveal').onchange=snapshot;
init();
