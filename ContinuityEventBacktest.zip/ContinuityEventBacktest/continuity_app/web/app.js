'use strict';
let meta=null,summaryGeneration=0,snapshotGeneration=0;
const queryParams=()=>new URLSearchParams({hold:$('#hold').value,kind:$('#kind').value,reference:$('#reference').value,price:$('#price').checked?'1':'0'});
const detailLink=(s,t)=>'/detail.html?'+new URLSearchParams({symbol:s,at:new Date(t).toISOString()});
async function summary(){
 const generation=++summaryGeneration;
 try{const q=queryParams(),r=await api('/api/summary?'+q);if(generation!==summaryGeneration)return;
 $('#stats').innerHTML=r.cells.map(c=>`<div class="stat">未来24h最高价 ＋${c.target}%<strong>${pct(c.probability)}</strong>${c.success} / ${c.n}，未知 ${c.unknown}<br><span class="muted">95%区间 ${pct(c.ci95[0])}～${pct(c.ci95[1])}${c.n<30?' · 样本较少':''}</span></div>`).join('');
 $('#summary-note').textContent=`原始确认记录${r.candidates} → 背景通过${r.cold} → 价格通过${r.price_pass} → 去重${r.deduplicated}。${r.note}`;
 $('#export').href='/api/events.csv?'+q;
 const ref=r.reference;
 $('#events').innerHTML=r.events.slice(-200).reverse().map(e=>`<tr><td><a href="${detailLink(e.symbol,e.confirm_ms)}">${esc(e.symbol)}</a></td><td>${esc((e.kinds||[e.kind]).map(kindLabel).join('+'))}</td><td>${time(e.confirm_ms)}</td><td>${num(e.price_confirm,8)}</td><td>${e.future_complete?'完整':'未知'}</td><td>${pct(e['mfe_'+ref])}</td><td>${e['hit_'+ref+'_20']==null?'未知':e['hit_'+ref+'_20']?'达到':'未达到'}</td><td>${num(e['minutes20_'+ref],0)}</td><td>${pct(e['mae_'+ref])}</td></tr>`).join('');
 }catch(e){notice(e.message,true)}
}
async function snapshot(){
 const generation=++snapshotGeneration,reference=$('#reference').value;
 $('#query').disabled=true;
 try{const q=queryParams();q.set('at',atISO($('#at').value));q.set('fresh',$('#fresh').value);q.set('reveal',$('#reveal').checked?'1':'0');const r=await api('/api/snapshot?'+q);if(generation!==snapshotGeneration)return;
 $('#future-th').classList.toggle('hidden',!r.future_revealed);
 $('#snapshot-note').textContent=`${time(r.at_ms)}，${r.rows.length}币。${r.note}`+(r.errors.length?' 读取失败：'+r.errors.map(e=>e.symbol+': '+e.error).join('；'):'');
 const ref=reference;
 $('#rows').innerHTML=r.rows.map(e=>{const future=e.future?.[ref];return `<tr><td><a href="${detailLink(e.symbol,r.at_ms)}">${esc(e.symbol)}</a></td><td>${esc(e.kinds.map(kindLabel).join('+'))}</td><td>${num(e.duration,0)}<br><span class="muted">交易 ${num(e.durations.trade,0)} / 主动买 ${num(e.durations.buy,0)}</span></td><td>${time(e.confirm_ms)}</td><td>${num(e.age_minutes,0)}</td><td>${e.kinds.map(k=>esc(kindLabel(k))+' '+pct(e.backgrounds[k].mean)+' / '+pct(e.backgrounds[k].full)).join('<br>')}</td><td>${num(e.close,8)}</td><td>${pct(e.r60)}</td><td>${pct(e.r24)}</td><td>${pct(e.dd24)}</td><td>${num(e.quote24,0)}</td>${r.future_revealed?`<td class="future">${pct(future?.max_gain)} / ${future?.hit20==null?'未知':future.hit20?'达到':'未达到'}</td>`:''}</tr>`}).join('')||'<tr><td colspan="12">这个时间没有符合当前条件的币。可核查持续时长、背景阈值、新激活窗口和价格过滤。</td></tr>';
 notice('查询完成。数据只覆盖本地已下载币种；未完整下载全市场时，结果不是币安全市场概率。');
 }catch(e){notice(e.message,true)}finally{if(generation===snapshotGeneration)$('#query').disabled=false}
}
async function init(){try{
 meta=await api('/api/meta');$('#hold').innerHTML=meta.options.holds.map(n=>`<option value="${n}" ${n===15?'selected':''}>${n}分钟</option>`).join('');$('#fresh').value=meta.options.fresh_hours;
 $('#at').value=localInput(new URLSearchParams(location.search).get('at')||Math.max(meta.start_ms,meta.end_ms-86400000));
 const startMs=meta.start_ms,endMs=meta.end_ms;
 $('#at').min=localInput(startMs);$('#at').max=localInput(endMs);
 $('#config').textContent=JSON.stringify({起止北京时间:[time(startMs),time(endMs)],币种数:Object.keys(meta.sources).length,参数:meta.options,文件失败:meta.errors,各币质量:meta.audit},null,2);
 notice(`已加载${Object.keys(meta.sources).length}币，${time(startMs)}～${time(endMs)}。失败文件${meta.errors.length}。时间无时区时按北京时间。`);
 await summary();await snapshot();
 }catch(e){notice(e.message,true)}}
$('#refresh').onclick=summary;$('#query').onclick=snapshot;
for(const id of ['hold','kind','reference','price'])$('#'+id).onchange=()=>{summary();snapshot()};
$('#reveal').onchange=snapshot;
init();
