'use strict';
const params=new URLSearchParams(location.search),symbol=params.get('symbol'),at=params.get('at');
let data=null,cursor=null;
const defs=[{id:'candles',title:'现货K线 · 绿涨红跌',keys:[]},{id:'trade',title:'交易连续性 · 有成交分钟占比',keys:['trade5','trade15','trade60'],percent:true},{id:'buy',title:'主动买入交易连续性 · 有主动买入分钟占比',keys:['buy5','buy15','buy60'],percent:true},{id:'amount',title:'成交额 / 主动买入额 · USDT',keys:['quote','taker_quote']}];
const colors=['#62b0ff','#f5c65b','#2ed3a1'];
defs.splice(3,0,{id:'state',title:'连续性状态 · 近6小时',keys:['buy_high','trade_high','buy_low'],percent:true,colors:['#62b0ff','#f5c65b','#8e9dad'],note:'高档占比＝所选窗口内C5≥80%的分钟占比；低档占比＝C5≤20%的分钟占比。C5为最近5分钟有成交/主动买入的分钟比例。每分钟滚动计算，3/6小时窗口分别需184/364个连续有效分钟；缺失或非法数据留空。用于活跃背景观察，不代表上涨概率。'});
function series(def){return def.id==='state'?(data.state_series||[]):data.candles}
const MIN_CANDLE_SPAN=.5;
function candleBounds(low,high){
 if(!finite(low)||!finite(high)||low<=0||high<low)return null;
 if(high/low-1>=MIN_CANDLE_SPAN)return {low,high};
 // Expand around the geometric centre; the complete visible wick range stays inside.
 const centre=Math.sqrt(low)*Math.sqrt(high),factor=Math.sqrt(1+MIN_CANDLE_SPAN);
 const lower=centre/factor;
 return {low:lower,high:Math.max(centre*factor,lower*(1+MIN_CANDLE_SPAN))};
}
function nearest(t,rows=data.candles){let low=0,high=rows.length-1;if(high<0)return null;while(low<high){const m=(low+high)>>1;if(rows[m].ms<t)low=m+1;else high=m}if(low&&Math.abs(rows[low-1].ms-t)<Math.abs(rows[low].ms-t))low--;return rows[low]}
function label(k){return ({trade5:'最近5分钟',trade15:'最近15分钟',trade60:'最近60分钟',buy5:'最近5分钟',buy15:'最近15分钟',buy60:'最近60分钟',buy_high:'主动买入高档占比（C5≥80%）',trade_high:'交易高档占比（C5≥80%）',buy_low:'主动买入低档占比（C5≤20%）',quote:'成交额',taker_quote:'主动买入额'})[k]||k}
function read(def,r){if(!r)return '';return time(r.ms)+(def.id==='candles'?` · O ${num(r.open,8)} H ${num(r.high,8)} L ${num(r.low,8)} C ${num(r.close,8)} Change ${finite(r.open)&&finite(r.close)?pct(r.close/r.open-1):'—'}`:' · '+def.keys.map(k=>label(k)+' '+(def.percent?pct(r[k]):num(r[k],2))).join(' · '))}
function draw(def){
 const rows=series(def);
 const canvas=$('#chart-'+def.id),rect=canvas.getBoundingClientRect(),dpr=devicePixelRatio||1,w=rect.width,h=rect.height,L=10,R=90,T=10,B=28;
 canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.lineWidth=1;
 const x=t=>L+(t-data.start_ms)/(data.end_ms-data.start_ms)*(w-L-R);let lo=Infinity,hi=-Infinity;
 for(const r of rows)for(const k of def.id==='candles'?['low','high']:def.keys)if(finite(r[k])){lo=Math.min(lo,r[k]);hi=Math.max(hi,r[k])}
 if(def.id==='candles'){
 const bounds=candleBounds(lo,hi);
 if(bounds){lo=bounds.low;hi=bounds.high}else{lo=0;hi=1}
 $('#candle-scale').textContent=bounds?'纵轴跨度 '+pct(hi/lo-1)+' · 最低50%；超过时按实际高低点显示':'暂无有效K线';
 $('#candle-scale').title='纵轴跨度 =（纵轴上界 ÷ 纵轴下界 − 1）；50%为整个纵轴范围，不是上下各50%。';
 canvas.dataset.yMin=String(lo);canvas.dataset.yMax=String(hi);
 }else if(def.percent){lo=0;hi=1}else{if(!finite(lo)){lo=0;hi=1}const pad=(hi-lo||1)*.05;lo-=pad;hi+=pad}
 const y=v=>T+(hi-v)/(hi-lo)*(h-T-B);ctx.font='11px system-ui';ctx.fillStyle='#9aadc1';ctx.strokeStyle='#304154';
 for(let i=0;i<4;i++){const v=hi-(hi-lo)*i/3,yy=y(v);ctx.beginPath();ctx.moveTo(L,yy);ctx.lineTo(w-R,yy);ctx.stroke();ctx.fillText(def.percent?pct(v,0):num(v,hi-lo<1?7:2),w-R+7,yy+4);const t=data.start_ms+(data.end_ms-data.start_ms)*i/3;ctx.textAlign=i===0?'left':i===3?'right':'center';ctx.fillText(time(t),x(t),h-7)}ctx.textAlign='left';
 ctx.save();ctx.beginPath();ctx.rect(L,T,w-L-R,h-T-B);ctx.clip();
 if(def.id==='candles'){
 const cw=Math.min(6,Math.max(.6,(w-L-R)/Math.max(1,data.candles.length)*.7));
 for(const r of data.candles){if(!finite(r.open)||!finite(r.close))continue;ctx.strokeStyle=ctx.fillStyle=r.close>=r.open?'#2ed3a1':'#ff6178';ctx.beginPath();ctx.moveTo(x(r.ms),y(r.high));ctx.lineTo(x(r.ms),y(r.low));ctx.stroke();ctx.fillRect(x(r.ms)-cw/2,Math.min(y(r.open),y(r.close)),cw,Math.max(1,Math.abs(y(r.close)-y(r.open))))}
 }else def.keys.forEach((k,i)=>{ctx.strokeStyle=(def.colors||colors)[i];ctx.setLineDash(k==='buy_low'?[5,4]:[]);ctx.beginPath();let connected=false;for(const r of rows){if(!finite(r[k])){connected=false;continue}if(connected)ctx.lineTo(x(r.ms),y(r[k]));else ctx.moveTo(x(r.ms),y(r[k]));connected=true}ctx.stroke()});
 ctx.setLineDash([]);
 if(data.end_ms>data.at_ms){ctx.fillStyle='#f5c65b09';ctx.fillRect(x(data.at_ms),T,w-R-x(data.at_ms),h-T-B)}
 if(def.id==='candles'){ctx.strokeStyle='#ffac62';const times=new Set(data.signals.filter(s=>s.bg_ok).map(s=>s.confirm_ms));for(const t of times){ctx.beginPath();ctx.moveTo(x(t),T);ctx.lineTo(x(t),T+12);ctx.stroke()}}
 ctx.setLineDash([4,4]);ctx.strokeStyle='#62b0ff';ctx.beginPath();ctx.moveTo(x(data.at_ms),T);ctx.lineTo(x(data.at_ms),h-B);ctx.stroke();if(cursor!==null){ctx.strokeStyle='#bacbdf';ctx.beginPath();ctx.moveTo(x(cursor),T);ctx.lineTo(x(cursor),h-B);ctx.stroke()}ctx.restore();
 $('#read-'+def.id).textContent=cursor===null?'输入时点：'+time(data.at_ms):read(def,nearest(cursor,rows));
}
function drawAll(){if(data)defs.forEach(draw)}
async function load(){
 $('#reload').disabled=true;
 try{data=await api('/api/detail?'+new URLSearchParams({symbol,at,before:$('#before').value,after:$('#after').value,period:$('#period').value,state_window:$('#state-window').value}));cursor=null;
 defs.find(d=>d.id==='state').title='连续性状态 · 近'+Number($('#state-window').value)/60+'小时';
 $('#back').href='/?at='+encodeURIComponent(at);$('#title').textContent=symbol+' · 连续性信号详情';$('#subtitle').textContent=time(data.at_ms)+' 北京时间';notice(data.note);
 $('#charts').innerHTML=defs.map(d=>`<section class="card ${d.id==='candles'?'candles':''}"><h2>${esc(d.title)}</h2><div class="legend" ${d.id==='candles'?'id="candle-scale"':''}>${d.keys.map((k,i)=>`<span style="color:${(d.colors||colors)[i]}">${label(k)}</span>`).join('　')}</div><div id="read-${d.id}" class="readout"></div><canvas id="chart-${d.id}"></canvas>${d.note?`<p class="muted">${esc(d.note)}</p>`:''}</section>`).join('');
 for(const d of defs){const canvas=$('#chart-'+d.id);canvas.onmousemove=e=>{const r=canvas.getBoundingClientRect(),ratio=Math.max(0,Math.min(1,(e.clientX-r.left-10)/(r.width-100))),row=nearest(data.start_ms+ratio*(data.end_ms-data.start_ms),series(d));if(!row)return;cursor=row.ms;drawAll();const tip=$('#tooltip');tip.textContent=read(d,row);tip.classList.remove('hidden');tip.style.left=Math.max(8,Math.min(e.clientX+12,innerWidth-tip.offsetWidth-8))+'px';tip.style.top=Math.max(8,Math.min(e.clientY+12,innerHeight-tip.offsetHeight-8))+'px'};canvas.onmouseleave=()=>{cursor=null;$('#tooltip').classList.add('hidden');drawAll()}}
 drawAll();
 }catch(e){notice(e.message,true)}finally{$('#reload').disabled=false}
}
for(const id of ['before','after','period','state-window'])$('#'+id).onchange=load;$('#reload').onclick=load;window.onresize=drawAll;
if(symbol&&at)load();else notice('链接缺少symbol/at，请从回放列表进入。',true);
