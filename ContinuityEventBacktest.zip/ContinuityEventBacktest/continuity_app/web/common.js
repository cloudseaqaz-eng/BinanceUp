'use strict';
const $=s=>document.querySelector(s),finite=v=>typeof v==='number'&&Number.isFinite(v);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=(v,d=2)=>finite(v)?v.toLocaleString('zh-CN',{maximumFractionDigits:d}):'—';
const pct=(v,d=1)=>finite(v)?num(v*100,d)+'%':'—';
const time=v=>v==null?'—':new Date(v).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false});
const localInput=v=>new Date(new Date(v).getTime()+8*3600000).toISOString().slice(0,16);
function notice(s,error=false){$('#notice').textContent=s;$('#notice').className='notice'+(error?' error':'')}
async function api(url){const r=await fetch(url);const j=await r.json();if(!r.ok)throw Error(j.error||r.statusText);return j}
function atISO(v){return v+':00+08:00'}

const kindLabel=k=>({trade:'交易',buy:'主动买入'})[k]||k;
