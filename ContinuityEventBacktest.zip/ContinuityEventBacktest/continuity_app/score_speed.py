"""Causal score changes in points/hour, with an optional one-sided EMA.

Compute against the complete score history before slicing a displayed window.
Missing scores invalidate the whole difference window and reset EMA state.
"""
import numpy as np
import pandas as pd


def settings(window=30, half_life=5):
    if window not in (30, 60):
        raise ValueError('积分速度窗口须为30或60分钟')
    if half_life not in (0, 5, 10):
        raise ValueError('积分速度EMA半衰期须为0、5或10分钟')
    return {'version': 1, 'window_minutes': window,
            'ema_half_life_minutes': half_life, 'unit': 'score_points_per_hour',
            'missing': 'require_complete_difference_window_and_reset_ema'}


def _smooth_segments(raw, half_life):
    if not half_life:
        return raw.copy()
    result = np.full(len(raw), np.nan)
    finite = np.isfinite(raw)
    edges = np.diff(np.r_[False, finite, False].astype(np.int8))
    for start, stop in zip(np.flatnonzero(edges == 1), np.flatnonzero(edges == -1)):
        # Each segment starts at its first observed speed, without carrying
        # stale EMA state over an unknown interval or substituting zeros.
        result[start:stop] = pd.Series(raw[start:stop]).ewm(
            halflife=half_life, adjust=False).mean().to_numpy()
    return result


def metrics(scores, window=30, half_life=5):
    """Return raw/smoothed buy and trade speed on a complete one-minute grid."""
    settings(window, half_life)
    if not isinstance(scores.index, pd.DatetimeIndex) or scores.index.hasnans:
        raise ValueError('积分速度需要有效的一分钟时间索引')
    if len(scores) > 1 and not np.all(
            scores.index[1:] - scores.index[:-1] == pd.Timedelta(minutes=1)):
        raise ValueError('积分速度需要连续、升序的一分钟时间索引；缺失分钟须先补为空值')
    result = pd.DataFrame(index=scores.index)
    for kind in ('buy', 'trade'):
        values = scores[kind + '_score'].to_numpy(dtype=float)
        known = np.isfinite(values)
        complete = pd.Series(known).rolling(window + 1, min_periods=window + 1).sum().eq(window + 1).to_numpy()
        raw = np.full(len(values), np.nan)
        # Only subtract finite endpoints; unknown interior minutes are also
        # excluded by complete, even when the two endpoints happen to exist.
        positions = np.flatnonzero(complete)
        raw[positions] = (values[positions] - values[positions - window]) * (60 / window)
        result[kind + '_speed_raw'] = raw
        result[kind + '_speed'] = _smooth_segments(raw, half_life)
    return result
