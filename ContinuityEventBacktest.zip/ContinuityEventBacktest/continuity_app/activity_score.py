"""Causal, normalized C5 scores with a seven-day slow head and one-day fast tail.

Input is a complete one-minute time grid. Unknown observations contribute neither
value nor known weight; elapsed minutes still age all previous contributions.
"""
import numpy as np
import pandas as pd

DAY=1440
TRANSITION=7*DAY
WARMUP=14*DAY
MIN_COVERAGE=.99
SLOW=2**(-1/TRANSITION)
FAST=2**(-1/DAY)
BOUNDARY=SLOW**TRANSITION
TOTAL_WEIGHT=(1-BOUNDARY)/(1-SLOW)+BOUNDARY/(1-FAST)


def _exponential_sum(values,factor):
    alpha=1-factor
    # A leading zero gives a zero initial state instead of ewm's first-value seed.
    return pd.Series(np.r_[0.,values]).ewm(alpha=alpha,adjust=False).mean().to_numpy()[1:]/alpha


def weighted_sum(values):
    """Exact age kernel, including its infinite fast tail, over available history."""
    slow=_exponential_sum(values,SLOW)
    fast=_exponential_sum(values,FAST)
    result=slow.copy()
    if len(result)>TRANSITION:
        result[TRANSITION:]+=BOUNDARY*(fast[:-TRANSITION]-slow[:-TRANSITION])
    return result


def metrics(c5):
    result=pd.DataFrame(index=c5.index)
    for kind in ('trade','buy'):
        values=c5[kind+'5'].to_numpy(dtype=float)
        known=np.isfinite(values)&(values>=0)&(values<=1)
        numerator=weighted_sum(np.where(known,values,0.))
        denominator=weighted_sum(known.astype(float))
        coverage=np.clip(denominator/TOTAL_WEIGHT,0,1)
        score=np.full(len(values),np.nan)
        first=np.flatnonzero(known)
        if len(first):
            elapsed=(c5.index-c5.index[first[0]]).total_seconds()/60
            ready=known&(elapsed>=WARMUP)&(coverage>=MIN_COVERAGE)
            np.divide(100*numerator,denominator,out=score,where=ready)
        result[kind+'_score']=np.clip(score,0,100)
        result[kind+'_coverage']=coverage
    return result


def settings():
    return {'version':1,'input':'linear C5','transition_days':7,'slow_half_life_days':7,
            'fast_half_life_days':1,'warmup_days':14,'minimum_coverage':MIN_COVERAGE}
