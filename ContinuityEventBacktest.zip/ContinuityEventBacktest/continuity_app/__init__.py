"""Independent continuity-event analysis; never imports the scoring project."""
