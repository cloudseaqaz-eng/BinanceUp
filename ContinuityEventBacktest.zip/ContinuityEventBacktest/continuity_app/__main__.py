import argparse,json,math
from .core import Options,build,Store
from .server import serve


def main():
    p=argparse.ArgumentParser(description='独立连续性激活回测：输入只读，结果另存')
    sub=p.add_subparsers(dest='command',required=True)
    b=sub.add_parser('build');b.add_argument('--data',required=True);b.add_argument('--results',required=True)
    b.add_argument('--holds',default='5,10,15,30,60');b.add_argument('--start');b.add_argument('--end')
    b.add_argument('--background-hours',type=int,default=6);b.add_argument('--background-mean',type=float,default=.6);b.add_argument('--background-full',type=float,default=.2)
    b.add_argument('--max-r60',type=float,default=.05);b.add_argument('--max-dd24',type=float,default=.10)
    b.add_argument('--cooldown-hours',type=int,default=24);b.add_argument('--fresh-hours',type=int,default=6)
    s=sub.add_parser('serve');s.add_argument('--results',required=True);s.add_argument('--port',type=int,default=8768)
    d=sub.add_parser('diagnose');d.add_argument('--results',required=True);d.add_argument('--symbol',required=True);d.add_argument('--at',required=True)
    d.add_argument('--hold',type=int,default=15);d.add_argument('--kind',choices=['any','trade','buy'],default='any');d.add_argument('--fresh',type=float,default=6);d.add_argument('--no-price-filter',action='store_true')
    d.add_argument('--no-background-filter',action='store_true')
    a=p.parse_args()
    if a.command=='serve':serve(a.results,a.port);return
    if a.command=='diagnose':
        print(json.dumps(Store(a.results).diagnose(a.symbol,a.at,a.hold,a.kind,not a.no_price_filter,a.fresh,not a.no_background_filter),ensure_ascii=False,indent=2));return
    holds=tuple(sorted(set(int(x) for x in a.holds.split(','))))
    if not holds or min(holds)<1 or max(holds)>1440:p.error('持续时长必须在1至1440分钟')
    if not 1<=a.background_hours<=168 or not 0<=a.background_mean<=1 or not 0<=a.background_full<=1 or a.cooldown_hours<1 or not 1<=a.fresh_hours<=168:p.error('背景、冷却或新激活窗口参数无效')
    if not math.isfinite(a.max_r60) or not math.isfinite(a.max_dd24) or a.max_r60<=-1 or a.max_dd24<0:p.error('价格阈值无效')
    opt=Options(holds=holds,background_minutes=a.background_hours*60,background_mean=a.background_mean,background_full=a.background_full,
                max_r60=a.max_r60,max_dd24=a.max_dd24,cooldown_minutes=a.cooldown_hours*60,fresh_hours=a.fresh_hours,start=a.start,end=a.end)
    meta=build(a.data,a.results,opt)
    print(f'完成：{len(meta["sources"])}币，失败{len(meta["errors"])}。启动：python -m continuity_app serve --results "{a.results}"')

if __name__=='__main__':main()
