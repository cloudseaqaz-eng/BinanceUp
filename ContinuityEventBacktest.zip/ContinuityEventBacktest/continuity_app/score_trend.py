"""Causal multi-hour OLS score trends and persistent short-speed occupancy.

Run against full minute history before slicing a display window. Unknown minutes
invalidate the relevant complete window; no interpolation or future fitting.
"""
import numpy as np
import pandas as pd

from .score_speed import metrics as speed_metrics


def settings(window=360, threshold=.02):
    if not isinstance(window, (int, np.integer)) or window not in (180, 360, 720):
        raise ValueError('积分趋势窗口须为180、360或720分钟')
    if threshold not in (0, .02, .05, .1):
        raise ValueError('上升速度阈值须为0、0.02、0.05或0.1积分点/小时')
    return {'version': 1, 'window_minutes': int(window),
            'threshold_points_per_hour': float(threshold),
            'short_window_minutes': 60, 'short_ema_half_life_minutes': 10,
            'unit': 'score_points_per_hour',
            'trend_method': 'trailing_ols_window_plus_one_points',
            'rising_method': 'fraction_of_complete_window_strictly_above_threshold'}


def metrics(scores, window=360, threshold=.02):
    """Return each channel's OLS slope, rising share, and fixed short speed."""
    settings(window, threshold)
    # This also validates the complete, ascending one-minute input index.
    short = speed_metrics(scores, window=60, half_life=10)
    result = pd.DataFrame(index=scores.index)
    centred = np.arange(window + 1, dtype=float) - window / 2
    scale = 60 / np.dot(centred, centred)
    for kind in ('buy', 'trade'):
        values = scores[kind + '_score'].to_numpy(dtype=float)
        known = np.isfinite(values)
        complete = pd.Series(known).rolling(window + 1, min_periods=window + 1).sum().eq(window + 1).to_numpy()
        trend = np.full(len(values), np.nan)
        if len(values) > window:
            # Correlation aligns centred oldest->newest time weights to each
            # trailing window. Dotting a centred time vector cancels intercepts.
            fitted = np.correlate(np.where(known, values, 0.), centred, mode='valid') * scale
            trend[window:] = np.where(complete[window:], fitted, np.nan)
            # Suppress roundoff at exactly flat levels, not actual small trends.
            trend[np.abs(trend) < 1e-12] = 0.
        speed = short[kind + '_speed']
        rising = speed.gt(threshold).astype(float).where(np.isfinite(speed))
        result[kind + '_trend'] = trend
        result[kind + '_rising'] = rising.rolling(window, min_periods=window).mean()
        result[kind + '_short_speed'] = speed
    return result
