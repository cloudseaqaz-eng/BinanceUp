from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlparse,parse_qs
import json,mimetypes,csv,io
from .core import Store,clean

WEB=Path(__file__).with_name('web')


def handler(store):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            url=urlparse(self.path);q=parse_qs(url.query);arg=lambda k,d=None:q.get(k,[d])[0]
            try:
                if url.path=='/api/meta':body=store.meta()
                elif url.path in ('/api/summary','/api/events.csv'):
                    body=store.summary(int(arg('hold',15)),arg('kind','any'),arg('reference','confirm'),arg('price','1')=='1')
                    if url.path.endswith('.csv'):
                        rows=body['events'];s=io.StringIO();fields=sorted(set().union(*(r.keys() for r in rows))) if rows else ['symbol','confirm_ms']
                        w=csv.DictWriter(s,fieldnames=fields);w.writeheader();w.writerows(rows)
                        return self.send_bytes(('\ufeff'+s.getvalue()).encode(),'text/csv; charset=utf-8')
                    body['events_total']=len(body['events']);body['events']=body['events'][-200:]
                elif url.path=='/api/snapshot':body=store.snapshot(arg('at'),int(arg('hold',15)),arg('kind','any'),arg('price','1')=='1',float(arg('fresh',6)),arg('reveal','0')=='1')
                elif url.path=='/api/detail':body=store.detail(arg('symbol'),arg('at'),int(arg('before',168)),int(arg('after',0)),int(arg('period',5)))
                elif url.path=='/favicon.ico':return self.send_bytes(b'','image/x-icon',204)
                else:
                    name='index.html' if url.path=='/' else url.path.lstrip('/')
                    if name not in ('index.html','detail.html','app.css','app.js','detail.js','common.js'):return self.send_bytes(b'not found','text/plain',404)
                    return self.send_bytes((WEB/name).read_bytes(),mimetypes.guess_type(name)[0] or 'text/plain')
                self.send_bytes(json.dumps(clean(body),ensure_ascii=False,allow_nan=False).encode(),'application/json; charset=utf-8')
            except Exception as exc:self.send_bytes(json.dumps({'error':str(exc)},ensure_ascii=False).encode(),'application/json; charset=utf-8',400)
        def send_bytes(self,b,content_type,status=200):
            self.send_response(status);self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(b)
    return Handler


def serve(results,port):
    store=Store(results);store.meta()
    server=ThreadingHTTPServer(('127.0.0.1',port),handler(store))
    print(f'打开 http://127.0.0.1:{port} （独立程序，只读原始K线）',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
