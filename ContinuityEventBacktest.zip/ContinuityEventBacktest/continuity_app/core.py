from pathlib import Path
from dataclasses import dataclass, asdict
import hashlib,json,math,os,sqlite3
import numpy as np
import pandas as pd

VERSION=1
MINUTE=60000
HORIZON=1440
REQUIRED=['open','high','low','close','quote','trades','taker_quote']


def stamp(value):
    t=pd.Timestamp(value)
    return (t.tz_localize('Asia/Shanghai') if t.tzinfo is None else t).tz_convert('UTC').floor('min')


def ms(t): return int(stamp(t).value//10**6)
def iso(t): return pd.Timestamp(int(t),unit='ms',tz='UTC').isoformat()


def clean(value):
    if isinstance(value,dict):return {k:clean(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [clean(v) for v in value]
    if isinstance(value,(np.integer,np.floating)):value=value.item()
    if isinstance(value,float) and not math.isfinite(value):return None
    return value


@dataclass
class Options:
    holds: tuple=(5,10,15,30,60)
    background_minutes: int=360
    background_mean: float=.6
    background_full: float=.2
    max_r60: float=.05
    max_dd24: float=.10
    cooldown_minutes: int=1440
    fresh_hours: int=6
    start: str|None=None
    end: str|None=None


def read_raw(path,start=None,end=None):
    filters=[]
    if start is not None:filters.append(('time','>=',stamp(start)))
    if end is not None:filters.append(('time','<=',stamp(end)))
    r=pd.read_parquet(path,columns=REQUIRED,filters=filters or None)
    if not isinstance(r.index,pd.DatetimeIndex):raise ValueError('Parquet必须有分钟时间索引')
    r.index=pd.to_datetime(r.index,utc=True)
    if r.index.has_duplicates:raise ValueError('时间戳重复，请核查原始数据')
    if not r.index.equals(r.index.floor('min')):raise ValueError('需要已收盘的一分钟K线时间戳')
    return r.sort_index()


def grid(raw):
    if raw.empty:return raw
    return raw.reindex(pd.date_range(raw.index.min(),raw.index.max(),freq='min',name='time'))


def valid_rows(r):
    p=r[['open','high','low','close']]
    valid=np.isfinite(r[REQUIRED]).all(axis=1)&p.gt(0).all(axis=1)
    valid &= r.high.ge(p[['open','close']].max(axis=1))&r.low.le(p[['open','close']].min(axis=1))
    valid &= r[['quote','trades','taker_quote']].ge(0).all(axis=1)&r.taker_quote.le(r.quote*1.000001)
    return valid


def price_features(r):
    close=r.close
    low=r.low.rolling(1440,min_periods=1440).min()
    return pd.DataFrame({'r60':close/close.shift(60)-1,'r24':close/close.shift(1440)-1,
                         'dd24':close/low-1,'quote24':r.quote.rolling(1440,min_periods=1440).sum()},index=r.index)


def passes_price(row,opt,enabled=True):
    return not enabled or (pd.notna(row['r60']) and pd.notna(row['dd24']) and row['r60']<=opt.max_r60 and row['dd24']<=opt.max_dd24)


def forward(series,op):
    # At i this covers exactly (i, i+1440], never the signal candle itself.
    rolling=series.iloc[::-1].rolling(HORIZON,min_periods=HORIZON)
    return getattr(rolling,op)().iloc[::-1].shift(-1)


def analyze(raw,symbol,opt):
    r=grid(raw)
    if r.empty:return [],[],{'symbol':symbol,'rows':0}
    valid=valid_rows(r)
    masked=r.where(valid)
    prices=price_features(masked)
    known=forward(valid.astype(float),'sum').eq(HORIZON)
    future_high=forward(masked.high,'max')
    future_low=forward(masked.low,'min')
    future_close=forward(masked.close,'max')
    intervals=[];events=[]
    times=r.index.asi8//10**6
    evaluation_start=ms(opt.start) if opt.start else int(times[0])
    evaluation_end=ms(opt.end) if opt.end else int(times[-1])
    for kind,column in [('trade','trades'),('buy','taker_quote')]:
        active=r[column].gt(0)&valid
        c5=active.astype(float).where(valid).rolling(5,min_periods=5).mean()
        bgmean=c5.rolling(opt.background_minutes,min_periods=opt.background_minutes).mean()
        bgfull=c5.eq(1).astype(float).where(c5.notna()).rolling(opt.background_minutes,min_periods=opt.background_minutes).mean()
        a=active.to_numpy();starts=np.flatnonzero(a&~np.r_[False,a[:-1]])
        ends=np.flatnonzero(a&~np.r_[a[1:],False])
        for s,e in zip(starts,ends):
            background_mean=bgmean.iloc[s-1] if s else np.nan
            background_full=bgfull.iloc[s-1] if s else np.nan
            bg_ok=bool(pd.notna(background_mean) and pd.notna(background_full) and background_mean<=opt.background_mean and background_full<=opt.background_full)
            for hold in opt.holds:
                i=s+hold+3
                if i>e:continue
                row={'symbol':symbol,'kind':kind,'hold':hold,'start_ms':int(times[s]),'confirm_ms':int(times[i]),'end_ms':int(times[e]),
                     'bg_mean':background_mean,'bg_full':background_full,'bg_ok':int(bg_ok)}
                intervals.append(clean(row))
                if not evaluation_start<=times[i]<=evaluation_end:continue
                event={**row,**prices.iloc[i].to_dict(),'price_confirm':masked.close.iloc[i],
                       'price_previous':masked.close.iloc[i-1] if i else np.nan,
                       'price_before':masked.close.iloc[s-1] if s else np.nan,'future_complete':int(known.iloc[i]),
                       'future_high':future_high.iloc[i],'future_low':future_low.iloc[i],
                       'future_max_close':future_close.iloc[i]}
                for h in (60,360,1440):
                    event[f'return_{h}']=(masked.close.iloc[i+h]/event['price_confirm']-1) if i+h<len(r) and valid.iloc[i+1:i+h+1].all() else np.nan
                for ref in ('confirm','previous','before'):
                    p=event['price_'+ref]
                    for target in (.1,.2,.3):
                        name=str(int(target*100))
                        event[f'hit_{ref}_{name}']=int(future_high.iloc[i]>=p*(1+target)) if known.iloc[i] and pd.notna(p) else None
                    if known.iloc[i] and pd.notna(p):
                        hits=np.flatnonzero(masked.high.iloc[i+1:i+1441].to_numpy()>=p*1.2)
                        first=int(hits[0]+1) if len(hits) else None
                        event[f'minutes20_{ref}']=first
                        event[f'adverse20_{ref}']=masked.low.iloc[i+1:i+first+1].min()/p-1 if first else None
                        event[f'mfe_{ref}']=future_high.iloc[i]/p-1
                        event[f'mae_{ref}']=future_low.iloc[i]/p-1
                events.append(clean(event))
    return intervals,events,{'symbol':symbol,'rows':len(r),'invalid_minutes':int((~valid).sum()),
                             'first_ms':int(times[0]),'last_ms':int(times[-1])}


def safe_output(data,output):
    data=Path(data).resolve();output=Path(output).resolve()
    if data==output or data in output.parents or output in data.parents:
        raise ValueError('结果目录必须与输入数据目录分离，不能互为父子目录')
    return data,output


def build(data,output,opt,progress=print):
    data,output=safe_output(data,output)
    raw_dir=data/'raw' if (data/'raw').is_dir() else data
    files=[p for p in sorted(raw_dir.glob('*.parquet')) if not any(x in p.stem for x in ('.oi','.funding'))]
    if not files:raise ValueError('找不到原始K线Parquet文件')
    config=data/'config.json'
    if config.exists():
        cfg=json.loads(config.read_text())
        for key_name in ('start','end'):
            if not getattr(opt,key_name) and cfg.get(key_name):
                value=pd.Timestamp(cfg[key_name])
                value=value.tz_localize('UTC') if value.tzinfo is None else value.tz_convert('UTC')
                setattr(opt,key_name,value.isoformat())
    if opt.start and opt.end and stamp(opt.start)>stamp(opt.end):raise ValueError('start晚于end')
    output.mkdir(parents=True,exist_ok=True)
    calculation=asdict(opt)
    for name in ('cooldown_minutes','fresh_hours','max_r60','max_dd24'):calculation.pop(name)
    key=hashlib.sha256(json.dumps({'version':VERSION,'options':calculation},sort_keys=True).encode()).hexdigest()[:16]
    cache=output/'cache'/key;cache.mkdir(parents=True,exist_ok=True)
    marker=output/'.building';marker.write_text('构建中，现有数据库继续可读')
    temp=output/'events.building.sqlite';temp.unlink(missing_ok=True)
    con=sqlite3.connect(temp)
    con.execute('CREATE TABLE intervals(symbol TEXT,kind TEXT,hold INTEGER,start_ms INTEGER,confirm_ms INTEGER,end_ms INTEGER,bg_ok INTEGER,payload TEXT)')
    con.execute('CREATE TABLE events(symbol TEXT,kind TEXT,hold INTEGER,confirm_ms INTEGER,payload TEXT)')
    con.execute('CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT)')
    sources={};audit=[];errors=[]
    cfg=json.loads(config.read_text()) if config.exists() else {}
    present={p.stem for p in files}
    errors.extend({'symbol':s,'error':'config中列出，但缺少原始K线文件'} for s in cfg.get('symbols',[]) if s not in present)
    try:
        for number,path in enumerate(files,1):
            try:
                stat=path.stat();finger={'path':str(path.resolve()),'size':stat.st_size,'mtime_ns':stat.st_mtime_ns}
                cached=cache/(path.stem+'.json')
                result=json.loads(cached.read_text()) if cached.exists() else None
                reused=bool(result and all(result['source'].get(k)==v for k,v in finger.items()))
                if not reused:
                    raw=read_raw(path)
                    intervals,events,info=analyze(raw,path.stem,opt)
                    finger['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
                    # Fingerprint includes content; quick reuse comparison uses immutable stat identity.
                    result={'source':finger,'intervals':intervals,'events':events,'audit':info}
                    staging=cached.with_suffix('.tmp');staging.write_text(json.dumps(clean(result),ensure_ascii=False,allow_nan=False));os.replace(staging,cached)
                sources[path.stem]=result['source'];audit.append(result['audit'])
                con.executemany('INSERT INTO intervals VALUES(?,?,?,?,?,?,?,?)',[(x['symbol'],x['kind'],x['hold'],x['start_ms'],x['confirm_ms'],x['end_ms'],x['bg_ok'],json.dumps(x,ensure_ascii=False)) for x in result['intervals']])
                con.executemany('INSERT INTO events VALUES(?,?,?,?,?)',[(x['symbol'],x['kind'],x['hold'],x['confirm_ms'],json.dumps(x,ensure_ascii=False)) for x in result['events']])
                progress(f'{number}/{len(files)} {path.stem}: 区间{len(result["intervals"])}，事件{len(result["events"])}'+('（缓存）' if reused else ''))
            except Exception as exc:
                errors.append({'symbol':path.stem,'error':str(exc)})
                progress(f'{path.stem}: {exc}')
        if not sources:raise ValueError('没有成功读取任何币种：'+json.dumps(errors,ensure_ascii=False))
        meta={'built_at':pd.Timestamp.now(tz='UTC').isoformat(),'version':VERSION,'data':str(data),'options':asdict(opt),'sources':sources,'audit':audit,'errors':errors,
              'start_ms':ms(opt.start) if opt.start else min(x['first_ms'] for x in audit),
              'end_ms':ms(opt.end) if opt.end else max(x['last_ms'] for x in audit)}
        con.execute('INSERT INTO metadata VALUES(?,?)',('meta',json.dumps(meta,ensure_ascii=False)))
        con.execute('CREATE INDEX interval_time ON intervals(hold,confirm_ms,end_ms)')
        con.execute('CREATE INDEX event_time ON events(hold,confirm_ms)')
        con.commit();con.close();os.replace(temp,output/'events.sqlite');marker.unlink(missing_ok=True)
        return meta
    except Exception:
        con.close();temp.unlink(missing_ok=True);raise


class Store:
    def __init__(self,output):self.output=Path(output).resolve()
    def connect(self):return sqlite3.connect((self.output/'events.sqlite').as_uri()+'?mode=ro',uri=True)
    def meta(self):
        with self.connect() as con:meta=json.loads(con.execute('SELECT value FROM metadata WHERE key="meta"').fetchone()[0])
        for symbol in meta['sources']:self.source(symbol,meta)
        return meta
    def source(self,symbol,meta):
        if symbol not in meta['sources']:raise ValueError('未知交易对')
        item=meta['sources'][symbol];path=Path(item['path']);st=path.stat()
        if st.st_size!=item['size'] or st.st_mtime_ns!=item['mtime_ns']:raise ValueError('源数据已改变，请重新build后查询')
        return path
    def summary(self,hold=15,kind='any',reference='confirm',price_filter=True):
        meta=self.meta();opt=Options(**meta['options'])
        if hold not in opt.holds or kind not in ('any','trade','buy') or reference not in ('confirm','previous','before'):raise ValueError('未知统计选项')
        with self.connect() as con:
            rows=[json.loads(x[0]) for x in con.execute('SELECT payload FROM events WHERE hold=? ORDER BY confirm_ms,symbol,kind',(hold,))]
        if kind!='any':rows=[r for r in rows if r['kind']==kind]
        cold=[r for r in rows if r['bg_ok']]
        filtered=[r for r in cold if passes_price(r,opt,price_filter)]
        selected=[];last={}
        for row in filtered:
            t=row['confirm_ms'];symbol=row['symbol']
            if symbol in last and t-last[symbol]<opt.cooldown_minutes*MINUTE:
                if selected and selected[-1]['symbol']==symbol and selected[-1]['confirm_ms']==t:
                    selected[-1].setdefault('kinds',[selected[-1]['kind']]).append(row['kind'])
                continue
            row['kinds']=[row['kind']]
            last[symbol]=t;selected.append(row)
        cells=[]
        for target in (10,20,30):
            key=f'hit_{reference}_{target}'
            valid=[r for r in selected if r.get(key) is not None]
            successes=sum(r[key] for r in valid);n=len(valid)
            p=successes/n if n else None
            if n:
                z=1.96;den=1+z*z/n;center=(p+z*z/(2*n))/den;half=z*((p*(1-p)/n+z*z/(4*n*n))**.5)/den
                ci=[max(0,center-half),min(1,center+half)]
            else:ci=[None,None]
            cells.append({'target':target,'success':successes,'n':n,'unknown':len(selected)-n,'probability':p,'ci95':ci})
        per_symbol={}
        for r in selected:
            if r.get(f'hit_{reference}_20') is not None:
                count=per_symbol.setdefault(r['symbol'],[0,0]);count[0]+=r[f'hit_{reference}_20'];count[1]+=1
        return clean({'hold':hold,'kind':kind,'reference':reference,'price_filter':price_filter,'candidates':len(rows),'cold':len(cold),'price_pass':len(filtered),
                      'deduplicated':len(selected),'cells':cells,'per_symbol':per_symbol,'events':selected,'note':f'概率按首次确认事件统计；跨类型any去重、{opt.cooldown_minutes/60:g}h冷却。置信区间为事件级Wilson近似，币/日期相关会降低有效样本量。'})
    def snapshot(self,at,hold=15,kind='any',price_filter=True,fresh_hours=None,reveal=False):
        meta=self.meta();opt=Options(**meta['options']);t=ms(at)
        if not meta['start_ms']<=t<=meta['end_ms']:raise ValueError('时间超出构建的实验区间')
        if hold not in opt.holds or kind not in ('any','trade','buy'):raise ValueError('未知筛选')
        fresh=opt.fresh_hours if fresh_hours is None else fresh_hours
        if not 0<=fresh<=168:raise ValueError('新激活窗口应在0至168小时，0为不限')
        with self.connect() as con:
            runs=[json.loads(x[0]) for x in con.execute('SELECT payload FROM intervals WHERE hold=? AND confirm_ms<=? AND end_ms>=? AND confirm_ms>=?',(hold,t,t,t-fresh*3600000 if fresh else 0))]
        grouped={}
        for r in runs:
            if r['bg_ok'] and (kind=='any' or kind==r['kind']):grouped.setdefault(r['symbol'],[]).append(r)
        rows=[];errors=[]
        for symbol,matching in grouped.items():
            try:
                raw=grid(read_raw(self.source(symbol,meta),iso(t-1440*MINUTE),iso(t)))
                raw=raw.reindex(pd.date_range(pd.Timestamp(t-1440*MINUTE,unit='ms',tz='UTC'),pd.Timestamp(t,unit='ms',tz='UTC'),freq='min',name='time'))
                raw=raw.where(valid_rows(raw));features=price_features(raw).iloc[-1].to_dict()
                if pd.isna(raw.close.iloc[-1]) or not passes_price(features,opt,price_filter):continue
                lead=min(matching,key=lambda r:r['confirm_ms'])
                row={**lead,**features,'kinds':sorted({x['kind'] for x in matching}),'close':raw.close.iloc[-1],
                     'durations':{x['kind']:int((t-x['start_ms'])//MINUTE-3) for x in matching},
                     'duration':max(int((t-x['start_ms'])//MINUTE-3) for x in matching),
                     'age_minutes':(t-lead['confirm_ms'])//MINUTE,'backgrounds':{x['kind']:{'mean':x['bg_mean'],'full':x['bg_full']} for x in matching}}
                if reveal:row['future']=self.outcome_at(symbol,t,lead['start_ms'],meta)
                row.pop('end_ms',None)  # The eventual run end is unknown at the queried time.
                rows.append(row)
            except Exception as exc:errors.append({'symbol':symbol,'error':str(exc)})
        rows.sort(key=lambda r:(-r['duration'],r['symbol']))
        return clean({'at_ms':t,'rows':rows,'errors':errors,'future_revealed':reveal,'note':'仅使用查询时点已知数据筛选；排序为当前连续100%时长。未来揭晓以输入时间为起点，区别于总体统计的首次确认时刻。'})
    def outcome_at(self,symbol,t,start_ms,meta):
        raw=read_raw(self.source(symbol,meta),iso(min(start_ms-MINUTE,t-MINUTE)),iso(t+HORIZON*MINUTE))
        ix=pd.date_range(pd.Timestamp(t+MINUTE,unit='ms',tz='UTC'),periods=HORIZON,freq='min',name='time')
        future=raw.reindex(ix);ok=bool(valid_rows(future).all())
        def close_at(x):return raw.close.get(pd.Timestamp(x,unit='ms',tz='UTC'),np.nan)
        refs={'confirm':close_at(t),'previous':close_at(t-MINUTE),'before':close_at(start_ms-MINUTE)}
        result={'complete':ok}
        for ref,p in refs.items():
            result[ref]={'price':p,'max_gain':future.high.max()/p-1 if ok and pd.notna(p) else None,
                         'hit20':bool(future.high.max()>=p*1.2) if ok and pd.notna(p) else None}
        return clean(result)
    def detail(self,symbol,at,before=168,after=0,period=5):
        meta=self.meta();t=ms(at)
        if not meta['start_ms']<=t<=meta['end_ms'] or before not in (168,336) or after not in (0,168) or period not in (1,3,5,15,60):raise ValueError('不支持的时间或窗口')
        path=self.source(symbol,meta)
        start=t-before*3600000;end=t+after*3600000
        raw=read_raw(path,iso(start-60*MINUTE),iso(end))
        if raw.empty:raise ValueError('窗口内没有行情')
        raw=grid(raw);raw=raw.where(valid_rows(raw))
        for kind,col in [('trade','trades'),('buy','taker_quote')]:
            active=raw[col].gt(0).astype(float).where(raw[col].notna())
            for window in (5,15,60):raw[f'{kind}{window}']=active.rolling(window,min_periods=window).mean()
        actual_end=min(end,int(raw.index.max().value//10**6))
        g=raw.loc[iso(start):iso(actual_end)].resample(f'{period}min',closed='right',label='right')
        candles=g.agg({'open':'first','high':'max','low':'min','close':'last','quote':'sum','taker_quote':'sum'})
        candles.loc[g.close.count()!=period]=np.nan
        candles=candles.join(raw[[f'{k}{w}' for k in ('trade','buy') for w in (5,15,60)]].reindex(candles.index))
        candles=candles.loc[candles.index<=pd.Timestamp(actual_end,unit='ms',tz='UTC')]
        candles['ms']=candles.index.asi8//10**6
        with self.connect() as con:
            signals=[json.loads(x[0]) for x in con.execute('SELECT payload FROM intervals WHERE symbol=? AND confirm_ms BETWEEN ? AND ? ORDER BY confirm_ms',(symbol,start,min(t,actual_end)))]
        for signal in signals:signal.pop('end_ms',None)
        return clean({'symbol':symbol,'at_ms':t,'start_ms':start,'end_ms':actual_end,'period':period,'candles':candles.to_dict('records'),
                      'signals':signals,'note':'绿涨红跌；事件确认标记只显示输入时点之前的记录。未来窗口不足一周时截到本地数据末尾，缺口不插值。'})
