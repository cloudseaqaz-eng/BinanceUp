#!/bin/bash
set -e
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv
fi
if ! .venv/bin/python -c "import numpy,pandas,pyarrow" 2>/dev/null; then
  .venv/bin/python -m pip install -r requirements.txt
fi
if [ ! -f continuity_results/events.sqlite ]; then
  read -r -p "已有 research_data 的完整路径：" continuity_input
  .venv/bin/python -m continuity_app build --data "$continuity_input" --results ./continuity_results
fi
printf '\n打开 http://127.0.0.1:8768；退出请按 Ctrl+C。\n'
.venv/bin/python -m continuity_app serve --results ./continuity_results
