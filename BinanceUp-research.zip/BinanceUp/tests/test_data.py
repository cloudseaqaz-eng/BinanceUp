from http.server import BaseHTTPRequestHandler, HTTPServer
from io import BytesIO
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
from urllib.parse import quote, urlencode
import zipfile

import pandas as pd

from research.config import Config, board_symbol
from research.data import cached_zip, download, get
from research.storage import assert_exact, read_frame, write_frame


class UnicodeDownloadTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        blob = BytesIO()
        with zipfile.ZipFile(blob, "w") as archive:
            archive.writestr("行情.csv", "time,close\n1,2\n")
        cls.blob = blob.getvalue()
        cls.requests = []

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                cls.requests.append(self.path)
                self.send_response(404 if self.path.startswith("/missing/") else 200)
                self.end_headers()
                self.wfile.write(cls.blob)

            def log_message(self, *_):
                pass

        cls.server = HTTPServer(("127.0.0.1", 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}/"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def test_chinese_spot_oi_funding_urls_and_cached_zip(self):
        with tempfile.TemporaryDirectory() as root:
            cfg = Config(start="2026-04-01", end="2026-10-01", root=root)
            with patch("research.data.ARCHIVE", self.base):
                for symbol in ("币安人生USDT", "牛来USDT"):
                    self.assertTrue(board_symbol(symbol))
                    paths = [
                        f"spot/monthly/klines/{symbol}/1m/{symbol}-1m-2026-09.zip",
                        f"futures/um/daily/metrics/{symbol}/{symbol}-metrics-2026-09-01.zip",
                        f"futures/um/monthly/fundingRate/{symbol}/{symbol}-fundingRate-2026-09.zip",
                    ]
                    for relative in paths:
                        log = []
                        self.assertEqual(cached_zip(cfg, relative, log), self.blob)
                        self.assertEqual(self.requests[-1], "/" + quote(relative, safe="/"))
                        self.assertEqual(log[-1]["status"], "downloaded")
                        self.assertEqual((Path(root)/"archive"/relative).read_bytes(), self.blob)
                        with patch("research.data.get", side_effect=AssertionError("cache must avoid network")):
                            self.assertEqual(cached_zip(cfg, relative, log), self.blob)
                        self.assertEqual(log[-1]["status"], "cached")

    def test_existing_escapes_and_s3_query_are_not_double_encoded(self):
        path = quote("币安人生USDT/币安人生USDT.zip", safe="/")
        query = urlencode({"list-type": "2", "continuation-token": "a+b/c=%E5 中文"})
        self.assertEqual(get(self.base + path + "?" + query), self.blob)
        self.assertEqual(self.requests[-1], "/" + path + "?" + query)

    def test_missing_chinese_archive_retains_404_behavior(self):
        self.assertIsNone(get(self.base + "missing/币安人生USDT.zip"))
        self.assertEqual(self.requests[-1], "/missing/" + quote("币安人生USDT.zip"))

    def test_chinese_converted_files_and_checkpoints_resume_without_network(self):
        with tempfile.TemporaryDirectory() as root:
            cfg = Config(start="2026-04-01", end="2026-10-01", root=root,
                         symbols=["币安人生USDT", "牛来USDT"])
            raw = pd.DataFrame({c: [1., 2., 3.] for c in
                                ("open", "high", "low", "close", "volume", "quote", "trades", "taker_quote")},
                               index=pd.date_range("2026-04-01", periods=3, freq="min", tz="UTC", name="time"))
            empty = pd.DataFrame(index=pd.DatetimeIndex([], tz="UTC", name="time"))
            with patch("research.data.fetch_spot", return_value=raw), \
                    patch("research.data.fetch_oi", return_value=empty), \
                    patch("research.data.fetch_funding", return_value=empty):
                download(cfg, workers=1)
            with patch("research.data.get", side_effect=AssertionError("checkpoint must avoid network")):
                download(cfg, workers=1)
            for symbol in cfg.symbols:
                rp = Path(root)/"raw"/f"{symbol}.parquet"
                fp = Path(root)/"features"/f"{symbol}.parquet"
                write_frame(raw, fp, raw_source=rp)
                assert_exact(raw, read_frame(fp))


if __name__ == "__main__":
    unittest.main()
