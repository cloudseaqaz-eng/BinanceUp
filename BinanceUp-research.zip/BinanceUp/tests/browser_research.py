"""Optional integration check: python tests/browser_research.py research_demo /tmp/research-check.

Requires Playwright + Chromium; deliberately not part of normal runtime dependencies.
Uses an existing, clearly marked synthetic demo and an ephemeral local HTTP port.
"""
import asyncio
import json
from pathlib import Path
import sys
import threading
from http.server import ThreadingHTTPServer

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from research.config import Config
from research.web import handler


async def run(root, output):
    from playwright.async_api import async_playwright
    cfg = Config.load(root)
    if cfg.universe_scope != 'synthetic_demo':
        raise ValueError('浏览器测试仅用于独立模拟演示目录')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    checks, errors, external = [], [], []
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler(cfg))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f'http://127.0.0.1:{server.server_port}'
    def check(name, passed, detail=None):
        checks.append({'check': name, 'passed': bool(passed), 'detail': detail})
        print(('PASS ' if passed else 'FAIL ')+name, flush=True)
    try:
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
            context = await browser.new_context(viewport={'width':1500,'height':1000}, device_scale_factor=2)
            page = await context.new_page()
            page.set_default_timeout(30000)
            page.on('pageerror', lambda e: errors.append(str(e)))
            page.on('request', lambda r: external.append(r.url) if not r.url.startswith(base) else None)
            await page.goto(base)
            await page.wait_for_selector('#rows tr')
            check('synthetic data warning visible', '模拟' in await page.locator('#notice').inner_text())
            check('future results hidden initially', await page.locator('th.future:not(.hidden)').count() == 0)
            check('calculated ranking rows exist', await page.locator('#rows tr').count() > 0)
            check('model is from the past', await page.evaluate('!data.model || new Date(data.model.usable_from)<=new Date(data.at)'))
            await page.locator('#future').check()
            check('future results reveal on demand', await page.locator('th.future:not(.hidden)').count() == 2)
            await page.locator('#eligible').uncheck()
            check('all symbols can be inspected with filter reasons', await page.locator('#rows tr').count() == len(cfg.symbols))
            check('activity quiet duration continuity columns populated', await page.evaluate("data.rows.every(r=>typeof r.activity_label==='string' && Number.isFinite(r.continuity15) && r.oi_status.message) && document.querySelectorAll('#rows td.activity').length===data.rows.length"))
            state=await page.evaluate('String(data.rows[0].activity_state)')
            await page.locator('#activity-filter').select_option(state)
            check('activity state filter', await page.locator('#rows tr').count() == await page.evaluate('data.rows.filter(r=>String(r.activity_state)===document.querySelector("#activity-filter").value).length'))
            await page.locator('#activity-filter').select_option('')
            await page.locator('#search').fill('DEMO01')
            check('symbol search', await page.locator('#rows tr').count() == 1)
            await page.locator('#search').fill('')
            await page.screenshot(path=str(output/'ranking.png'), full_page=True)
            await page.goto(base+'/detail.html?symbol=DEMO02USDT&at=2026-10-19T00:00:00Z')
            await page.wait_for_selector('#chart-zoi')
            check('missing OI explained without invented points', await page.evaluate("data.oi_status.code==='no_archive' && data.candles.every(r=>r.zoi15===null) && document.querySelector('#oi-note').textContent.includes('OI')"))
            await page.goto(base+'/detail.html?symbol=DEMO01USDT&at=2026-10-19T00:00:00Z')
            await page.wait_for_selector('#chart-candles')
            check('left information and right charts', await page.evaluate("document.querySelector('aside').getBoundingClientRect().right<=document.querySelector('main').getBoundingClientRect().left+1"))
            check('bounded Kline height at DPR2', await page.locator('#chart-candles').evaluate('e=>e.getBoundingClientRect().height') == 320)
            check('no default future bars', await page.evaluate('data.candles.every(r=>r.ms<=new Date(data.at).getTime())'))
            check('OI uses coin quantity', await page.evaluate('data.candles.some(r=>r.oi>0 && r.oi_usdt>r.oi)'))
            check('continuity series valid and fixed percent scale', await page.evaluate("data.candles.every(r=>r.continuity15===1) && definitions.find(d=>d.id==='continuity').percent===true"))
            check('OI anomaly and relative strength are separate charts', await page.evaluate("document.querySelector('#chart-zoi') && document.querySelector('#chart-relative') && definitions.find(d=>d.id==='zoi').keys.length===1"))
            await page.locator('#chart-continuity').hover(position={'x':380,'y':80})
            check('continuity tooltip uses percentages', '%' in await page.locator('#tooltip').inner_text())
            for period in ['3','5']:
                async with page.expect_response(lambda r: '/api/detail?' in r.url and 'period='+period in r.url):
                    await page.locator('#period').select_option(period)
                await page.wait_for_function(f'data.period==={period} && !document.querySelector("#reload").disabled')
                check(period+' minute period', await page.evaluate('data.period') == int(period))
            async with page.expect_response(lambda r: '/api/detail?' in r.url and 'before=168' in r.url):
                await page.locator('#before').select_option('168')
            await page.wait_for_function('new Date(data.at)-new Date(data.start)===168*3600000 && !document.querySelector("#reload").disabled')
            check('one week history retained', await page.evaluate('data.candles.length') >= 2016)
            await page.locator('#group').select_option('all')
            check('all metric panels present', await page.locator('.chart-card').count() == 20)
            canvas = page.locator('#chart-candles')
            await canvas.hover(position={'x':380,'y':120})
            check('OHLC tooltip contains Change', 'Change' in await page.locator('#tooltip').inner_text())
            check('crosshair timestamps aligned across OI and Kline', await page.evaluate("document.querySelector('#read-candles').textContent.split(' · ')[0]===document.querySelector('#read-oi').textContent.split(' · ')[0]"))
            check('no external chart CDN or market API requests', not external, external)
            await page.screenshot(path=str(output/'detail.png'), full_page=False)
            async with page.expect_response(lambda r: '/api/detail?' in r.url and 'after=24' in r.url):
                await page.locator('#after').select_option('24')
            await page.wait_for_function('new Date(data.end)>new Date(data.at) && !document.querySelector("#reload").disabled')
            check('future chart and outcome revealed explicitly', await page.locator('#future-result').is_visible())
            await page.set_viewport_size({'width':720,'height':1000})
            await page.wait_for_timeout(150)
            check('mobile stacks information above charts', await page.evaluate("document.querySelector('aside').getBoundingClientRect().bottom<=document.querySelector('main').getBoundingClientRect().top+1"))
            check('canvas height stable after resize', await canvas.evaluate('e=>e.getBoundingClientRect().height') == 320)
            await page.set_viewport_size({'width':1500,'height':1000})
            await page.goto(base+'/report.html')
            await page.wait_for_selector('#report .card')
            check('held-out report rendered', '未参与选权重' in await page.locator('#report').inner_text())
            check('calibration and weights visible', '概率校准检查' in await page.locator('#report').inner_text() and '最终测试所用权重' in await page.locator('#report').inner_text())
            await page.screenshot(path=str(output/'report.png'), full_page=True)
            check('no JavaScript runtime errors', not errors, errors)
            await browser.close()
    finally:
        server.shutdown()
        server.server_close()
        (output/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
    if not all(c['passed'] for c in checks):
        raise SystemExit(1)


if __name__=='__main__':
    asyncio.run(run(sys.argv[1] if len(sys.argv)>1 else 'research_demo', sys.argv[2] if len(sys.argv)>2 else '/tmp/research-browser-check'))
