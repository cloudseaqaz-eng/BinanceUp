"""Optional integration check: python tests/browser_research.py research_demo /tmp/research-check.

Requires Playwright + Chromium; deliberately not part of normal runtime dependencies.
Uses an existing, clearly marked synthetic demo and an ephemeral local HTTP port.
"""
import asyncio
from datetime import datetime, timedelta
import json
import re
from pathlib import Path
import sys
import threading
from http.server import ThreadingHTTPServer

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from research.config import Config
from research.web import handler


async def run(root, output):
    from playwright.async_api import async_playwright
    cfg = Config.load(root)
    if cfg.universe_scope != 'synthetic_demo':
        raise ValueError('浏览器测试仅用于独立模拟演示目录')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    checks, errors, external = [], [], []
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler(cfg))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f'http://127.0.0.1:{server.server_port}'
    def check(name, passed, detail=None):
        checks.append({'check': name, 'passed': bool(passed), 'detail': detail})
        print(('PASS ' if passed else 'FAIL ')+name, flush=True)
    try:
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
            context = await browser.new_context(viewport={'width':1500,'height':1000}, device_scale_factor=2)
            page = await context.new_page()
            page.set_default_timeout(30000)
            page.on('pageerror', lambda e: errors.append(str(e)))
            page.on('request', lambda r: external.append(r.url) if not r.url.startswith(base) else None)
            response=await page.goto(base)
            check('static HTML disables stale caching', 'no-store' in response.headers.get('cache-control',''))
            await page.wait_for_selector('#rows tr')
            check('synthetic data warning visible', '模拟' in await page.locator('#notice').inner_text())
            check('future results hidden initially', await page.locator('th.future:not(.hidden)').count() == 0)
            check('calculated ranking rows exist', await page.locator('#rows tr').count() > 0)
            check('model is from the past', await page.evaluate('!data.model || new Date(data.model.usable_from)<=new Date(data.at)'))
            await page.locator('#future').check()
            check('future results reveal on demand', await page.locator('th.future:not(.hidden)').count() == 2)
            await page.locator('#eligible').uncheck()
            check('all symbols can be inspected with filter reasons', await page.locator('#rows tr').count() == len(cfg.symbols))
            check('activity quiet duration continuity columns populated', await page.evaluate("data.rows.every(r=>typeof r.activity_label==='string' && Number.isFinite(r.continuity15) && r.oi_status.message) && document.querySelectorAll('#rows td.activity').length===data.rows.length"))
            state=await page.evaluate('String(data.rows[0].activity_state)')
            await page.locator('#activity-filter').select_option(state)
            check('activity state filter', await page.locator('#rows tr').count() == await page.evaluate('data.rows.filter(r=>String(r.activity_state)===document.querySelector("#activity-filter").value).length'))
            await page.locator('#activity-filter').select_option('')
            await page.locator('#search').fill('DEMO01')
            check('symbol search', await page.locator('#rows tr').count() == 1)
            await page.locator('#search').fill('')
            await page.screenshot(path=str(output/'ranking.png'), full_page=True)
            await page.goto(base+'/detail.html?symbol=DEMO02USDT&at=2026-10-19T00:00:00Z')
            await page.wait_for_selector('#chart-zoi')
            check('missing OI explained without invented points', await page.evaluate("data.oi_status.code==='no_archive' && data.candles.every(r=>r.zoi15===null) && document.querySelector('#oi-note').textContent.includes('OI')"))
            await page.goto(base+'/detail.html?symbol=DEMO01USDT&at=2026-10-19T00:00:00Z')
            await page.wait_for_selector('#chart-candles')
            check('left information and right charts', await page.evaluate("document.querySelector('aside').getBoundingClientRect().right<=document.querySelector('main').getBoundingClientRect().left+1"))
            check('bounded Kline height at DPR2', await page.locator('#chart-candles').evaluate('e=>e.getBoundingClientRect().height') == 320)
            check('no default future bars', await page.evaluate('data.candles.every(r=>r.ms<=new Date(data.at).getTime())'))
            check('OI uses coin quantity', await page.evaluate('data.candles.some(r=>r.oi>0 && r.oi_usdt>r.oi)'))
            check('continuity series valid and fixed percent scale', await page.evaluate("data.candles.every(r=>r.continuity15===1) && definitions.find(d=>d.id==='continuity').percent===true"))
            check('OI anomaly and relative strength are separate charts', await page.evaluate("document.querySelector('#chart-zoi') && document.querySelector('#chart-relative') && definitions.find(d=>d.id==='zoi').keys.length===1"))
            await page.locator('#chart-continuity').hover(position={'x':380,'y':80})
            check('continuity tooltip uses percentages', '%' in await page.locator('#tooltip').inner_text())
            check('buy continuity uses minute windows with fixed percent scale', await page.evaluate("data.candles.every(r=>r.buy_continuity5===1 && r.buy_continuity15===1 && r.buy_continuity60===1) && definitions.find(d=>d.id==='buy-continuity').percent"))
            await page.locator('#chart-buy-continuity').hover(position={'x':380,'y':80})
            check('buy continuity tooltip and Kline cursor align', '%' in await page.locator('#tooltip').inner_text() and await page.evaluate("document.querySelector('#read-candles').textContent.split(' · ')[0]===document.querySelector('#read-buy-continuity').textContent.split(' · ')[0]"))
            await page.locator('#group').select_option('flow')
            check('buy continuity is available in flow group', await page.locator('#chart-buy-continuity').count()==1)
            await page.locator('#group').select_option('core')
            check('accumulation is bounded and preserves minute sampling', await page.evaluate("data.accum_series.length===48*60+1 && data.accum_series.every((r,i)=>r.activity_accum>=0 && r.activity_accum<=20 && r.ms<=new Date(data.at).getTime() && (!i||r.ms-data.accum_series[i-1].ms===60000)) && !definitions.find(d=>d.id==='accum').percent"))
            await page.locator('#chart-accum').hover(position={'x':380,'y':80})
            check('accumulation tooltip gives score and current minute rule aligned with Kline', '本分钟' in await page.locator('#tooltip').inner_text() and '分' in await page.locator('#tooltip').inner_text() and await page.evaluate("document.querySelector('#read-candles').textContent.split(' · ')[0]===document.querySelector('#read-accum').textContent.split(' · ')[0]"))
            check('accumulation includes a score-unit dashed day baseline', await page.evaluate("definitions.find(d=>d.id==='accum').keys.some(k=>k[0]==='activity_baseline24' && k[2].dash.length>0) && data.accum_series.every(r=>r.activity_baseline24>=0 && r.activity_baseline24<=20)"))
            check('baseline tooltip reports mean and difference in points', '此前24h累计分均值' in await page.locator('#tooltip').inner_text() and '较基线' in await page.locator('#tooltip').inner_text())
            await page.locator('#chart-accum').scroll_into_view_if_needed()
            await page.screenshot(path=str(output/'accumulation.png'),full_page=False)
            check('two distribution scores preserve minute cadence and hide future', await page.evaluate("definitions.find(d=>d.id==='distribution').keys.length===2 && data.dist_series.length===48*60+1 && data.dist_series.every((r,i)=>r.ms<=new Date(data.at).getTime() && (!i||r.ms-data.dist_series[i-1].ms===60000) && r.dist_buy_score30===100 && r.dist_trade_score30===100)"))
            for window in ['15','30']:
                await page.locator('#dist-window').select_option(window)
                check('distribution window '+window, await page.evaluate("definitions.find(d=>d.id==='distribution').keys[0][0]==='dist_buy_score"+window+"' && definitions.find(d=>d.id==='distribution').keys[1][0]==='dist_trade_score"+window+"'"))
            await page.locator('#chart-distribution').hover(position={'x':380,'y':80})
            check('distribution tooltip gives points and low tail diagnostics aligned with Kline', '低位均值' in await page.locator('#tooltip').inner_text() and '分' in await page.locator('#tooltip').inner_text() and await page.evaluate("document.querySelector('#read-candles').textContent.split(' · ')[0]===document.querySelector('#read-distribution').textContent.split(' · ')[0]"))
            await page.locator('#chart-distribution').scroll_into_view_if_needed()
            await page.screenshot(path=str(output/'distribution.png'),full_page=False)
            check('retired activation chart and API are absent', await page.evaluate("!document.querySelector('#chart-activation') && !document.querySelector('#activation-kind') && !('activation_series' in data) && !('activation_current' in data)"))
            check('UW pressure is independent with fixed percent scale', await page.evaluate("definitions.find(d=>d.id==='uw-smooth').percent && definitions.find(d=>d.id==='structure').keys.every(k=>k[0]!=='uw3') && document.querySelector('#chart-uw-smooth')"))
            check('UW preserves minute samples and hides future initially', await page.evaluate("data.uw_series.every((r,i)=>r.ms<=new Date(data.at).getTime() && (!i || r.ms-data.uw_series[i-1].ms===60000))"))
            await page.locator('#group').select_option('uw')
            check('UW focused view contains Kline and two smooth charts', await page.locator('.chart-card').count() == 3)
            check('retired change chart controls and data are absent', await page.evaluate("!document.querySelector('#chart-uw-change') && !document.querySelector('#uw-markers') && data.uw_events.length===0 && data.uw_regions.length===0 && data.uw_series.every(r=>!('uw_change5' in r))"))
            await page.locator('#chart-uw-smooth').hover(position={'x':380,'y':80})
            check('UW pressure tooltip uses percentages', '%' in await page.locator('#tooltip').inner_text())
            check('UW cursor aligns with Kline', await page.evaluate("document.querySelector('#read-candles').textContent.split(' · ')[0]===document.querySelector('#read-uw-smooth').textContent.split(' · ')[0]"))
            check('UW defaults to 60 minutes and raw curves are collapsed', await page.evaluate("document.querySelector('#uw-window').value==='60' && !document.querySelector('#chart-uw-pressure') && definitions.find(d=>d.id==='uw-zero').keys[0][0]==='uw_zero60'"))
            check('smooth tooltip explains coverage and prior day comparison', '覆盖' in await page.locator('#tooltip').inner_text() and '此前24h' in await page.locator('#tooltip').inner_text())
            for window in ['30','120','60']:
                await page.locator('#uw-window').select_option(window)
                check('UW window '+window+' switches both metrics', await page.evaluate("definitions.find(d=>d.id==='uw-zero').keys[0][0]==='uw_zero"+window+"' && definitions.find(d=>d.id==='uw-smooth').keys[0][0]==='uw_pressure"+window+"'"))
            await page.locator('#uw-raw').check()
            check('raw curves expand on demand', await page.locator('.chart-card').count()==4 and await page.locator('#chart-uw-pressure').count()==1)
            await page.locator('#uw-raw').uncheck()
            await page.mouse.move(1,1)
            await page.screenshot(path=str(output/'uw-focused.png'), full_page=True)
            await page.evaluate('window.uwAtBefore=JSON.stringify(data.uw_current)')
            for period in ['3','5']:
                async with page.expect_response(lambda r: '/api/detail?' in r.url and 'period='+period in r.url):
                    await page.locator('#period').select_option(period)
                await page.wait_for_function(f'data.period==={period} && !document.querySelector("#reload").disabled')
                check(period+' minute period', await page.evaluate('data.period') == int(period))
            async with page.expect_response(lambda r: '/api/detail?' in r.url and 'before=168' in r.url):
                await page.locator('#before').select_option('168')
            await page.wait_for_function('new Date(data.at)-new Date(data.start)===168*3600000 && !document.querySelector("#reload").disabled')
            check('one week history retained', await page.evaluate('data.candles.length') >= 2016)
            async with page.expect_response(lambda r: '/api/detail?' in r.url and 'before=336' in r.url):
                await page.locator('#before').select_option('336')
            await page.wait_for_function('new Date(data.at)-new Date(data.start)===336*3600000 && !document.querySelector("#reload").disabled')
            check('two week history loads minute UW and sampled candles', await page.evaluate('data.candles.length>=4032 && data.uw_series.length===336*60+1'))
            await page.locator('#group').select_option('all')
            check('all metric panels present', await page.locator('.chart-card').count() == 25)
            canvas = page.locator('#chart-candles')
            await canvas.hover(position={'x':380,'y':120})
            check('OHLC tooltip contains Change', 'Change' in await page.locator('#tooltip').inner_text())
            check('crosshair timestamps aligned across OI and Kline', await page.evaluate("document.querySelector('#read-candles').textContent.split(' · ')[0]===document.querySelector('#read-oi').textContent.split(' · ')[0]"))
            check('no external chart CDN or market API requests', not external, external)
            await page.screenshot(path=str(output/'detail.png'), full_page=False)
            await page.evaluate('window.uwAtBefore=JSON.stringify(data.uw_current)')
            async with page.expect_response(lambda r: '/api/detail?' in r.url and 'after=24' in r.url):
                await page.locator('#after').select_option('24')
            await page.wait_for_function('new Date(data.end)>new Date(data.at) && !document.querySelector("#reload").disabled')
            check('future chart and outcome revealed explicitly', await page.locator('#future-result').is_visible())
            check('future toggle does not rewrite UW state at scoring time', await page.evaluate('window.uwAtBefore===JSON.stringify(data.uw_current)'))
            for hours in ['72','168']:
                async with page.expect_response(lambda r: '/api/detail?' in r.url and 'after='+hours in r.url):
                    await page.locator('#after').select_option(hours)
                await page.wait_for_function('!document.querySelector("#reload").disabled')
                # Near the dataset end, the UI must clip rather than invent future bars.
                clipped = await page.evaluate('new Date(data.end).getTime()')
                response = await context.request.get(base+'/api/detail?symbol=DEMO01USDT&at=2026-10-10T00:00:00Z&before=6&period=60&after='+hours)
                extended = await response.json()
                check('future '+hours+' hours loads and clips at dataset end', response.status==200 and clipped==int(datetime.fromisoformat(cfg.end).timestamp()*1000) and datetime.fromisoformat(extended['end'])-datetime.fromisoformat(extended['at'])==timedelta(hours=int(hours)))
            await page.set_viewport_size({'width':720,'height':1000})
            await page.wait_for_timeout(150)
            check('mobile stacks information above charts', await page.evaluate("document.querySelector('aside').getBoundingClientRect().bottom<=document.querySelector('main').getBoundingClientRect().top+1"))
            check('canvas height stable after resize', await canvas.evaluate('e=>e.getBoundingClientRect().height') == 320)
            await page.set_viewport_size({'width':1500,'height':1000})
            await page.goto(base+'/report.html')
            await page.wait_for_selector('#report .card')
            check('held-out report rendered', '未参与选权重' in await page.locator('#report').inner_text())
            check('calibration and weights visible', '概率校准检查' in await page.locator('#report').inner_text() and '最终测试所用权重' in await page.locator('#report').inner_text())
            await page.screenshot(path=str(output/'report.png'), full_page=True)
            legacy_html_pattern=re.compile(r'/detail\.html\?.*compat=old-html')
            async def old_html(route):
                response=await route.fetch()
                body=await response.text()
                body=body.replace('<button id="reload">','<label><input id="uw-markers" type="checkbox" checked>UW异常标记</label><label>状态观察<select id="activation-kind"><option>成交</option></select></label><button id="reload">')
                body=body.replace('<option value="uw">UW观察（含K线）</option>','')
                body=re.sub(r'<label>UW平滑窗口.*?</label>|<label><input id="uw-raw".*?</label>','',body)
                body=re.sub(r'<label>连续性评分窗口.*?</label>','',body)
                body=re.sub(r'<p id="(?:oi-note|context-note)"[^>]*></p>','',body)
                await route.fulfill(response=response,body=body)
            await page.route(legacy_html_pattern,old_html)
            await page.goto(base+'/detail.html?symbol=DEMO01USDT&at=2026-10-19T00:00:00Z&compat=old-html&group=uw')
            await page.wait_for_selector('#chart-uw-smooth')
            check('old HTML retired UW toggle is removed without crashing', await page.locator('#uw-markers').count()==0 and await page.locator('#activation-kind').count()==0)
            check('old HTML UW option is restored', await page.locator('#group option[value="uw"]').count()==1 and await page.locator('.chart-card').count()==3)
            check('missing optional legacy notes do not break rendering', await page.locator('#oi-note').count()==0 and await page.locator('#chart-candles').count()==1 and 'Setup评分' in await page.locator('#summary').inner_text())
            check('detail assets are versioned and bypass old JS cache', await page.evaluate("Array.from(document.scripts).filter(s=>/common.js|detail.js/.test(s.src)).every(s=>s.src.includes('?v='))"))
            await page.screenshot(path=str(output/'legacy-controls.png'),full_page=True)
            legacy_api_pattern=re.compile(r'/api/detail\?')
            async def old_api(route):
                response=await route.fetch()
                body=await response.json()
                for key in list(body):
                    if key.startswith('uw_') or key in ('oi_status','context_note'):
                        body.pop(key)
                for row in body['candles']:
                    for key in list(row):
                        if key.startswith('uw_'):row.pop(key)
                await route.fulfill(response=response,json=body)
            await page.route(legacy_api_pattern,old_api)
            await page.goto(base+'/detail.html?symbol=DEMO01USDT&at=2026-10-19T00:00:00Z&group=uw')
            await page.wait_for_selector('#chart-candles')
            check('old backend gives a restart instruction instead of crashing', 'serve' in await page.locator('#notice').inner_text() and await page.locator('#notice').evaluate("e=>e.classList.contains('warn')"))
            check('old backend retains Kline and does not invent UW samples', await page.evaluate("data.candles.length>0 && data.uw_series.length===0 && data.uw_events.length===0 && data.snapshot.score!==null"))
            await page.unroute(legacy_api_pattern,old_api)
            await page.unroute(legacy_html_pattern,old_html)
            check('no JavaScript runtime errors', not errors, errors)
            await browser.close()
    finally:
        server.shutdown()
        server.server_close()
        (output/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
    if not all(c['passed'] for c in checks):
        raise SystemExit(1)


if __name__=='__main__':
    asyncio.run(run(sys.argv[1] if len(sys.argv)>1 else 'research_demo', sys.argv[2] if len(sys.argv)>2 else '/tmp/research-browser-check'))
