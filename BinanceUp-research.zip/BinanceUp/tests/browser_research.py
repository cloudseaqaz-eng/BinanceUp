"""Optional integration check: python tests/browser_research.py research_demo /tmp/research-check.

Requires Playwright + Chromium; deliberately not part of normal runtime dependencies.
Uses an existing, clearly marked synthetic demo and an ephemeral local HTTP port.
"""
import asyncio
import json
from pathlib import Path
import sys
import threading
from http.server import ThreadingHTTPServer

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from research.config import Config
from research.web import handler


async def run(root, output):
    from playwright.async_api import async_playwright
    cfg = Config.load(root)
    if cfg.universe_scope != 'synthetic_demo':
        raise ValueError('浏览器测试仅用于独立模拟演示目录')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    checks, errors, external = [], [], []
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler(cfg))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f'http://127.0.0.1:{server.server_port}'
    def check(name, passed, detail=None):
        checks.append({'check': name, 'passed': bool(passed), 'detail': detail})
        print(('PASS ' if passed else 'FAIL ')+name, flush=True)
    try:
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
            context = await browser.new_context(viewport={'width':1500,'height':1000}, device_scale_factor=2)
            page = await context.new_page()
            page.set_default_timeout(30000)
            page.on('pageerror', lambda e: errors.append(str(e)))
            page.on('request', lambda r: external.append(r.url) if not r.url.startswith(base) else None)
            await page.goto(base)
            await page.wait_for_selector('#rows tr')
            check('synthetic data warning visible', '模拟' in await page.locator('#notice').inner_text())
            check('future results hidden initially', await page.locator('th.future:not(.hidden)').count() == 0)
            check('calculated ranking rows exist', await page.locator('#rows tr').count() > 0)
            check('model is from the past', await page.evaluate('!data.model || new Date(data.model.usable_from)<=new Date(data.at)'))
            await page.locator('#future').check()
            check('future results reveal on demand', await page.locator('th.future:not(.hidden)').count() == 2)
            await page.locator('#eligible').uncheck()
            check('all symbols can be inspected with filter reasons', await page.locator('#rows tr').count() == len(cfg.symbols))
            check('activity quiet duration continuity columns populated', await page.evaluate("data.rows.every(r=>typeof r.activity_label==='string' && Number.isFinite(r.continuity15) && r.oi_status.message) && document.querySelectorAll('#rows td.activity').length===data.rows.length"))
            state=await page.evaluate('String(data.rows[0].activity_state)')
            await page.locator('#activity-filter').select_option(state)
            check('activity state filter', await page.locator('#rows tr').count() == await page.evaluate('data.rows.filter(r=>String(r.activity_state)===document.querySelector("#activity-filter").value).length'))
            await page.locator('#activity-filter').select_option('')
            await page.locator('#search').fill('DEMO01')
            check('symbol search', await page.locator('#rows tr').count() == 1)
            await page.locator('#search').fill('')
            await page.screenshot(path=str(output/'ranking.png'), full_page=True)
            await page.goto(base+'/detail.html?symbol=DEMO02USDT&at=2026-10-19T00:00:00Z')
            await page.wait_for_selector('#chart-zoi')
            check('missing OI explained without invented points', await page.evaluate("data.oi_status.code==='no_archive' && data.candles.every(r=>r.zoi15===null) && document.querySelector('#oi-note').textContent.includes('OI')"))
            await page.goto(base+'/detail.html?symbol=DEMO01USDT&at=2026-10-19T00:00:00Z')
            await page.wait_for_selector('#chart-candles')
            check('left information and right charts', await page.evaluate("document.querySelector('aside').getBoundingClientRect().right<=document.querySelector('main').getBoundingClientRect().left+1"))
            check('bounded Kline height at DPR2', await page.locator('#chart-candles').evaluate('e=>e.getBoundingClientRect().height') == 320)
            check('no default future bars', await page.evaluate('data.candles.every(r=>r.ms<=new Date(data.at).getTime())'))
            check('OI uses coin quantity', await page.evaluate('data.candles.some(r=>r.oi>0 && r.oi_usdt>r.oi)'))
            check('continuity series valid and fixed percent scale', await page.evaluate("data.candles.every(r=>r.continuity15===1) && definitions.find(d=>d.id==='continuity').percent===true"))
            check('OI anomaly and relative strength are separate charts', await page.evaluate("document.querySelector('#chart-zoi') && document.querySelector('#chart-relative') && definitions.find(d=>d.id==='zoi').keys.length===1"))
            await page.locator('#chart-continuity').hover(position={'x':380,'y':80})
            check('continuity tooltip uses percentages', '%' in await page.locator('#tooltip').inner_text())
            check('UW pressure is independent with fixed percent scale', await page.evaluate("definitions.find(d=>d.id==='uw-pressure').percent && definitions.find(d=>d.id==='structure').keys.every(k=>k[0]!=='uw3') && document.querySelector('#chart-uw-pressure')"))
            check('UW preserves minute samples and hides future initially', await page.evaluate("data.uw_series.every((r,i)=>r.ms<=new Date(data.at).getTime() && (!i || r.ms-data.uw_series[i-1].ms===60000))"))
            await page.locator('#group').select_option('uw')
            check('UW focused view contains Kline and two UW panels', await page.locator('.chart-card').count() == 3)
            check('UW lines include raw bars baseline and P90', await page.evaluate("definitions.find(d=>d.id==='uw-change').keys.some(k=>k[2]?.type==='bars') && definitions.find(d=>d.id==='uw-change').keys.some(k=>k[0]==='uw_p90' && k[2].dash.length)"))
            check('UW exact minute confirmation markers exist', await page.evaluate("data.uw_events.length>0 && data.uw_events.every(e=>e.ms>e.started_ms && e.ms<=new Date(data.at).getTime())"))
            await page.mouse.move(1,1)
            marked=await page.locator('#chart-uw-change').evaluate('e=>e.toDataURL()')
            await page.locator('#uw-markers').uncheck()
            unmarked=await page.locator('#chart-uw-change').evaluate('e=>e.toDataURL()')
            check('UW markers and shading toggle visually', marked != unmarked)
            await page.locator('#uw-markers').check()
            await page.locator('#chart-uw-change').hover(position={'x':380,'y':80})
            check('UW tooltip explains units and event state', '个百分点' in await page.locator('#tooltip').inner_text() and bool(await page.locator('#uw-status').inner_text()))
            check('UW cursor aligns with Kline', await page.evaluate("document.querySelector('#read-candles').textContent.split(' · ')[0]===document.querySelector('#read-uw-change').textContent.split(' · ')[0]"))
            await page.mouse.move(1,1)
            await page.screenshot(path=str(output/'uw-focused.png'), full_page=True)
            await page.evaluate('window.uwAtBefore=JSON.stringify(data.uw_current)')
            for period in ['3','5']:
                async with page.expect_response(lambda r: '/api/detail?' in r.url and 'period='+period in r.url):
                    await page.locator('#period').select_option(period)
                await page.wait_for_function(f'data.period==={period} && !document.querySelector("#reload").disabled')
                check(period+' minute period', await page.evaluate('data.period') == int(period))
            async with page.expect_response(lambda r: '/api/detail?' in r.url and 'before=168' in r.url):
                await page.locator('#before').select_option('168')
            await page.wait_for_function('new Date(data.at)-new Date(data.start)===168*3600000 && !document.querySelector("#reload").disabled')
            check('one week history retained', await page.evaluate('data.candles.length') >= 2016)
            await page.locator('#group').select_option('all')
            check('all metric panels present', await page.locator('.chart-card').count() == 22)
            canvas = page.locator('#chart-candles')
            await canvas.hover(position={'x':380,'y':120})
            check('OHLC tooltip contains Change', 'Change' in await page.locator('#tooltip').inner_text())
            check('crosshair timestamps aligned across OI and Kline', await page.evaluate("document.querySelector('#read-candles').textContent.split(' · ')[0]===document.querySelector('#read-oi').textContent.split(' · ')[0]"))
            check('no external chart CDN or market API requests', not external, external)
            await page.screenshot(path=str(output/'detail.png'), full_page=False)
            await page.evaluate('window.uwAtBefore=JSON.stringify(data.uw_current)')
            async with page.expect_response(lambda r: '/api/detail?' in r.url and 'after=24' in r.url):
                await page.locator('#after').select_option('24')
            await page.wait_for_function('new Date(data.end)>new Date(data.at) && !document.querySelector("#reload").disabled')
            check('future chart and outcome revealed explicitly', await page.locator('#future-result').is_visible())
            check('future toggle does not rewrite UW state at scoring time', await page.evaluate('window.uwAtBefore===JSON.stringify(data.uw_current)'))
            await page.set_viewport_size({'width':720,'height':1000})
            await page.wait_for_timeout(150)
            check('mobile stacks information above charts', await page.evaluate("document.querySelector('aside').getBoundingClientRect().bottom<=document.querySelector('main').getBoundingClientRect().top+1"))
            check('canvas height stable after resize', await canvas.evaluate('e=>e.getBoundingClientRect().height') == 320)
            await page.set_viewport_size({'width':1500,'height':1000})
            await page.goto(base+'/report.html')
            await page.wait_for_selector('#report .card')
            check('held-out report rendered', '未参与选权重' in await page.locator('#report').inner_text())
            check('calibration and weights visible', '概率校准检查' in await page.locator('#report').inner_text() and '最终测试所用权重' in await page.locator('#report').inner_text())
            await page.screenshot(path=str(output/'report.png'), full_page=True)
            check('no JavaScript runtime errors', not errors, errors)
            await browser.close()
    finally:
        server.shutdown()
        server.server_close()
        (output/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
    if not all(c['passed'] for c in checks):
        raise SystemExit(1)


if __name__=='__main__':
    asyncio.run(run(sys.argv[1] if len(sys.argv)>1 else 'research_demo', sys.argv[2] if len(sys.argv)>2 else '/tmp/research-browser-check'))
