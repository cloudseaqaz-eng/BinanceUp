from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd

from research.config import Config
from research.storage import write_frame
from research.uw import metrics, events, regions
from research.web import detail


def candles(minutes=1440, start="2026-01-01T00:01Z", flat=False):
    ix = pd.date_range(start, periods=minutes, freq="min", name="time")
    return pd.DataFrame({"open":100., "high":100., "low":100. if flat else 99.,
                         "close":100., "volume":1., "quote":100., "trades":1., "taker_quote":50.}, index=ix)


def activate(raw, offset):
    raw = raw.copy()
    raw.iloc[offset::2, raw.columns.get_loc("high")] = 101.
    return raw


class UpperWickTests(unittest.TestCase):
    def test_weighted_pressure_limits_tiny_candle_influence(self):
        raw = candles(15, flat=True)
        raw.iloc[-2, raw.columns.get_loc("high")] = 100.1
        raw.loc[raw.index[-1], ["high", "close"]] = 110.
        result = metrics(raw)
        self.assertAlmostEqual(result.uw_pressure15.iloc[-1], .1/10.1)
        self.assertAlmostEqual(result.uw_raw3.iloc[-1], 1/3)

    def test_flat_market_has_no_pressure_or_false_anomaly(self):
        result = metrics(candles(flat=True))
        self.assertTrue(result.uw_pressure15.isna().all())
        self.assertEqual(result.uw_raw3.iloc[-1], 0)
        self.assertEqual(result.uw_change5.iloc[-1], 0)
        self.assertEqual(result.uw_baseline.iloc[-1], 0)
        self.assertFalse(result.uw_event.any())
        self.assertFalse(np.isinf(result.select_dtypes(include=["number"])).any().any())

    def test_missing_and_invalid_candles_remain_unknown(self):
        raw = activate(candles(), 600)
        missing = raw.index[800]
        raw = raw.drop(missing)
        raw.loc[raw.index[900], "high"] = 98.  # high below open/close
        result = metrics(raw)
        self.assertTrue(result.loc[missing:missing+pd.Timedelta(minutes=2), "uw_raw3"].isna().all())
        self.assertTrue(result.loc[missing:missing+pd.Timedelta(minutes=14), "uw_pressure15"].isna().all())
        self.assertTrue(pd.isna(result.loc[raw.index[900], "uw_change5"]))
        self.assertFalse(result.loc[missing, "uw_confirmed"])

    def test_future_changes_do_not_rewrite_baseline_flags_or_event_times(self):
        raw = activate(candles(), 721)
        cut = raw.index[1000]
        original = metrics(raw)
        changed = raw.copy()
        changed.loc[changed.index > cut, "high"] = 200.
        changed.loc[changed.index > cut, "low"] = 50.
        modified = metrics(changed)
        pd.testing.assert_frame_equal(original.loc[:cut], modified.loc[:cut])
        self.assertEqual(events(original, raw.index[0], cut),events(modified, raw.index[0], cut))

    def test_recent_30_minutes_are_excluded_from_baseline(self):
        raw = candles()
        changed = activate(raw, len(raw)-20)
        a, b = metrics(raw), metrics(changed)
        for col in ["uw_baseline", "uw_p90", "uw_threshold"]:
            self.assertEqual(a[col].iloc[-1], b[col].iloc[-1])
        self.assertGreater(b.uw_change5.iloc[-1], a.uw_change5.iloc[-1])

    def test_confirmation_occurs_after_three_minutes_without_backdating(self):
        raw = activate(candles(), 721)
        start = raw.index[721]
        result = metrics(raw)
        first = events(result, raw.index[0], raw.index[-1])[0]
        self.assertEqual(first["started_ms"], start.value//10**6)
        self.assertEqual(first["ms"], (start+pd.Timedelta(minutes=2)).value//10**6)
        self.assertFalse(result.loc[start, "uw_confirmed"])
        self.assertFalse(result.loc[start+pd.Timedelta(minutes=1), "uw_confirmed"])
        region = regions(result, start, raw.index[-1])[0]
        self.assertEqual(region["start_ms"], first["ms"])
        prefix = metrics(raw.loc[:start+pd.Timedelta(minutes=1)])
        self.assertEqual(events(prefix, prefix.index[0], prefix.index[-1]), [])

    def test_unknown_start_is_lower_bound_and_not_fake_first_event(self):
        raw = activate(candles(), 365)
        result = metrics(raw)
        first_valid = result.uw_threshold.first_valid_index()
        current = result.loc[first_valid+pd.Timedelta(minutes=5)]
        self.assertTrue(current.uw_run_censored)
        self.assertTrue(current.uw_confirmed)
        self.assertTrue(pd.isna(current.uw_started_ms))
        self.assertFalse(result.loc[:first_valid+pd.Timedelta(minutes=5), "uw_event"].any())

    def test_baseline_requires_sufficient_observations(self):
        raw = candles()
        raw.loc[raw.index[900:950], ["open","high","low","close"]] = np.nan
        result = metrics(raw)
        self.assertLess(result.uw_baseline_coverage.iloc[1100], .95)
        self.assertTrue(pd.isna(result.uw_threshold.iloc[1100]))
        self.assertTrue(pd.isna(result.uw_above.iloc[1100]))


class UpperWickDetailTests(unittest.TestCase):
    def test_display_period_future_toggle_and_old_scores_are_preserved(self):
        with tempfile.TemporaryDirectory() as root:
            cfg = Config(start="2026-01-02", end="2026-01-04", root=root, symbols=["TESTUSDT"])
            raw = activate(candles(minutes=3*1440), 2161)
            raw_path = Path(root)/"raw/TESTUSDT.parquet"
            feature_path = Path(root)/"features/TESTUSDT.parquet"
            write_frame(raw, raw_path)
            write_frame(pd.DataFrame({"uw3":.2}, index=raw.index), feature_path)
            write_frame(pd.DataFrame(index=raw.index), Path(root)/"market.parquet")
            write_frame(pd.DataFrame(index=raw.index), Path(root)/"labels/TESTUSDT.parquet")
            original_feature_bytes = feature_path.read_bytes()
            original_raw_bytes = raw_path.read_bytes()
            row = {"symbol":"TESTUSDT", "score":73., "probability":.2}
            summary = {"rows":[row], "weights":[.125]*8, "model":{"id":"existing"}, "model_message":None}
            at = pd.Timestamp("2026-01-02T12:20Z")
            with patch("research.web.snapshot", return_value=summary):
                a = detail(cfg, "TESTUSDT", at, before=6, period=5)
                b = detail(cfg, "TESTUSDT", at, before=6, period=3)
                c = detail(cfg, "TESTUSDT", at, before=6, after=24, period=1)
            self.assertEqual(a["uw_series"], b["uw_series"])
            self.assertEqual(a["uw_events"], b["uw_events"])
            self.assertEqual(a["uw_current"], c["uw_current"])
            self.assertTrue(all(r["ms"] <= at.value//10**6 for r in a["uw_series"]))
            self.assertTrue(all(r["ms"] <= at.value//10**6 for r in a["uw_events"]))
            self.assertTrue(any(r["ms"] > at.value//10**6 for r in c["uw_series"]))
            self.assertTrue(any(e["ms"] % 300000 != 0 for e in a["uw_events"]))
            self.assertEqual(a["snapshot"], row)
            self.assertEqual(a["model"], {"id":"existing"})
            self.assertTrue(all(r["uw3"] == .2 for r in a["candles"]))
            self.assertEqual(feature_path.read_bytes(), original_feature_bytes)
            self.assertEqual(raw_path.read_bytes(), original_raw_bytes)


if __name__ == "__main__":
    unittest.main()
