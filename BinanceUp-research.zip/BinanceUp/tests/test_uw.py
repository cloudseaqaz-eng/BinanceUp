from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd

from research.config import Config
from research.storage import write_frame
from research.uw import metrics
from research.web import detail


def candles(minutes=1440, start="2026-01-01T00:01Z", flat=False):
    ix = pd.date_range(start, periods=minutes, freq="min", name="time")
    return pd.DataFrame({"open":100., "high":100., "low":100. if flat else 99.,
                         "close":100., "volume":1., "quote":100., "trades":1., "taker_quote":50.}, index=ix)


def activate(raw, offset):
    raw = raw.copy()
    raw.iloc[offset::2, raw.columns.get_loc("high")] = 101.
    return raw


class UpperWickTests(unittest.TestCase):
    def test_weighted_pressure_limits_tiny_candle_influence(self):
        raw = candles(15, flat=True)
        raw.iloc[-2, raw.columns.get_loc("high")] = 100.1
        raw.loc[raw.index[-1], ["high", "close"]] = 110.
        result = metrics(raw)
        self.assertAlmostEqual(result.uw_pressure15.iloc[-1], .1/10.1)
        self.assertAlmostEqual(result.uw_raw3.iloc[-1], 1/3)

    def test_flat_market_pressure_is_unknown_and_raw_wick_is_zero(self):
        result = metrics(candles(flat=True))
        self.assertTrue(result.uw_pressure15.isna().all())
        self.assertEqual(result.uw_raw3.iloc[-1], 0)
        self.assertFalse(np.isinf(result.select_dtypes(include=["number"])).any().any())

    def test_missing_and_invalid_candles_remain_unknown(self):
        raw = activate(candles(), 600)
        missing = raw.index[800]
        raw = raw.drop(missing)
        raw.loc[raw.index[900], "high"] = 98.  # high below open/close
        result = metrics(raw)
        self.assertTrue(result.loc[missing:missing+pd.Timedelta(minutes=2), "uw_raw3"].isna().all())
        self.assertTrue(result.loc[missing:missing+pd.Timedelta(minutes=14), "uw_pressure15"].isna().all())
        self.assertTrue(pd.isna(result.loc[raw.index[900], "uw_raw3"]))

    def test_future_changes_do_not_rewrite_pressure(self):
        raw = activate(candles(), 721)
        cut = raw.index[1000]
        original = metrics(raw)
        changed = raw.copy()
        changed.loc[changed.index > cut, "high"] = 200.
        changed.loc[changed.index > cut, "low"] = 50.
        modified = metrics(changed)
        pd.testing.assert_frame_equal(original.loc[:cut], modified.loc[:cut])

    def test_one_upper_wick_keeps_pressure_nonzero_for_fifteen_minutes(self):
        raw=candles(60)
        raw.loc[raw.index[20],'high']=101.
        result=metrics(raw)
        self.assertEqual(result.index[result.uw_raw3.gt(0)].tolist(),raw.index[20:23].tolist())
        self.assertEqual(result.index[result.uw_pressure15.gt(0)].tolist(),raw.index[20:35].tolist())
        self.assertEqual(result.uw_pressure15.iloc[35],0)

    def test_zero_rate_counts_overlapping_three_minute_windows(self):
        raw = candles(200)
        raw.loc[raw.index[100], "high"] = 101.
        result = metrics(raw)
        self.assertAlmostEqual(result.uw_zero60.iloc[159], 57/60)
        self.assertAlmostEqual(result.uw_pressure60.iloc[159], 1/61)
        self.assertEqual(result.uw_zero60.iloc[162], 1.)
        self.assertEqual(result.uw_pressure60.iloc[160], 0.)
        self.assertTrue(result.uw_zero120.iloc[:121].isna().all())

    def test_smoothing_gaps_are_not_zero_or_last_n_valid_records(self):
        raw = candles(300)
        missing = raw.index[150]
        result = metrics(raw.drop(missing))
        self.assertTrue(result.uw_zero60.iloc[150:212].isna().all())
        self.assertTrue(result.uw_pressure60.iloc[150:210].isna().all())
        self.assertLess(result.uw_coverage60.iloc[180], 1.)
        self.assertEqual(result.uw_zero60.iloc[212], 1.)
        self.assertEqual(result.uw_pressure60.iloc[210], 0.)

    def test_baseline_uses_disjoint_previous_day_and_full_history(self):
        raw = candles(2000)
        raw.loc[raw.index[-60:], "high"] = 101.
        result = metrics(raw)
        self.assertEqual(result.uw_zero60.iloc[-1], 0.)
        self.assertEqual(result.uw_zero_delta60.iloc[-1], -1.)
        self.assertEqual(result.uw_pressure60.iloc[-1], .5)
        self.assertEqual(result.uw_pressure_delta60.iloc[-1], .5)
        self.assertTrue(result.uw_zero_delta60.iloc[:1501].isna().all())

    def test_zero_pressure_can_coexist_with_continuous_directional_trading(self):
        raw=candles(60)
        raw['open']=100+np.arange(len(raw))*.1
        raw['close']=raw.open+.1
        raw['high']=raw.close
        raw['low']=raw.open
        result=metrics(raw)
        self.assertTrue(raw.trades.gt(0).all())
        self.assertTrue(result.uw_raw3.dropna().eq(0).all())
        self.assertTrue(result.uw_pressure15.dropna().eq(0).all())


class UpperWickDetailTests(unittest.TestCase):
    def test_display_period_future_toggle_and_old_scores_are_preserved(self):
        with tempfile.TemporaryDirectory() as root:
            cfg = Config(start="2026-01-02", end="2026-01-04", root=root, symbols=["TESTUSDT"])
            raw = activate(candles(minutes=3*1440), 2161)
            raw_path = Path(root)/"raw/TESTUSDT.parquet"
            feature_path = Path(root)/"features/TESTUSDT.parquet"
            write_frame(raw, raw_path)
            write_frame(pd.DataFrame({"uw3":.2}, index=raw.index), feature_path)
            write_frame(pd.DataFrame(index=raw.index), Path(root)/"market.parquet")
            write_frame(pd.DataFrame(index=raw.index), Path(root)/"labels/TESTUSDT.parquet")
            original_feature_bytes = feature_path.read_bytes()
            original_raw_bytes = raw_path.read_bytes()
            row = {"symbol":"TESTUSDT", "score":73., "probability":.2}
            summary = {"rows":[row], "weights":[.125]*8, "model":{"id":"existing"}, "model_message":None}
            at = pd.Timestamp("2026-01-02T12:20Z")
            with patch("research.web.snapshot", return_value=summary):
                a = detail(cfg, "TESTUSDT", at, before=6, period=5)
                b = detail(cfg, "TESTUSDT", at, before=6, period=3)
                c = detail(cfg, "TESTUSDT", at, before=6, after=24, period=1)
            self.assertEqual(a["uw_series"], b["uw_series"])
            self.assertEqual(a["activation_series"], b["activation_series"])
            self.assertEqual(a["activation_current"], c["activation_current"])
            self.assertTrue(all(r["buy_continuity15"] == 1 for r in a["candles"]))
            self.assertTrue(all(r["buy_continuity60"] == 1 for r in b["candles"]))
            self.assertEqual(a["uw_events"], b["uw_events"])
            self.assertEqual(a["uw_current"], c["uw_current"])
            self.assertTrue(all(r["ms"] <= at.value//10**6 for r in a["uw_series"]))
            self.assertTrue(all(r["ms"] <= at.value//10**6 for r in a["uw_events"]))
            self.assertTrue(any(r["ms"] > at.value//10**6 for r in c["uw_series"]))
            self.assertEqual(a["uw_events"], [])
            self.assertEqual(a["uw_regions"], [])
            self.assertTrue({"uw_raw3", "uw_pressure15", "uw_zero60", "uw_pressure60", "uw_zero_delta60"} <= set(a["uw_current"]))
            self.assertEqual(a["snapshot"], row)
            self.assertEqual(a["model"], {"id":"existing"})
            self.assertTrue(all(r["uw3"] == .2 for r in a["candles"]))
            self.assertEqual(feature_path.read_bytes(), original_feature_bytes)
            self.assertEqual(raw_path.read_bytes(), original_raw_bytes)


if __name__ == "__main__":
    unittest.main()
