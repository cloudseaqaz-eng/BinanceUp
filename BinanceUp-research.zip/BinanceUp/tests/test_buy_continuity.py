"""Causal, minute-based taker-buy continuity, including missing observations."""
import unittest
import numpy as np
import pandas as pd
from research.activity import buy_continuity


class BuyContinuityTests(unittest.TestCase):
    def raw(self, amounts):
        return pd.DataFrame({"taker_quote": amounts},
            index=pd.date_range("2026-01-01T00:01Z", periods=len(amounts), freq="min", name="time"))

    def test_minutes_count_equally_regardless_of_amount(self):
        raw = self.raw([0, 0.001, 0, 100000, 0]*12)
        result = buy_continuity(raw)
        for window in (5, 15, 60):
            self.assertAlmostEqual(result[f"buy_continuity{window}"].iloc[-1], .4)
            self.assertTrue(result[f"buy_continuity{window}"].iloc[:window-1].isna().all())
        self.assertEqual(buy_continuity(self.raw([0]*60)).buy_continuity60.iloc[-1], 0)
        self.assertEqual(buy_continuity(self.raw([1]*60)).buy_continuity60.iloc[-1], 1)

    def test_missing_invalid_and_omitted_minutes_are_unknown(self):
        raw = self.raw([1.]*180)
        raw.iloc[60, 0] = np.nan
        raw.iloc[90, 0] = -1
        raw.iloc[100, 0] = np.inf
        missing = raw.index[120]
        result = buy_continuity(raw.drop(missing))
        for i in (60, 90, 100, 120):
            self.assertTrue(result.buy_continuity5.iloc[i:i+5].isna().all())
        self.assertTrue(result.buy_continuity60.iloc[120:].isna().all())
        self.assertEqual(result.buy_continuity5.iloc[125], 1)
        self.assertEqual(result.index[120], missing)

    def test_future_changes_do_not_rewrite_history(self):
        raw = self.raw([0., 1.]*120)
        original = buy_continuity(raw)
        raw.iloc[120:, 0] = 100
        pd.testing.assert_frame_equal(original.iloc[:120], buy_continuity(raw).iloc[:120])
