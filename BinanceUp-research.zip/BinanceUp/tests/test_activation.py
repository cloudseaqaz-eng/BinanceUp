import unittest
import numpy as np
import pandas as pd
from research.activation import metrics


def raw(n=2000):
    return pd.DataFrame({"open":100., "high":100., "low":99., "close":100.,
        "trades":0., "taker_quote":0.},
        index=pd.date_range("2026-01-01T00:01Z", periods=n, freq="min", name="time"))


class ActivationTests(unittest.TestCase):
    def test_step_response_and_delayed_baseline(self):
        data=raw()
        data.iloc[1600:, data.columns.get_loc("trades")]=1
        result=metrics(data)
        self.assertAlmostEqual(result.activation_trade_fast.iloc[1604], .5)
        self.assertAlmostEqual(result.activation_trade_slow.iloc[1629], .5)
        self.assertEqual(result.activation_trade_base.iloc[1629], 0)
        self.assertAlmostEqual(result.activation_trade_base.iloc[1630], 1/1440)
        candidate=result.index[result.activation_trade_state.eq(1)][0]
        confirmed=result.index[result.activation_trade_state.eq(2)][0]
        self.assertLess(candidate, confirmed)
        self.assertTrue(result.activation_trade_state.iloc[1700]==2)

    def test_future_changes_preserve_all_past_outputs(self):
        data=raw()
        before=metrics(data)
        data.iloc[1700:, data.columns.get_loc("trades")]=100
        data.iloc[1700:, data.columns.get_loc("high")]=200
        pd.testing.assert_frame_equal(before.iloc[:1700], metrics(data).iloc[:1700])

    def test_missing_invalid_events_restart_warmup(self):
        data=raw()
        data.trades=1.
        data.iloc[1600, data.columns.get_loc("trades")]=np.nan
        result=metrics(data)
        self.assertTrue(result.activation_trade_fast.iloc[1600:1780].isna().all())
        self.assertEqual(result.activation_trade_fast.iloc[1780],1)
        self.assertTrue(result.activation_trade_base.iloc[1630:].isna().all())
        data.iloc[1500, data.columns.get_loc("taker_quote")]=-1
        data.iloc[1550, data.columns.get_loc("high")]=98
        result=metrics(data.drop(data.index[1650]))
        self.assertTrue(np.isnan(result.activation_buy_fast.iloc[1500]))
        self.assertTrue(np.isnan(result.activation_wick_fast.iloc[1550]))
        self.assertTrue(result.iloc[1650].filter(like="_fast").isna().all())

    def test_wick_presence_is_distinct_from_amount_and_zero_ratio(self):
        data=raw()
        data.trades=1.
        data.taker_quote=0.001
        data.high=101.
        result=metrics(data)
        self.assertEqual(result.activation_wick_fast.iloc[-1],1)
        self.assertEqual(result.activation_buy_fast.iloc[-1],1)
        data.high=data.open
        self.assertEqual(metrics(data).activation_wick_fast.iloc[-1],0)

    def test_transient_pulse_does_not_confirm_and_decay_exits(self):
        data=raw(3000)
        data.loc[data.index[1600], "trades"]=1
        result=metrics(data)
        self.assertFalse(result.activation_trade_state.eq(2).any())
        data.iloc[1700:1800, data.columns.get_loc("trades")]=1
        result=metrics(data)
        self.assertTrue(result.activation_trade_state.iloc[1750]==2)
        self.assertEqual(result.activation_trade_state.iloc[-1],0)
