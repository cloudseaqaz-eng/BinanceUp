import unittest
import numpy as np
import pandas as pd
from research.activity_accum import accumulation


def raw(trades):
    return pd.DataFrame({"trades": trades}, index=pd.date_range(
        "2026-01-01T00:01Z", periods=len(trades), freq="min", name="time"))


class AccumulationTests(unittest.TestCase):
    def test_growth_hold_decay_and_caps(self):
        result=accumulation(raw([1]*40+[1,0]*50+[0]*40))
        self.assertTrue(result.activity_accum.iloc[:4].isna().all())
        self.assertEqual(result.activity_accum.iloc[4],1)
        self.assertEqual(result.activity_accum.iloc[23],20)
        self.assertTrue(result.activity_accum.iloc[45:140].eq(20).all())
        self.assertEqual(result.activity_accum.iloc[-1],0)
        self.assertTrue(result.activity_accum.dropna().between(0,20).all())

    def test_each_of_six_minute_counts_maps_to_correct_step(self):
        for count,step in [(0,-1),(1,-1),(2,0),(3,0),(4,1),(5,1)]:
            result=accumulation(raw([1]*count+[0]*(5-count)))
            self.assertEqual(result.activity_points5.iloc[-1],count)
            self.assertEqual(result.activity_step.iloc[-1],step)

    def test_gaps_invalid_values_reset_without_fake_zero_minutes(self):
        for bad in [np.nan,-1,np.inf]:
            data=raw([1.]*80)
            data.iloc[40,0]=bad
            result=accumulation(data)
            self.assertTrue(result.activity_accum.iloc[40:45].isna().all())
            self.assertEqual(result.activity_accum.iloc[45],1)
        data=raw([1.]*80)
        result=accumulation(data.drop(data.index[40]))
        self.assertTrue(result.activity_accum.iloc[40:45].isna().all())
        self.assertEqual(result.activity_accum.iloc[45],1)

    def test_future_cannot_change_past(self):
        data=raw([1]*40+[1,0]*50+[0]*40)
        original=accumulation(data)
        data.iloc[120:,0]=1000
        pd.testing.assert_frame_equal(original.iloc[:120],accumulation(data).iloc[:120])
