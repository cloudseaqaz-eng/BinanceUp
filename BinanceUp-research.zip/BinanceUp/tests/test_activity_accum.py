import unittest
import numpy as np
import pandas as pd
from research.activity_accum import accumulation


def raw(trades):
    return pd.DataFrame({"trades": trades}, index=pd.date_range(
        "2026-01-01T00:01Z", periods=len(trades), freq="min", name="time"))


class AccumulationTests(unittest.TestCase):
    def test_growth_hold_decay_and_caps(self):
        result=accumulation(raw([1]*40+[1,0]*50+[0]*40))
        self.assertTrue(result.activity_accum.iloc[:4].isna().all())
        self.assertEqual(result.activity_accum.iloc[4],1)
        self.assertEqual(result.activity_accum.iloc[23],20)
        self.assertTrue(result.activity_accum.iloc[45:140].eq(20).all())
        self.assertEqual(result.activity_accum.iloc[-1],0)
        self.assertTrue(result.activity_accum.dropna().between(0,20).all())

    def test_each_of_six_minute_counts_maps_to_correct_step(self):
        for count,step in [(0,-1),(1,-1),(2,0),(3,0),(4,1),(5,1)]:
            result=accumulation(raw([1]*count+[0]*(5-count)))
            self.assertEqual(result.activity_points5.iloc[-1],count)
            self.assertEqual(result.activity_step.iloc[-1],step)

    def test_gaps_invalid_values_reset_without_fake_zero_minutes(self):
        for bad in [np.nan,-1,np.inf]:
            data=raw([1.]*80)
            data.iloc[40,0]=bad
            result=accumulation(data)
            self.assertTrue(result.activity_accum.iloc[40:45].isna().all())
            self.assertEqual(result.activity_accum.iloc[45],1)
        data=raw([1.]*80)
        result=accumulation(data.drop(data.index[40]))
        self.assertTrue(result.activity_accum.iloc[40:45].isna().all())
        self.assertEqual(result.activity_accum.iloc[45],1)

    def test_future_cannot_change_past(self):
        data=raw([1]*40+[1,0]*50+[0]*40)
        original=accumulation(data)
        data.iloc[120:,0]=1000
        pd.testing.assert_frame_equal(original.iloc[:120],accumulation(data).iloc[:120])


    def test_baseline_is_score_mean_with_thirty_minute_exclusion(self):
        data=raw([0]*1800+[1]*80)
        result=accumulation(data)
        self.assertTrue(result.activity_baseline24.iloc[:1473].isna().all())
        self.assertEqual(result.activity_baseline24.iloc[1832],0)
        self.assertAlmostEqual(result.activity_baseline24.iloc[1833],1/1440)
        at=1870
        self.assertAlmostEqual(result.activity_baseline24.iloc[at],
            result.activity_accum.iloc[at-30-1439:at-30+1].mean())
        self.assertAlmostEqual(result.activity_excess24.iloc[at],
            result.activity_accum.iloc[at]-result.activity_baseline24.iloc[at])
        data.iloc[at-29:,0]=0
        changed=accumulation(data)
        self.assertEqual(changed.activity_baseline24.iloc[at],result.activity_baseline24.iloc[at])

    def test_baseline_gaps_are_unknown_and_mean_is_not_event_frequency(self):
        data=raw([1]*40+[1,0]*1800)
        result=accumulation(data)
        self.assertEqual(result.activity_baseline24.iloc[-1],20)
        self.assertAlmostEqual(data.trades.iloc[-1440:].mean(),.5)
        data.iloc[2000,0]=np.nan
        result=accumulation(data)
        self.assertTrue(np.isnan(result.activity_baseline24.iloc[2030]))
        self.assertTrue(np.isnan(result.activity_excess24.iloc[2030]))
