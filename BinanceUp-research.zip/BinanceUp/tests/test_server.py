import concurrent.futures
import importlib.util
import io
import json
import tempfile
import threading
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen

spec = importlib.util.spec_from_file_location('dashboard_server', Path(__file__).resolve().parents[1]/'server.py')
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)


def archive_bytes():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        z.writestr('metrics.csv', 'create_time,symbol,sum_open_interest,sum_open_interest_value\n2025-01-01 00:00:00,BTCUSDT,10,1000\n2025-01-01 00:05:00,BTCUSDT,11,1100\n')
    return buf.getvalue()


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = s.Store(self.tmp.name)
        self.label = dict(symbol='BTCUSDT', event_id='1', timestamp_ms=1735689601000, market='spot', interval='1m')

    def tearDown(self):
        self.tmp.cleanup()

    def test_archive_values_and_utc(self):
        self.assertEqual(s.read_archive(archive_bytes(), 'BTCUSDT'), [[1735689600000, 1000.0, 10.0], [1735689900000, 1100.0, 11.0]])

    def test_atomic_persistence_and_duplicates(self):
        a = self.store.add_label(self.label)
        self.assertEqual(self.store.add_label(self.label)['id'], a['id'])
        saved = s.Store(self.tmp.name).labels()['annotations']
        self.assertEqual(len(saved), 1)
        self.assertEqual(saved[0]['timestamp_cst'], '2025-01-01T08:00:01.000+08:00')
        self.assertEqual(saved[0]['time_basis'], 'cursor')
        self.store.delete_label(a['id'])
        self.assertEqual(self.store.labels()['annotations'], [])

    def test_concurrent_writes_not_lost(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            list(pool.map(lambda i: self.store.add_label(dict(self.label, timestamp_ms=self.label['timestamp_ms']+i*1000)), range(30)))
        self.assertEqual(len(self.store.labels()['annotations']), 30)
        self.assertEqual(list(self.store.labels_path.parent.glob('*.tmp')), [])

    def test_corrupt_file_preserved(self):
        self.store.labels_path.parent.mkdir()
        self.store.labels_path.write_text('{broken')
        with self.assertRaises(ValueError): self.store.add_label(self.label)
        self.assertEqual(self.store.labels_path.read_text(), '{broken')

    def test_failed_replace_keeps_old_file(self):
        self.store.add_label(self.label)
        before = self.store.labels_path.read_bytes()
        with patch.object(s.os, 'replace', side_effect=OSError('disk failure')):
            with self.assertRaises(OSError): self.store.add_label(dict(self.label, timestamp_ms=self.label['timestamp_ms']+1000))
        self.assertEqual(self.store.labels_path.read_bytes(), before)

    def test_invalid_label_rejected(self):
        for change in [dict(timestamp_ms=True), dict(timestamp_ms=-1), dict(symbol='../etc'), dict(market='bad'), dict(interval='bad'), dict(event_id='../')]:
            with self.assertRaises(ValueError): self.store.add_label(dict(self.label, **change))
        self.assertFalse(self.store.labels_path.exists())

    def test_complete_day_uses_cache(self):
        points = [[1735689600000+i*s.STEP, 1000+i, 10] for i in range(288)]
        with patch.object(s, 'fetch_bytes', return_value=b'dummy') as fetch, patch.object(s, 'read_archive', return_value=points):
            first, _ = self.store.oi_day('BTCUSDT', '2025-01-01')
            second, _ = self.store.oi_day('BTCUSDT', '2025-01-01')
        self.assertEqual(first, second)
        self.assertEqual(fetch.call_count, 1)

    def test_recent_rest_fills_missing_archive(self):
        now = int(s.time.time()*1000)
        start = now//s.DAY*s.DAY-s.DAY
        day = s.datetime.fromtimestamp(start/1000, s.UTC).date().isoformat()
        rows = [dict(timestamp=start+i*s.STEP, sumOpenInterestValue=1000, sumOpenInterest=10) for i in range(288)]
        def fake(url):
            if 'data.binance.vision' in url: raise HTTPError(url, 404, 'missing', {}, None)
            return json.dumps(rows).encode()
        with patch.object(s, 'fetch_bytes', side_effect=fake):
            points, warning = self.store.oi_day('BTCUSDT', day)
        self.assertEqual(len(points), 288)
        self.assertEqual(warning, '')

    def test_missing_historical_archive_remains_missing(self):
        with patch.object(s, 'fetch_bytes', side_effect=HTTPError('https://example', 404, 'missing', {}, None)):
            result = self.store.oi('BTCUSDT', 1735689600000, 1735693200000)
        self.assertFalse(result['complete'])
        self.assertEqual(result['points'], [])
        self.assertTrue(result['warnings'])

    def test_real_http_json_write_and_origin_guard(self):
        server = s.make_server(self.tmp.name, 0)
        thread = threading.Thread(target=server.serve_forever, daemon=True);thread.start()
        base = f'http://127.0.0.1:{server.server_port}'
        try:
            req = Request(base+'/api/annotations', data=json.dumps(self.label).encode(), headers={'Content-Type':'application/json'}, method='POST')
            with urlopen(req) as response: label = json.load(response)
            self.assertEqual(label['symbol'], 'BTCUSDT')
            with urlopen(base+'/api/annotations') as response: self.assertEqual(len(json.load(response)['annotations']), 1)
            req = Request(base+'/api/annotations', data=json.dumps(self.label).encode(), headers={'Content-Type':'application/json','Origin':'https://external.example'}, method='POST')
            with self.assertRaises(HTTPError) as exc: urlopen(req)
            self.assertEqual(exc.exception.code, 403)
            with urlopen(Request(base+'/api/annotations/'+label['id'], method='DELETE')) as response: self.assertTrue(json.load(response)['ok'])
        finally:
            server.shutdown();server.server_close();thread.join()

if __name__ == '__main__': unittest.main()
