import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd

from research.activity import continuity, hourly_context, context_frame, activity_at
from research.config import Config, json_write
from research.data import fetch_oi, fetch_funding, download, download_request
from research.features import frozen_robust_z
from research.oi import native_oi, diagnose_oi, contract
from research.storage import write_frame, read_frame, receipt
from research.train import choose_model


def quiet_raw(days=22):
    ix = pd.date_range('2026-01-01T00:01Z', periods=days*1440, freq='min', name='time')
    return pd.DataFrame({'open':1.,'close':1.,'high':1.,'low':1.,'quote':10.,
                         'volume':10.,'trades':1.,'taker_quote':5.}, index=ix)


class ActivityTests(unittest.TestCase):
    def test_continuity_counts_minutes_not_orders_or_size_and_preserves_gaps(self):
        raw = quiet_raw(1).iloc[:20].copy()
        raw['trades'] = [1000,0,1,0,9]*4
        c = continuity(raw)
        self.assertAlmostEqual(c.continuity5.iloc[-1], .6)
        self.assertAlmostEqual(c.continuity15.iloc[-1], .6)
        self.assertTrue(pd.isna(c.continuity60.iloc[-1]))
        missing = continuity(raw.drop(raw.index[10]))
        self.assertTrue(pd.isna(missing.continuity15.iloc[-1]))
        self.assertAlmostEqual(missing.continuity5.iloc[-1], .6)

    def test_long_quiet_is_left_censored_and_activation_keeps_prior_duration(self):
        raw = quiet_raw()
        start = pd.Timestamp('2026-01-21T12:00Z')
        raw.loc[raw.index > start, ['quote','trades']] = [1000.,10.]
        h = hourly_context(raw)
        before = h.loc[start+pd.Timedelta(minutes=30)]
        self.assertEqual(before.activity_state, 1)
        self.assertTrue(before.quiet_lower_bound)
        self.assertGreater(before.quiet_hours, 72)
        after = h.loc[start+pd.Timedelta(hours=1, minutes=30)]
        self.assertEqual(after.activity_state, 3)
        self.assertEqual(after.quiet_kind, 2)
        self.assertEqual(before.quiet_hours, after.quiet_hours)

    def test_future_changes_cannot_rewrite_background_or_early_activation(self):
        raw = quiet_raw()
        at = pd.Timestamp('2026-01-20T12:45Z')
        original = hourly_context(raw)
        raw.loc[raw.index > at, ['close','high','low']] *= 2
        raw.loc[raw.index > at, ['quote','trades']] *= 100
        changed = hourly_context(raw)
        pd.testing.assert_frame_equal(original.loc[:at], changed.loc[:at])
        # A background hour is not exposed until its 30-minute release delay.
        self.assertEqual(original.loc[:at].iloc[-1].background_at_ms,
                         pd.Timestamp('2026-01-20T12:00Z').value//10**6)

    def test_pump_memory_survives_price_return_to_start(self):
        raw = quiet_raw()
        pump = (raw.index >= '2026-01-20T12:00Z') & (raw.index <= '2026-01-20T18:00Z')
        raw.loc[pump,['open','close','high','low']] = 1.4
        h = hourly_context(raw)
        row = h.loc['2026-01-21T12:30Z']
        self.assertEqual(row.activity_state, 6)
        self.assertGreater(row.runup7d,.39)

    def test_gap_breaks_quiet_duration_instead_of_counting_as_silence(self):
        raw = quiet_raw()
        gap = pd.Timestamp('2026-01-21T12:00Z')
        raw = raw.drop(gap)
        h = hourly_context(raw)
        self.assertEqual(h.loc[gap+pd.Timedelta(minutes=30),'activity_state'],0)
        row = h.loc[gap+pd.Timedelta(hours=7, minutes=30)]
        self.assertEqual(row.quiet_hours,7)
        self.assertTrue(row.quiet_lower_bound)

    def test_context_cache_invalidates_when_raw_changes(self):
        with tempfile.TemporaryDirectory() as root:
            cfg=Config(start='2026-01-20',end='2026-01-23',root=root,symbols=['TESTUSDT'])
            p=Path(root)/'raw/TESTUSDT.parquet'
            raw=quiet_raw()
            write_frame(raw,p)
            original=context_frame(cfg,'TESTUSDT')
            with patch('research.activity.hourly_context',side_effect=AssertionError('must reuse')):
                context_frame(cfg,'TESTUSDT')
            raw.loc[raw.index>'2026-01-21',['quote','trades']]=[1000,10]
            write_frame(raw,p)
            updated=context_frame(cfg,'TESTUSDT')
            self.assertNotEqual(original.iloc[-1].activity_state,updated.iloc[-1].activity_state)


class OITests(unittest.TestCase):
    def setUp(self):
        ix=pd.date_range('2026-01-01T00:01Z',periods=2050,freq='5min',name='time')
        self.oi=pd.DataFrame({'oi':100+np.arange(len(ix))*.01,'oi_usdt':1000.},index=ix)

    def test_zero_oi_and_missing_intermediate_sample_do_not_create_infinite_spike(self):
        raw=self.oi.copy()
        raw.loc[raw.index[-6],'oi']=0
        native=native_oi(raw)
        self.assertTrue(native.iloc[-6:-2].doi15.isna().all())
        self.assertTrue(pd.isna(native.oi.iloc[-6]))
        self.assertTrue(pd.isna(native.oi_usdt.iloc[-6]))
        self.assertFalse(np.isinf(native.doi15).any())
        z=frozen_robust_z(native.doi15,window=2016,refresh=1)
        self.assertTrue(z.iloc[-6:-2].isna().all())
        self.assertTrue(np.isfinite(z.iloc[-1]))

    def test_missing_reasons_distinguish_no_archive_warmup_gap_invalid_and_ready(self):
        at=self.oi.index[-1]
        self.assertEqual(diagnose_oi(None,at)['code'],'no_archive')
        self.assertEqual(diagnose_oi(self.oi,at,mode='off')['code'],'off')
        self.assertEqual(diagnose_oi(self.oi,at-pd.Timedelta(days=10))['code'],'not_yet')
        self.assertEqual(diagnose_oi(self.oi.iloc[-100:],at)['code'],'warmup')
        self.assertEqual(diagnose_oi(self.oi,at+pd.Timedelta(minutes=5))['code'],'gap')
        bad=self.oi.copy();bad.iloc[-1,0]=0
        self.assertEqual(diagnose_oi(bad,at,zoi=4)['code'],'invalid')
        bad=self.oi.drop(self.oi.index[-2])
        self.assertEqual(diagnose_oi(bad,at,zoi=4)['code'],'change_gap')
        self.assertEqual(diagnose_oi(self.oi,at,zoi=1)['code'],'ready')

    def test_diagnosis_does_not_use_future_samples(self):
        at=self.oi.index[500]
        self.assertEqual(diagnose_oi(self.oi,at),diagnose_oi(self.oi.loc[:at],at))

    def test_rebuilt_oi_features_cannot_reuse_old_calibration(self):
        with tempfile.TemporaryDirectory() as root:
            cfg=Config(start='2026-01-01',end='2026-07-01',root=root)
            path=Path(root)/'results/models.json'
            model={'id':'old','usable_from':'2026-02-01T00:00Z'}
            json_write(path,[model])
            self.assertEqual(choose_model(cfg,'2026-03-01')['id'],'old')
            json_write(Path(root)/'features/build_info.json',{'version':2,'revision':'new-inputs'})
            self.assertIsNone(choose_model(cfg,'2026-03-01'))
            model['feature_revision']='new-inputs'
            json_write(path,[model])
            self.assertEqual(choose_model(cfg,'2026-03-01')['id'],'old')

    def test_mapped_contract_units_and_funding_path(self):
        cfg=Config(start='2026-01-01',end='2026-01-02',warmup_days=22)
        frame=pd.DataFrame({'create_time':['2026-01-01T00:00Z'],
                            'sum_open_interest':[123.], 'sum_open_interest_value':[456.]})
        paths=[]
        def archive(cfg,relative,log):
            paths.append(relative)
            return b'fixture'
        with patch('research.data.cached_zip',side_effect=archive),patch('research.data.zip_frame',return_value=frame):
            result=fetch_oi(cfg,'PEPEUSDT',[])
        self.assertTrue(all('/1000PEPEUSDT/' in p for p in paths))
        self.assertEqual(result.oi.iloc[0],123_000)
        self.assertEqual(result.oi_usdt.iloc[0],456)
        self.assertEqual(result.index[0],pd.Timestamp('2026-01-01T00:01Z'))
        funding=pd.DataFrame({'calc_time':[1767225600000], 'last_funding_rate':[.001], 'funding_interval_hours':[8]})
        with patch('research.data.cached_zip',side_effect=archive),patch('research.data.zip_frame',return_value=funding):
            self.assertEqual(fetch_funding(cfg,'PEPEUSDT',[]).funding8h.iloc[0],.001)
        self.assertTrue(all('1000PEPEUSDT' in p for p in paths))
        self.assertEqual(contract('BTCUSDT'),('BTCUSDT',1))

    def test_mapping_upgrade_reuses_converted_spot_and_retries_futures_only(self):
        with tempfile.TemporaryDirectory() as root:
            cfg=Config(start='2026-01-01',end='2026-01-02',root=root,symbols=['PEPEUSDT'])
            raw=quiet_raw(1)
            for symbol in ['PEPEUSDT','BTCUSDT']:
                p=Path(root)/'raw'/f'{symbol}.parquet'
                write_frame(raw,p)
                manifest={'symbol':symbol,'error':None,'spot_rows':len(raw),'oi_rows':0,'funding_rows':0,
                          'files':[],'raw_receipts':[receipt(p)],'request':download_request(cfg)}
                json_write(Path(root)/'manifests'/f'{symbol}.json',manifest)
            empty=pd.DataFrame()
            with patch('research.data.fetch_spot',side_effect=AssertionError('must reuse spot')), \
                    patch('research.data.fetch_oi',return_value=self.oi) as fetch, \
                    patch('research.data.fetch_funding',return_value=empty):
                download(cfg,workers=1)
            self.assertEqual(fetch.call_count,1)
            self.assertEqual(fetch.call_args.args[1],'PEPEUSDT')
            manifest=json.loads((Path(root)/'manifests/PEPEUSDT.json').read_text())
            self.assertEqual(manifest['oi_source_symbol'],'1000PEPEUSDT')
            self.assertEqual(len(read_frame(Path(root)/'raw/PEPEUSDT.parquet')),len(raw))


if __name__=='__main__':
    unittest.main()
