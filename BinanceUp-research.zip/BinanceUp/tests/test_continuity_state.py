import unittest
import numpy as np
import pandas as pd
from research.continuity_state import metrics


def raw(n=800):
    return pd.DataFrame({"trades":1., "taker_quote":1.},
        index=pd.date_range("2026-01-01T00:01Z",periods=n,freq="min",name="time"))


class ContinuityStateTests(unittest.TestCase):
    def test_complete_windows_endpoints_and_duration(self):
        data=raw()
        data.taker_quote=0.
        f=metrics(data)
        self.assertTrue(f.state_trade_high360.iloc[:363].isna().all())
        self.assertEqual(f.state_trade_high360.iloc[363],1)
        self.assertEqual(f.state_trade_run80.iloc[363],360)
        self.assertEqual(f.state_trade_run100.iloc[363],360)
        self.assertEqual(f.state_buy_high360.iloc[363],0)
        self.assertEqual(f.state_buy_low360.iloc[363],1)

    def test_eighty_percent_tolerates_one_missing_buy_minute_in_five(self):
        data=raw()
        data.iloc[::5,data.columns.get_loc("taker_quote")]=0.
        f=metrics(data)
        self.assertEqual(f.state_buy_high180.iloc[-1],1)
        self.assertEqual(f.state_buy_run80.iloc[-1],len(data)-4)
        self.assertEqual(f.state_buy_run100.iloc[-1],0)
        self.assertEqual(f.state_buy_c5.iloc[-1],.8)

    def test_gaps_invalid_values_reset_and_occupancy_remains_unknown(self):
        for bad in (np.nan,-1,np.inf):
            data=raw()
            data.iloc[400,data.columns.get_loc("taker_quote")]=bad
            f=metrics(data.drop(data.index[600]))
            self.assertTrue(f.state_buy_run80.iloc[400:405].isna().all())
            self.assertEqual(f.state_buy_run80.iloc[405],1)
            self.assertTrue(f.state_buy_high180.iloc[400:584].isna().all())
            self.assertEqual(f.state_buy_high180.iloc[584],1)
            self.assertTrue(f.iloc[600].isna().all())

    def test_causal_and_manual_rolling_frequency(self):
        data=raw()
        rng=np.random.default_rng(27)
        data.taker_quote=(rng.random(len(data))>.3).astype(float)
        f=metrics(data)
        points=data.taker_quote.gt(0).rolling(5).sum()
        high=points.ge(4).astype(float).where(points.notna())
        np.testing.assert_allclose(f.state_buy_high180,high.rolling(180).mean(),equal_nan=True)
        data.iloc[500:,data.columns.get_loc("taker_quote")]=0
        pd.testing.assert_frame_equal(f.iloc[:500],metrics(data).iloc[:500])
