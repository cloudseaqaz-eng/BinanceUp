import unittest
import numpy as np
import pandas as pd
from research.distribution_score import metrics, score_points


def raw(n=200):
    return pd.DataFrame({"trades":np.arange(n)%2,"taker_quote":np.arange(n)%3},
        index=pd.date_range("2026-01-01T00:01Z", periods=n, freq="min", name="time"))


class DistributionScoreTests(unittest.TestCase):
    def test_same_mean_different_low_tail(self):
        stable=score_points(pd.Series([3.]*30),30).iloc[-1]
        interrupted=score_points(pd.Series([1.]*15+[5.]*15),30).iloc[-1]
        self.assertEqual(stable["mean"],interrupted["mean"])
        self.assertAlmostEqual(stable.score,60)
        self.assertAlmostEqual(interrupted.score,48)
        self.assertAlmostEqual(interrupted.lowshare,.5)
        self.assertAlmostEqual(interrupted.highshare,.5)

    def test_bucket_method_equals_sorted_lowest_samples(self):
        rng=np.random.default_rng(27)
        points=pd.Series(rng.integers(0,6,100).astype(float))
        for window in (15,30):
            result=score_points(points,window)
            expected=points.rolling(window).apply(
                lambda a:100*(.7*a.mean()/5+.3*np.sort(a)[:window//5].mean()/5),raw=True)
            np.testing.assert_allclose(result.score,expected,equal_nan=True)

    def test_missing_invalid_prewarm_and_endpoints(self):
        data=raw()
        data.trades=1.
        data.taker_quote=0.
        result=metrics(data)
        self.assertTrue(result.dist_trade_score30.iloc[:33].isna().all())
        self.assertEqual(result.dist_trade_score30.iloc[33],100)
        self.assertEqual(result.dist_buy_score15.iloc[18],0)
        for value in (np.nan,-1,np.inf):
            changed=data.copy()
            changed.iloc[80,changed.columns.get_loc("taker_quote")]=value
            r=metrics(changed.drop(changed.index[120]))
            self.assertTrue(r.dist_buy_score30.iloc[80:114].isna().all())
            self.assertEqual(r.dist_buy_score30.iloc[114],0)
            self.assertTrue(r.iloc[120].filter(like="score").isna().all())

    def test_future_does_not_change_past_and_channels_are_independent(self):
        data=raw()
        original=metrics(data)
        data.iloc[120:,data.columns.get_loc("taker_quote")]=0
        changed=metrics(data)
        pd.testing.assert_frame_equal(original.iloc[:120],changed.iloc[:120])
        pd.testing.assert_frame_equal(original.filter(like="dist_trade"),changed.filter(like="dist_trade"))
