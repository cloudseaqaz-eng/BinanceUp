import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
import numpy as np
import pandas as pd
from research.config import Config, COMPONENTS, PDF_WEIGHTS, board_symbol, json_write
from research.data import parse_klines
from research.features import make_features, frozen_robust_z, bars5, past_percentile
from research.labels import future_labels, build_labels
from research.scoring import scores, pool_entries
from research.train import choose_model, model_schedule, probabilities, fit_calibration


class LabelTests(unittest.TestCase):
    def test_first_future_entry_and_censoring(self):
        top = [0,0,0,1,1,0,0,1,0,0]
        target, delay = future_labels(top, np.ones(10, dtype=bool), 3)
        self.assertEqual(target[0], 1)  # exact horizon boundary counts
        self.assertEqual(delay[0], 3)
        self.assertTrue(np.isnan(target[3]))  # already top N
        self.assertEqual(delay[5], 2)  # first hit, not endpoint
        self.assertTrue(np.isnan(target[8]))  # unobserved full future

    def test_gap_does_not_become_negative_or_selective_positive(self):
        target, _ = future_labels([0,1,0,0,0,0], [1,1,0,1,1,1], 3)
        self.assertTrue(np.isnan(target[0]))  # early hit still censored if horizon has gap
        self.assertTrue(np.isnan(target[2]))

    def test_no_hit_is_zero_with_complete_window(self):
        target, _ = future_labels(np.zeros(8), np.ones(8), 3)
        np.testing.assert_array_equal(target[:5], np.zeros(5))
        self.assertTrue(np.isnan(target[5:]).all())

    def test_failed_download_cannot_silently_remove_competitor(self):
        with tempfile.TemporaryDirectory() as root:
            cfg=Config(start='2026-01-01',end='2026-07-01',root=root,symbols=['BTCUSDT','ETHUSDT'])
            json_write(Path(root)/'download_summary.json', [{'symbol':'BTCUSDT','error':None},{'symbol':'ETHUSDT','error':'network'}])
            with self.assertRaisesRegex(ValueError, '拒绝缩小榜单'):
                build_labels(cfg)

    def test_board_keeps_unscored_competitors_and_censors_on_their_gaps(self):
        with tempfile.TemporaryDirectory() as root:
            symbols=['BTCUSDT']+[f'T{i:02d}USDT' for i in range(11)]
            cfg=Config(start='2026-01-01',end='2026-01-06',root=root,symbols=symbols,universe_scope='synthetic_demo')
            for d in ('raw','features'):
                (Path(root)/d).mkdir()
            ix=pd.date_range('2026-01-01T00:01:00Z', '2026-01-06T00:00:00Z',freq='min',name='time')
            gap=pd.Timestamp('2026-01-04T12:00:00Z')
            for j,s in enumerate(symbols):
                c=100*np.exp(j*np.arange(len(ix))/1000000)
                # All competitors have almost no liquidity; ranking must still include them.
                raw=pd.DataFrame({'open':c,'high':c,'low':c,'close':c,'volume':1.,'quote':1.,'trades':1.,'taker_quote':.5},index=ix)
                if j==11:
                    raw=raw.drop(gap)
                raw.to_parquet(Path(root)/'raw'/(s+'.parquet'))
            pd.DataFrame({'zr5':0.,'sigma':.001},index=ix).to_parquet(Path(root)/'features/BTCUSDT.parquet')
            build_labels(cfg)
            lab=pd.read_parquet(Path(root)/'labels/BTCUSDT.parquet')
            market=pd.read_parquet(Path(root)/'market.parquet')
            self.assertEqual(lab.loc['2026-01-03T00:00:00Z','rank24'],12)
            self.assertFalse(market.loc[gap,'board_valid'])
            self.assertTrue(np.isnan(lab.loc[gap-pd.Timedelta(hours=1),'target']))


class ArchiveTests(unittest.TestCase):
    def test_millisecond_microsecond_and_close_time(self):
        for factor in (1, 1000):
            ms = 1767225600000
            line = f'{ms*factor},1,2,.5,1.5,10,{(ms+59999)*factor},15,8,6,9,0\n'
            b = io.BytesIO()
            with zipfile.ZipFile(b, 'w') as z:
                z.writestr('test.csv', line)
            f = parse_klines(b.getvalue())
            self.assertEqual(f.index[0], pd.Timestamp('2026-01-01T00:01:00Z'))
            self.assertEqual(f.iloc[0].trades, 8)
            self.assertEqual(f.iloc[0].taker_quote, 9)

    def test_universe_exclusions_not_suffix_guessing(self):
        self.assertFalse(board_symbol('USDCUSDT'))
        self.assertFalse(board_symbol('BTCUPUSDT'))
        self.assertTrue(board_symbol('JUPUSDT'))
        self.assertTrue(board_symbol('SUPERUSDT'))


class FeatureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        rng = np.random.default_rng(22)
        ix = pd.date_range('2026-01-01T00:01:00Z', periods=31*1440, freq='min', name='time')
        close = 100*np.exp(np.cumsum(rng.normal(0,.0004,len(ix))))
        q = rng.lognormal(10.8,.5,len(ix))
        cls.raw = pd.DataFrame({'open':np.r_[close[0],close[:-1]],'high':close*1.001,'low':close*.999,'close':close,
                                'volume':q/close,'quote':q,'trades':q/100,'taker_quote':q*rng.uniform(.4,.6,len(ix))},index=ix)
        cls.cut = ix[-1441]
        cls.original = make_features(cls.raw, cls.raw)

    def test_future_mutation_cannot_change_past_features(self):
        changed = self.raw.copy()
        future = changed.index > self.cut
        changed.loc[future, ['open','high','low','close']] *= 5
        changed.loc[future, ['quote','trades','taker_quote']] *= 20
        modified = make_features(changed, changed)
        cols = COMPONENTS+['rvol15','tcr15','bbw_pct','bo1h','div','beta','zres30','zr15','penalty']
        pd.testing.assert_frame_equal(self.original.loc[:self.cut,cols], modified.loc[:self.cut,cols])

    def test_seasonal_and_core_features_are_ready_after_warmup(self):
        self.assertTrue(self.original.feature_ready.iloc[-1])
        self.assertTrue(.5 < self.original.rvol15.iloc[-1] < 2)

    def test_five_minute_bars_use_only_closed_minutes_and_leave_gaps(self):
        cut = self.raw.iloc[:7]
        five = bars5(cut)
        self.assertEqual(five.index[-1], pd.Timestamp('2026-01-01T00:05:00Z'))
        self.assertEqual(five.close.iloc[-1], cut.close.iloc[4])
        bad = cut.copy()
        bad.iloc[2] = np.nan
        self.assertTrue(bars5(bad).close.isna().all())

    def test_percentile_excludes_current(self):
        s = pd.Series([1.,2.,3.,2.])
        self.assertEqual(past_percentile(s,3).iloc[-1], 2/3)

    def test_robust_baseline_excludes_current(self):
        s = pd.Series(np.arange(50,dtype=float), index=pd.date_range('2026-01-01',periods=50,freq='min',tz='UTC'))
        a = frozen_robust_z(s,window=10,refresh=1)
        s.iloc[-1] = 1000
        b = frozen_robust_z(s,window=10,refresh=1)
        np.testing.assert_array_equal(a.iloc[:-1], b.iloc[:-1])
        self.assertEqual(b.iloc[-1],4)


class ScoringTests(unittest.TestCase):
    def test_missing_oi_redistribution_and_core_missing(self):
        f = pd.DataFrame(np.ones((3,8))*.5,columns=COMPONENTS)
        f.loc[1,'oi_build'] = np.nan
        f.loc[2,'compression'] = np.nan
        f['penalty']=1
        s=scores(f)
        self.assertAlmostEqual(s[0],50)
        self.assertAlmostEqual(s[1],50)
        self.assertTrue(np.isnan(s[2]))

    def test_pool_hysteresis_exit_and_cooldown(self):
        f=pd.DataFrame({'time':pd.date_range('2026-01-01',periods=25,freq='min',tz='UTC'), 'symbol':'TESTUSDT',
                        'score':[60,35,35,35]+[70]*21,'eligible':True,'penalty':1,'risk_off':False})
        cfg=Config(start='2026-01-01',end='2026-07-01')
        entries=pool_entries(f,cfg=cfg)
        self.assertEqual(entries.index.tolist(),[0,18])

    def test_pool_state_continues_across_model_boundary(self):
        f=pd.DataFrame({'time':pd.date_range('2026-01-01',periods=200,freq='min',tz='UTC'), 'symbol':'TESTUSDT',
                        'score':70.,'eligible':True,'penalty':1.,'risk_off':False})
        cfg=Config(start='2026-01-01',end='2026-07-01')
        whole=pool_entries(f,cfg=cfg)
        first,state=pool_entries(f.iloc[:90],cfg=cfg,return_state=True)
        second,state=pool_entries(f.iloc[90:],cfg=cfg,state=state,return_state=True)
        self.assertEqual(pd.concat([first,second]).index.tolist(),whole.index.tolist())
        self.assertEqual(whole.index.tolist(),[0,75,150])


class TrainingTests(unittest.TestCase):
    def test_model_is_never_visible_before_training_finishes(self):
        with tempfile.TemporaryDirectory() as root:
            cfg=Config(start='2026-01-01',end='2026-07-01',root=root)
            model={'id':'later','usable_from':'2026-05-01T00:00:00Z'}
            json_write(Path(root)/'results/models.json',[model])
            self.assertIsNone(choose_model(cfg,'2026-04-30T23:59:00Z'))
            self.assertEqual(choose_model(cfg,'2026-05-01T00:00:00Z')['id'],'later')

    def test_final_holdout_does_not_overlap_walkforward(self):
        cfg=Config(start='2026-04-22',end='2026-10-22')
        folds=model_schedule(cfg)
        self.assertTrue(folds[-1][2])
        self.assertEqual(folds[-2][1],folds[-1][0])
        self.assertEqual(folds[0][0],pd.Timestamp('2026-07-18',tz='UTC'))

    def test_insufficient_calibration_does_not_invent_probability(self):
        cfg=Config(start='2026-01-01',end='2026-07-01')
        f=pd.DataFrame({'eligible':[True], 'target':[1.], 'score':[70.], 'oi_available':[False],
                        'time':[pd.Timestamp('2026-01-01',tz='UTC')], 'symbol':['BTCUSDT'], 'first_hit_minutes':[5.]})
        cal=fit_calibration(f,cfg)
        self.assertTrue(np.isnan(probabilities(f,cal)[0]))


if __name__=='__main__':
    unittest.main()
