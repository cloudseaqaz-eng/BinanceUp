import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd
from research.config import Config, COMPONENTS, json_write
from research.data import download, download_request
from research.scoring import scores
from research.storage import (write_frame, read_frame, assert_exact, metadata, compact,
                              source_digest, file_digest, receipt, prune_archives)


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.cfg = Config(start='2026-01-01', end='2026-07-01', root=str(self.root), symbols=['BTCUSDT'])
        for name in ('raw', 'features', 'manifests'):
            (self.root/name).mkdir()
        ix = pd.date_range('2026-01-01T00:01:00Z', periods=48, freq='min', name='time')
        self.raw = pd.DataFrame({c: np.arange(48, dtype='float64')+.12345678912345 for c in
                                ('open','high','low','close','volume','quote','trades','taker_quote')}, index=ix)
        self.raw.iloc[8] = np.nan
        self.raw.loc[ix[1], 'quote'] = -0.
        self.rp = self.root/'raw/BTCUSDT.parquet'
        self.fp = self.root/'features/BTCUSDT.parquet'
        self.raw.to_parquet(self.rp)
        self.f = self.raw.astype('float32')
        for c in COMPONENTS:
            self.f[c] = np.linspace(0, 1, 48, dtype='float32')
        self.f['penalty'] = np.ones(48, dtype='float32')
        self.f['observed'] = self.raw.close.notna()

    def tearDown(self):
        self.tmp.cleanup()

    def test_virtual_raw_columns_rehydrate_exact_values_dtype_gaps_and_scores(self):
        info = write_frame(self.f, self.fp, raw_source=self.rp)
        self.assertEqual(len(info['virtual_columns']), 8)
        self.assertNotIn('close', pd.read_parquet(self.fp).columns)
        result = read_frame(self.fp)
        assert_exact(self.f, result)
        np.testing.assert_array_equal(scores(self.f), scores(result))
        subset = read_frame(self.fp, self.f.index[5], self.f.index[12], columns=['quote','close'])
        assert_exact(self.f.iloc[5:13][['quote','close']], subset)
        self.assertTrue(np.signbit(result.quote.iloc[1]))

    def test_non_identical_duplicate_is_kept(self):
        self.f.loc[self.f.index[2], 'close'] = 999
        info = write_frame(self.f, self.fp, raw_source=self.rp)
        self.assertNotIn('close', info['virtual_columns'])
        assert_exact(self.f, read_frame(self.fp))

    def test_recompressing_raw_keeps_existing_feature_references_valid(self):
        write_frame(self.f, self.fp, raw_source=self.rp)
        old_digest = source_digest(self.rp)
        write_frame(self.raw, self.rp)
        self.assertEqual(source_digest(self.rp), old_digest)
        assert_exact(self.f, read_frame(self.fp))

    def test_changed_source_cannot_silently_change_old_scores(self):
        write_frame(self.f, self.fp, raw_source=self.rp)
        changed = self.raw.copy()
        changed.loc[changed.index[2], 'close'] = 1000
        write_frame(changed, self.rp)
        with self.assertRaisesRegex(ValueError, '基础行情已变化'):
            read_frame(self.fp)

    def test_failed_verification_does_not_replace_good_file(self):
        self.f.to_parquet(self.fp)
        before = self.fp.read_bytes()
        with patch('research.storage.assert_exact', side_effect=AssertionError('test mismatch')):
            with self.assertRaises(AssertionError):
                write_frame(self.f, self.fp)
        self.assertEqual(self.fp.read_bytes(), before)
        self.assertEqual(list(self.fp.parent.glob('*.part')), [])

    def test_migration_is_exact_and_idempotent(self):
        self.f.to_parquet(self.fp)
        first = compact(self.cfg)
        self.assertEqual(first['files_verified'], 2)
        assert_exact(self.f, read_frame(self.fp))
        before = self.fp.read_bytes()
        again = compact(self.cfg)
        self.assertEqual(again['files_verified'], 0)
        self.assertEqual(self.fp.read_bytes(), before)

    def test_raw_float64_is_not_downcast(self):
        write_frame(self.raw, self.rp)
        result = read_frame(self.rp)
        assert_exact(self.raw, result)
        self.assertEqual(result.close.dtype, np.dtype('float64'))

    def test_archive_cleanup_requires_valid_converted_files_and_only_deletes_listed_zip(self):
        directory = self.root/'archive'
        directory.mkdir()
        archive = directory/'sample.zip'
        archive.write_bytes(b'verified-source-for-test')
        other = directory/'unrelated.zip'
        other.write_bytes(b'preserve')
        manifest = {'error': None, 'raw_receipts': [receipt(self.rp)],
                    'files': [{'path':'sample.zip','sha256':file_digest(archive),'status':'cached'}]}
        with patch('research.storage.verify_receipts',return_value=False):
            with self.assertRaisesRegex(ValueError, '拒绝清理'):
                prune_archives(self.cfg,manifest)
        self.assertTrue(archive.exists())
        manifest['files'][0]['sha256'] = 'incorrect'
        with self.assertRaisesRegex(ValueError, '哈希不符'):
            prune_archives(self.cfg,manifest)
        self.assertTrue(archive.exists())
        manifest['files'][0]['sha256'] = file_digest(archive)
        self.assertGreater(prune_archives(self.cfg,manifest),0)
        self.assertFalse(archive.exists())
        self.assertTrue(other.exists())

    def test_download_resumes_without_network_after_archives_removed(self):
        result={'symbol':'BTCUSDT','error':None,'spot_rows':len(self.raw),'oi_rows':0,'funding_rows':0,
                'files':[],'raw_receipts':[receipt(self.rp)],'request':download_request(self.cfg)}
        json_write(self.root/'manifests/BTCUSDT.json',result)
        with patch('research.data.get',side_effect=AssertionError('network must not be used')):
            resumed=download(self.cfg,workers=1)
        self.assertEqual(resumed[0]['spot_rows'],len(self.raw))

    def test_refresh_cannot_overwrite_verified_data_with_missing_archive_rows(self):
        result={'symbol':'BTCUSDT','error':None,'spot_rows':len(self.raw),'oi_rows':0,'funding_rows':0,
                'files':[],'raw_receipts':[receipt(self.rp)],'request':download_request(self.cfg)}
        json_write(self.root/'manifests/BTCUSDT.json',result)
        before = self.rp.read_bytes()
        with patch('research.data.fetch_spot', return_value=self.raw.iloc[:-1]):
            with self.assertRaisesRegex(RuntimeError, '部分下载失败'):
                download(self.cfg,workers=1,refresh=True)
        self.assertEqual(before,self.rp.read_bytes())
        preserved = json.loads((self.root/'manifests/BTCUSDT.json').read_text())
        self.assertEqual(preserved['spot_rows'],len(self.raw))
        self.assertIsNone(preserved['error'])

    def test_new_download_prunes_only_after_converted_checkpoint_is_saved(self):
        directory=self.root/'archive';directory.mkdir()
        archive=directory/'sample.zip';archive.write_bytes(b'test-source')
        self.cfg.oi_mode='off'
        def fetch(cfg,symbol,log):
            log.append({'path':'sample.zip','sha256':file_digest(archive),'status':'downloaded'})
            return self.raw
        with patch('research.data.fetch_spot',side_effect=fetch):
            result=download(self.cfg,workers=1)
        self.assertFalse(archive.exists())
        self.assertIsNone(result[0]['error'])
        self.assertTrue(result[0]['raw_receipts'])
        assert_exact(self.raw,read_frame(self.rp))
        with patch('research.data.get',side_effect=AssertionError('no network')):
            download(self.cfg,workers=1)

    def test_failure_after_spot_conversion_keeps_archive(self):
        directory=self.root/'archive';directory.mkdir()
        archive=directory/'sample.zip';archive.write_bytes(b'test-source')
        def fetch(cfg,symbol,log):
            log.append({'path':'sample.zip','sha256':file_digest(archive),'status':'downloaded'})
            return self.raw
        with patch('research.data.fetch_spot',side_effect=fetch), patch('research.data.fetch_oi',side_effect=RuntimeError('OI download failed')):
            with self.assertRaisesRegex(RuntimeError,'部分下载失败'):
                download(self.cfg,workers=1)
        self.assertTrue(archive.exists())


if __name__ == '__main__':
    unittest.main()
