#!/bin/bash
set -e
cd "$(dirname "$0")"
PYTHON=python3
if [ -x .venv/bin/python ]; then PYTHON=.venv/bin/python; fi
exec "$PYTHON" -m research --root "${1:-research_data}" serve --port 8767
