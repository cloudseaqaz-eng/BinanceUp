#!/usr/bin/env python3
"""Local dashboard server. Standard library only; bind to loopback."""
import argparse
import csv
import io
import json
import math
import os
import re
import tempfile
import threading
import time
import uuid
import webbrowser
import zipfile
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import parse_qs, urlencode, urlsplit
from urllib.request import Request, urlopen

UTC = timezone.utc
CST = timezone(timedelta(hours=8))
DAY = 86400000
STEP = 300000
SYMBOL = re.compile(r"^[A-Z0-9]{2,30}USDT$")


def atomic_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            json.dump(data, out, ensure_ascii=False, indent=2, allow_nan=False)
            out.write('\n')
            out.flush()
            os.fsync(out.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def normalize_points(points):
    result = {}
    for p in points:
        try:
            t, value = int(p[0]), float(p[1])
            quantity = float(p[2]) if len(p) > 2 and p[2] is not None else None
            if t >= 0 and math.isfinite(value) and value >= 0:
                result[t] = [t, value] + ([quantity] if quantity is not None and math.isfinite(quantity) else [])
        except (ValueError, TypeError, IndexError, OverflowError):
            continue
    return sorted(result.values())


def read_archive(body, symbol):
    points = []
    with zipfile.ZipFile(io.BytesIO(body)) as archive:
        names = [n for n in archive.namelist() if n.endswith('.csv')]
        if not names:
            raise ValueError('历史备份没有CSV文件')
        with archive.open(names[0]) as raw:
            rows = csv.DictReader(io.TextIOWrapper(raw, encoding='utf-8-sig'))
            for row in rows:
                if row.get('symbol') != symbol:
                    continue
                dt = datetime.fromisoformat(row['create_time'].replace('Z', '+00:00'))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=UTC)
                points.append([int(dt.timestamp()*1000), row['sum_open_interest_value'], row['sum_open_interest']])
    return normalize_points(points)


def fetch_bytes(url):
    request = Request(url, headers={'User-Agent': 'BinanceUp-LocalDashboard/1.0'})
    with urlopen(request, timeout=12) as response:
        body = response.read(16*1024*1024 + 1)
        if len(body) > 16*1024*1024:
            raise ValueError('上游文件超过大小限制')
        return body


def full_coverage(points, start, end):
    first = math.ceil(start/STEP)*STEP
    last = math.floor(end/STEP)*STEP
    ticks = {p[0] for p in points}
    return all(t in ticks for t in range(first, last+1, STEP))


class Store:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.labels_path = self.root / 'data' / 'buy_points.json'
        self.label_lock = threading.Lock()
        self.cache_lock = threading.Lock()
        self.day_locks = {}

    def read_labels(self):
        if not self.labels_path.exists():
            return {'schema_version': 1, 'annotations': []}
        doc = json.loads(self.labels_path.read_text(encoding='utf-8'))
        if not isinstance(doc, dict) or doc.get('schema_version') != 1 or not isinstance(doc.get('annotations'), list):
            raise ValueError('buy_points.json 格式异常；已保留原文件，未覆盖')
        return doc

    def labels(self):
        with self.label_lock:
            return self.read_labels()

    def add_label(self, data):
        if not isinstance(data, dict):
            raise ValueError('请求必须为JSON对象')
        symbol = data.get('symbol', '')
        if not isinstance(symbol, str) or not SYMBOL.fullmatch(symbol):
            raise ValueError('交易对格式无效')
        timestamp = data.get('timestamp_ms')
        if type(timestamp) is not int or not 0 < timestamp <= int(time.time()*1000)+DAY:
            raise ValueError('标注时间无效')
        event_id = str(data.get('event_id', ''))
        if not re.fullmatch(r'\d{1,20}', event_id):
            raise ValueError('事件编号无效')
        market = data.get('market')
        interval = data.get('interval')
        if market not in ('spot', 'perp', 'up', 'oi') or interval not in ('1m', '3m', '5m', '15m', '1h'):
            raise ValueError('市场或周期无效')
        dt = datetime.fromtimestamp(timestamp/1000, UTC)
        label = {
            'id': str(uuid.uuid4()), 'symbol': symbol, 'event_id': event_id,
            'timestamp_ms': timestamp,
            'timestamp_utc': dt.isoformat(timespec='milliseconds').replace('+00:00', 'Z'),
            'timestamp_cst': dt.astimezone(CST).isoformat(timespec='milliseconds'),
            'market': market, 'interval': interval,
            'label': 'best_buy', 'source': 'manual', 'time_basis': 'cursor',
            'created_at': datetime.now(UTC).isoformat(timespec='seconds').replace('+00:00', 'Z')
        }
        with self.label_lock:
            doc = self.read_labels()
            old = next((x for x in doc['annotations'] if x['symbol'] == symbol and str(x['event_id']) == event_id and x['timestamp_ms'] == timestamp), None)
            if old:
                return old
            doc['annotations'].append(label)
            atomic_json(self.labels_path, doc)
        return label

    def delete_label(self, label_id):
        with self.label_lock:
            doc = self.read_labels()
            keep = [x for x in doc['annotations'] if x['id'] != label_id]
            if len(keep) == len(doc['annotations']):
                raise KeyError('标注不存在')
            doc['annotations'] = keep
            atomic_json(self.labels_path, doc)

    def oi_day(self, symbol, day):
        key = (symbol, day)
        with self.cache_lock:
            lock = self.day_locks.setdefault(key, threading.Lock())
        with lock:
            cache = self.root / '.cache' / 'oi' / symbol / (day+'.json')
            start = int(datetime.fromisoformat(day).replace(tzinfo=UTC).timestamp()*1000)
            end = start+DAY-1
            now = int(time.time()*1000)
            if start > now:
                return [], '未来日期无数据'
            if cache.exists():
                try:
                    doc = json.loads(cache.read_text())
                    points = normalize_points(doc['points'])
                    complete = end < now and full_coverage(points, start, end)
                    if complete or time.time()-doc['saved_at'] < 300:
                        return points, doc.get('warning', '')
                except (ValueError, KeyError, TypeError):
                    pass
            points = []
            warnings = []
            url = f'https://data.binance.vision/data/futures/um/daily/metrics/{symbol}/{symbol}-metrics-{day}.zip'
            try:
                points = read_archive(fetch_bytes(url), symbol)
            except HTTPError as exc:
                warnings.append('历史备份未发布' if exc.code == 404 else f'历史备份HTTP {exc.code}')
            except Exception as exc:
                warnings.append('历史备份读取失败：'+str(exc)[:140])
            # The REST endpoint only retains roughly one month. Archives cover older dates.
            if not full_coverage(points, start, min(end, now)) and end >= now-29*DAY:
                cursor = max(start, now-29*DAY)
                try:
                    while cursor <= min(end, now):
                        q = urlencode(dict(symbol=symbol, period='5m', startTime=cursor, endTime=min(end, now), limit=500))
                        rows = json.loads(fetch_bytes('https://fapi.binance.com/futures/data/openInterestHist?'+q))
                        if not isinstance(rows, list):
                            raise ValueError('OI接口返回异常')
                        if not rows:
                            break
                        points.extend([int(x['timestamp']), float(x['sumOpenInterestValue']), float(x['sumOpenInterest'])] for x in rows)
                        nxt = int(rows[-1]['timestamp'])+1
                        if nxt <= cursor:
                            raise ValueError('OI分页时间未前进')
                        cursor = nxt
                        if len(rows) < 500:
                            break
                except Exception as exc:
                    warnings.append('近期OI接口失败：'+str(exc)[:140])
            points = [p for p in normalize_points(points) if start <= p[0] <= end]
            warning = '' if full_coverage(points, start, min(end, now)) else '；'.join(warnings) or '该日部分采样缺失'
            if points:
                atomic_json(cache, dict(points=points, saved_at=time.time(), warning=warning))
            return points, warning

    def oi(self, symbol, start, end):
        if not SYMBOL.fullmatch(symbol) or not 0 <= start < end or end-start > 32*DAY:
            raise ValueError('OI参数无效：窗口最多32天')
        dates = [datetime.fromtimestamp(t/1000, UTC).date().isoformat() for t in range(start//DAY*DAY, end//DAY*DAY+1, DAY)]
        points, warnings = [], []
        with ThreadPoolExecutor(max_workers=3) as pool:
            for day, result in zip(dates, pool.map(lambda d: self.oi_day(symbol, d), dates)):
                pts, warning = result
                points.extend(pts)
                if warning:
                    warnings.append(day+'：'+warning)
        points = [p for p in normalize_points(points) if start <= p[0] <= end]
        return dict(points=points, period_ms=STEP, start=start, end=end,
                    complete=full_coverage(points, start, end), warnings=warnings,
                    source='币安历史备份 / 近期OI接口')


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, store, **kwargs):
        self.store = store
        super().__init__(*args, directory=str(store.root), **kwargs)

    def json_response(self, status, doc):
        body = json.dumps(doc, ensure_ascii=False, allow_nan=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def local_request(self):
        host = self.headers.get('Host', '')
        allowed = {f'localhost:{self.server.server_port}', f'127.0.0.1:{self.server.server_port}'}
        origin = self.headers.get('Origin')
        return host in allowed and (origin is None or origin in {'http://'+h for h in allowed})

    def api(self):
        if not self.local_request():
            self.json_response(403, {'error': '仅允许从本地面板访问'})
            return
        path = urlsplit(self.path).path
        try:
            if self.command == 'GET' and path == '/api/annotations':
                return self.json_response(200, self.store.labels())
            if self.command == 'GET' and path == '/api/oi':
                q = parse_qs(urlsplit(self.path).query)
                return self.json_response(200, self.store.oi(q['symbol'][0], int(q['start'][0]), int(q['end'][0])))
            if self.command == 'POST' and path == '/api/annotations':
                length = int(self.headers.get('Content-Length', 0))
                if not 0 < length <= 8192 or self.headers.get_content_type() != 'application/json':
                    raise ValueError('需要有效的JSON请求')
                data = json.loads(self.rfile.read(length))
                return self.json_response(201, self.store.add_label(data))
            if self.command == 'DELETE' and re.fullmatch(r'/api/annotations/[a-f0-9-]{36}', path):
                self.store.delete_label(path.rsplit('/', 1)[1])
                return self.json_response(200, {'ok': True})
            self.json_response(404, {'error': '接口不存在'})
        except KeyError as exc:
            self.json_response(400, {'error': str(exc)})
        except (ValueError, TypeError, OverflowError) as exc:
            self.json_response(400, {'error': str(exc)})
        except Exception as exc:
            self.json_response(500, {'error': '操作失败：'+str(exc)[:200]})

    def do_GET(self):
        if urlsplit(self.path).path.startswith('/api/'):
            return self.api()
        # The service is local; do not expose repository metadata or cached downloads.
        parts = Path(urlsplit(self.path).path).parts
        if any(p.startswith('.') for p in parts if p != '/'):
            return self.send_error(404)
        return super().do_GET()

    def do_POST(self):
        self.api()

    def do_DELETE(self):
        self.api()


def make_server(root, port):
    return ThreadingHTTPServer(('127.0.0.1', port), partial(Handler, store=Store(root)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--open', action='store_true')
    args = parser.parse_args()
    try:
        server = make_server(Path(__file__).resolve().parent, args.port)
    except OSError as exc:
        raise SystemExit(f'启动失败：{exc}。请先关闭旧的服务窗口，再重新运行 start.command。')
    url = f'http://localhost:{server.server_port}'
    print('暴拉事件观察台 → '+url+'（关闭此窗口即停止服务）', flush=True)
    if args.open:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
