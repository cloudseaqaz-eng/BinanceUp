"""Causal observation curves; heuristic states are not fitted probabilities."""
import numpy as np
import pandas as pd

WARMUP = 180
LOOKBACK_MINUTES = 1561
KINDS = ("trade", "buy", "wick")


def metrics(raw):
    raw = raw.sort_index().reindex(pd.date_range(raw.index.min(), raw.index.max(), freq="min", name="time"))
    events = {}
    for kind, column in (("trade", "trades"), ("buy", "taker_quote")):
        v = raw[column]
        events[kind] = v.gt(0).astype(float).where(np.isfinite(v) & v.ge(0))
    prices = raw[["open", "high", "low", "close"]]
    valid = np.isfinite(prices).all(axis=1) & prices.gt(0).all(axis=1)
    valid &= raw.high.ge(prices[["open", "close"]].max(axis=1))
    valid &= raw.low.le(prices[["open", "close"]].min(axis=1))
    events["wick"] = raw.high.gt(prices[["open", "close"]].max(axis=1)).astype(float).where(valid)
    result = pd.DataFrame(index=raw.index)
    for kind, event in events.items():
        prefix = "activation_"+kind+"_"
        # Restart on gaps; never interpolate or bridge unknown minute events.
        segments = event.isna().cumsum()
        for name, half in (("fast", 5), ("slow", 30)):
            result[prefix+name] = event.groupby(segments).transform(
                lambda s: s.ewm(halflife=half, adjust=False, min_periods=WARMUP).mean()).where(event.notna())
        base = event.shift(30).rolling(1440, min_periods=1440).mean()
        result[prefix+"base"] = base
        fast, slow = result[prefix+"fast"], result[prefix+"slow"]
        delta = fast-base
        result[prefix+"delta"] = delta
        threshold, floor = (.10, .15) if kind == "wick" else (.15, .30)
        ready = fast.notna() & slow.notna() & base.notna()
        candidate = ready & delta.ge(threshold) & fast.ge(floor)
        persistent = candidate.astype(float).rolling(5, min_periods=5).sum().ge(3) & slow.gt(base)
        states, runs = [], []
        state = run = weak = 0
        for ok, hit, confirm, d in zip(ready, candidate, persistent, delta):
            if not ok:
                state = run = weak = 0
                states.append(np.nan)
                runs.append(np.nan)
                continue
            run = run+1 if hit else 0
            weak = weak+1 if d < threshold/2 else 0
            if state == 2:
                if weak >= 5:
                    state = 0
            elif confirm:
                state = 2
            else:
                state = 1 if hit else 0
            states.append(state)
            runs.append(run)
        result[prefix+"state"] = states
        result[prefix+"run"] = runs
    return result
