"""Read-only local dashboard. No external CDN, order API, or annotation-to-target leakage."""
from functools import lru_cache
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
import json
import math
import mimetypes
import numpy as np
import pandas as pd
from .config import COMPONENTS, COMPONENT_LABELS, PDF_WEIGHTS, utc
from .data import read_raw
from .scoring import load_panel, parquet_slice, scores
from .train import choose_model, probabilities, feature_revision
from .activity import activity_at, continuity, buy_continuity, CONTEXT_NOTE
from .oi import diagnose_oi, contract
from . import uw

WEB = Path(__file__).with_name("web")


def oi_status(cfg, symbol, at, zoi=None):
    path = cfg.path/"raw"/f"{symbol}.oi.parquet"
    oi = parquet_slice(path, end=at) if path.exists() else None
    result = diagnose_oi(oi, at, cfg.oi_mode, zoi)
    # Synthetic features are intentionally not derived from exchange archives.
    if cfg.universe_scope == "synthetic_demo" and zoi is not None and np.isfinite(zoi):
        result = {"code": "synthetic", "label": "模拟OI", "message": "合成演示OI，非交易所实测数据。"}
    source, multiplier = contract(symbol)
    if source != symbol:
        result["message"] += f" 对应映射{source}；新版下载器将持仓数量乘{multiplier}换算为现货币数量。旧实验需重复download补充映射数据。"
    return result


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, np.ndarray)):
        return [clean(v) for v in value]
    if isinstance(value, (pd.Timestamp,)):
        return value.isoformat()
    if isinstance(value, np.generic):
        return clean(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if value is pd.NaT or value is pd.NA:
        return None
    return value


def snapshot(cfg, at):
    if (cfg.path/"features/.building").exists():
        raise ValueError("指标重建未完成；请完成features后再打开面板，避免混用不同版本。")
    at = utc(at).floor("min")
    if at < utc(cfg.start) or at > utc(cfg.end):
        raise ValueError("时间必须在实验起止范围内")
    frame = load_panel(cfg, at, at, step=1)
    model = choose_model(cfg, at)
    model_message = None
    model_path = cfg.path/"results/models.json"
    if model is None and model_path.exists():
        models = json.loads(model_path.read_text())
        if any(m.get("feature_revision", "legacy") != feature_revision(cfg) for m in models):
            model_message = "指标已重建，旧权重/概率不再匹配；当前显示PDF默认分，概率留空。请重新运行labels、train。"
    frame["score"] = scores(frame, model["weights"] if model else PDF_WEIGHTS)
    frame["probability"] = probabilities(frame, model["calibration"]) if model else np.nan
    frame["selected"] = False
    selection = frame.loc[frame.eligible & (frame.score >= cfg.min_score)].sort_values(["score", "symbol"], ascending=[False, True]).head(cfg.top_k)
    frame.loc[selection.index, "selected"] = True
    frame = frame.sort_values(["eligible", "score", "symbol"], ascending=[False, False, True])
    rows = []
    for row in frame.to_dict("records"):
        reasons = []
        if not row["feature_ready"]:
            reasons.append("特征预热不足/缺失")
        if not row["history_complete"]:
            reasons.append("前24h分钟缺口")
        if row["q1440"] < cfg.min_quote24:
            reasons.append("24h成交额不足")
        if row["rank24"] <= cfg.top_n:
            reasons.append("当前已在前10")
        if not row["board_valid"]:
            reasons.append("榜单覆盖不全")
        if row["late"]:
            reasons.append("已启动/晚期否决")
        if row["wash"]:
            reasons.append("WASH否决")
        if not row["valid"]:
            reasons.append("近5m有效样本不足")
        if row["risk_off"]:
            reasons.append("市场风险状态否决")
        if row["zero1440"] > .05:
            reasons.append("零成交分钟过多")
        if row["age_days_lower_bound"] < 7:
            reasons.append("可证实上市历史不足7天")
        row["reasons"] = reasons
        row.update(activity_at(cfg, row["symbol"], at))
        row["oi_status"] = oi_status(cfg, row["symbol"], at, row.get("zoi15"))
        rows.append(row)
    return clean({"at": at, "model": model, "weights": model["weights"] if model else PDF_WEIGHTS, "rows": rows,
                  "model_message": model_message,
                  "universe_scope": cfg.universe_scope, "oi_mode": cfg.oi_mode,
                  "components": COMPONENTS, "component_labels": COMPONENT_LABELS,
                  "board_coverage": float(frame.board_coverage.iloc[0]) if len(frame) else 0,
                  "context_note": CONTEXT_NOTE,
                  "note": "概率仅来自当时已完成训练/校准的模型；空值表示尚无模型或校准样本不足。未来标签仅供事后观察。"})


def detail(cfg, symbol, at, before=48, after=0, period=5):
    if symbol not in cfg.symbols:
        raise ValueError("不在实验交易对清单中")
    if before not in (6, 24, 48, 72, 168, 336) or after not in (0, 24, 48, 72, 168) or period not in (1, 3, 5, 15, 60):
        raise ValueError("不支持的图表窗口/周期")
    at = utc(at).floor("min")
    if at < utc(cfg.start) or at > utc(cfg.end):
        raise ValueError("时间超出实验范围")
    start, end = at-pd.Timedelta(hours=before), min(at+pd.Timedelta(hours=after), utc(cfg.end))
    path = cfg.path / "features" / f"{symbol}.parquet"
    f = parquet_slice(path, start, end)
    # Raw bars are authoritative for OHLC even for the separate synthetic demonstration.
    raw_path = cfg.path / "raw" / f"{symbol}.parquet"
    history_start = start-pd.Timedelta(minutes=max(59, uw.LOOKBACK_MINUTES))
    extended = parquet_slice(raw_path, history_start, end)
    extended = extended.reindex(pd.date_range(history_start, end, freq="min", name="time"))
    trade_continuity = continuity(extended).loc[start:end].join(buy_continuity(extended).loc[start:end])
    upper_wick = uw.metrics(extended)
    raw = extended.loc[start:end]
    groups = raw.resample(f"{period}min", closed="right", label="right")
    candles = groups.agg({"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum", "quote": "sum", "trades": "sum", "taker_quote": "sum"})
    candles.loc[groups.close.count() != period] = np.nan
    candles = candles.loc[candles.index <= end]
    columns = [c for c in f.columns if c not in candles.columns and pd.api.types.is_numeric_dtype(f[c])]
    # last() normally skips NaNs and hides gaps: use the actual end-of-bucket row instead.
    indicators = f[columns].reindex(candles.index)
    market = parquet_slice(cfg.path / "market.parquet", start, end).reindex(candles.index)
    labels = parquet_slice(cfg.path / "labels" / f"{symbol}.parquet", start, end).reindex(candles.index)
    combined = candles.join(indicators).join(market).join(labels)
    combined = combined.join(trade_continuity.reindex(combined.index))
    combined = combined.join(upper_wick.reindex(combined.index))
    combined["ms"] = combined.index.asi8 // 10**6
    summary = snapshot(cfg, at)
    row = next((r for r in summary["rows"] if r["symbol"] == symbol), None)
    return clean({"symbol": symbol, "at": at, "start": start, "end": end, "period": period,
                  "candles": combined.reset_index(drop=True).to_dict("records"), "snapshot": row,
                  "weights": summary["weights"], "model": summary["model"], "universe_scope": cfg.universe_scope,
                  "model_message": summary["model_message"],
                  "oi_status": oi_status(cfg, symbol, at, row.get("zoi15") if row else None),
                  "context_note": CONTEXT_NOTE,
                  "uw_series": upper_wick.loc[start:end].assign(ms=lambda x: x.index.asi8//10**6).reset_index(drop=True).to_dict("records"),
                  # Empty compatibility fields let an older cached UI show the
                  # pressure plot without resurrecting removed change markers.
                  "uw_events": [], "uw_regions": [],
                  "uw_current": upper_wick.loc[at].to_dict(), "uw_note": uw.NOTE,
                  "component_labels": COMPONENT_LABELS, "components": COMPONENTS,
                  "note": "曲线为各已收盘时点的原始指标；3/15/60分钟仅改变展示采样，不改变慢层公式。OI缺口不插值。"})


def handler(cfg):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            url = urlparse(self.path)
            query = parse_qs(url.query)
            arg = lambda key, default=None: query.get(key, [default])[0]
            try:
                if url.path == "/api/status":
                    report_path = cfg.path / "results" / "report.json"
                    info = {"start": cfg.start, "end": cfg.end, "symbols": len(cfg.symbols), "universe_scope": cfg.universe_scope,
                            "oi_mode": cfg.oi_mode, "sample_minutes": cfg.sample_minutes, "ready": (cfg.path/"market.parquet").exists(),
                            "report_ready": report_path.exists(), "default_at": (utc(cfg.end)-pd.Timedelta(days=2)).isoformat()}
                    return self.send_json(info)
                if url.path == "/api/snapshot":
                    return self.send_json(snapshot(cfg, arg("at")))
                if url.path == "/api/detail":
                    return self.send_json(detail(cfg, arg("symbol"), arg("at"), int(arg("before", 48)), int(arg("after", 0)), int(arg("period", 5))))
                if url.path == "/api/report":
                    path = cfg.path / "results" / "report.json"
                    if not path.exists():
                        return self.send_json({"status": "not_trained", "message": "尚未完成权重训练；可以先浏览PDF默认评分。"})
                    report = json.loads(path.read_text())
                    final_model = report.get("final_holdout", {}).get("model", {})
                    if final_model.get("feature_revision", "legacy") != feature_revision(cfg):
                        return self.send_json({"status": "stale", "message": "指标已重建，旧报告不再匹配；请完成labels、train后查看新报告。"})
                    return self.send_json(report)
                if url.path == "/favicon.ico":
                    self.send_response(204)
                    self.end_headers()
                    return
                # Strict allowlist prevents accidental exposure of data archives and local files.
                names = {"/": "index.html", "/index.html": "index.html", "/detail.html": "detail.html", "/report.html": "report.html",
                         "/app.css": "app.css", "/common.js": "common.js", "/list.js": "list.js", "/detail.js": "detail.js", "/report.js": "report.js"}
                if url.path not in names:
                    self.send_error(404)
                    return
                p = WEB/names[url.path]
                payload = p.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", (mimetypes.guess_type(str(p))[0] or "application/octet-stream")+"; charset=utf-8")
                self.send_header("Content-Length", str(len(payload)))
                self.send_header("Cache-Control", "no-store, max-age=0")
                self.end_headers()
                self.wfile.write(payload)
            except (ValueError, KeyError, TypeError) as e:
                self.send_json({"error": str(e)}, 400)
            except FileNotFoundError:
                self.send_json({"error": "所需数据尚未生成；请先执行 download、features、labels。"}, 404)
            except Exception as e:
                self.log_error("%s", str(e))
                self.send_json({"error": "计算失败："+str(e)}, 500)

        def send_json(self, value, status=200):
            body = json.dumps(clean(value), ensure_ascii=False, allow_nan=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

    return Handler


def serve(cfg, port=8767):
    server = ThreadingHTTPServer(("127.0.0.1", port), handler(cfg))
    print(f"回测面板 http://127.0.0.1:{port}   数据：{cfg.path}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
