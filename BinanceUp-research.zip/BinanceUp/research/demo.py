"""Isolated synthetic UI/pipeline demonstration, never a Binance backtest result."""
from pathlib import Path
import numpy as np
import pandas as pd
from .config import Config, COMPONENTS, json_write, utc
from .labels import build_labels
from .storage import write_frame


def make_demo(root, days=150):
    path = Path(root).resolve()
    if (path/"config.json").exists():
        raise ValueError("演示目录已存在；请指定一个新的 --root")
    end = pd.Timestamp("2026-10-21", tz="UTC")
    symbols = ["BTCUSDT"]+[f"DEMO{i:02d}USDT" for i in range(23)]
    cfg = Config(start=(end-pd.Timedelta(days=days)).isoformat(), end=end.isoformat(), root=str(path),
                 symbols=symbols, universe_scope="synthetic_demo", sample_minutes=5, trials=24, oi_mode="available")
    cfg.save()
    for folder in ("raw", "features"):
        (path/folder).mkdir(exist_ok=True)
    ix = pd.date_range(cfg.warm_start+pd.Timedelta(minutes=1), end, freq="min", name="time")
    rng = np.random.default_rng(cfg.seed)
    market_return = rng.normal(0, .00025, len(ix))
    for j, symbol in enumerate(symbols):
        returns = market_return+rng.normal(0, .0007, len(ix))
        # Random multi-hour movements, not actual event examples.
        for i in rng.integers(1440, len(ix)-360, size=days//2):
            returns[i:i+180] += rng.uniform(-.0006, .0008)
        close = (60000 if j == 0 else j+1)*np.exp(np.cumsum(returns))
        op = np.r_[close[0], close[:-1]]
        quote = rng.lognormal(11.6, .65, len(ix))
        buy = np.clip(.5+returns*100+rng.normal(0,.05,len(ix)), .1, .9)
        raw = pd.DataFrame({"open": op, "high": np.maximum(op,close)*1.0004, "low": np.minimum(op,close)*.9996,
                            "close": close, "volume": quote/close, "quote": quote, "trades": (quote/120).astype(int), "taker_quote": quote*buy}, index=ix)
        write_frame(raw, path/"raw"/(symbol+".parquet"))
        f = raw.copy()
        for w in (5, 15, 60, 1440):
            f[f"r{w}"] = f.close/f.close.shift(w)-1
        signal = pd.Series(rng.uniform(size=len(ix)), index=ix).rolling(180, min_periods=1).mean()
        signal = ((signal-.5)*15+.5).clip(0, 1)
        for k, col in enumerate(COMPONENTS):
            noise = pd.Series(rng.uniform(size=len(ix)), index=ix).rolling(90, min_periods=1).mean()
            f[col] = (.6*signal+.4*((noise-.5)*14+.5).clip(0,1)).clip(0,1)
        if j % 3 == 0:
            f["oi_build"] = np.nan
        f["oi_available"] = f.oi_build.notna()
        f["oi"] = np.where(f.oi_available, 1e6*np.exp(np.cumsum(returns*.2)), np.nan)
        f["oi_usdt"] = f.oi*f.close
        f["doi15"] = f.oi/f.oi.shift(15)-1
        f["zoi15"] = f.oi_build*3
        f["rvol15"], f["tcr15"], f["rvol5"] = 1+2*f.preheat, 1+2*f.trade_count, 1+3*f.preheat
        f["q1440"] = f.quote.rolling(1440).sum()
        for w in (5, 15, 30):
            f[f"tbr{w}"] = f.taker_quote.rolling(w).sum()/f.quote.rolling(w).sum()
        f["div"] = f.cvd_divergence*3-1
        f["cvd"] = (2*f.taker_quote-f.quote).rolling(240).sum()
        f["nfn5"] = f.cvd/f.q1440*20
        f["bbw_pct"] = 1-f.compression
        f["bo1h"] = f.proximity*4-3
        f["bo4h"] = f.bo1h-1
        f["zres30"] = f.relative_strength*3
        f["zr5"] = f.r5/.003
        f["zr15"] = f.r15/.006
        f["sigma"] = pd.Series(returns, index=ix).rolling(180).std()
        f["squeeze"] = (f.bbw_pct < .2).astype(float)
        f["uw3"], f["er10"], f["pos4h"] = .2, .3, f.proximity
        f["dd24"] = f.close/f.low.rolling(1440).min()-1
        f["vwap_dev"] = f.close/(f.quote.rolling(1440).sum()/f.volume.rolling(1440).sum())-1
        f["funding8h"], f["zf"] = np.nan, np.nan
        f["zero1440"] = 0.
        f["age_days_lower_bound"] = np.arange(len(ix))/1440
        f["feature_ready"] = f.age_days_lower_bound >= 22
        f["history_complete"] = f.age_days_lower_bound >= 1
        f["valid"], f["wash"] = True, False
        f["late"] = (f.r60 > .08) | (f.zr5 > 3.5)
        f["penalty"] = (~f.late).astype(float)
        for c in f.select_dtypes(include=["float64"]).columns:
            f[c] = f[c].astype("float32")
        write_frame(f, path/"features"/(symbol+".parquet"), raw_source=path/"raw"/(symbol+".parquet"))
        print("DEMO", symbol, flush=True)
    json_write(path/"DEMO_ONLY.json", {"warning": "全部行情和评分分项均为合成，仅验证软件流程与页面，不能用于任何真实概率或权重结论。"})
    build_labels(cfg)
    print("演示已生成：", path, flush=True)
    return cfg
