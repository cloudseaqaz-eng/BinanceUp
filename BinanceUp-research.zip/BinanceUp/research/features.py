"""Causal features from closed bars. No targets are read in this module."""
import numpy as np
import pandas as pd
from uuid import uuid4
from .config import COMPONENTS, utc, json_write
from .data import read_raw
from .storage import write_frame
from .oi import native_oi

EPS = 1e-12


def ramp(x, a, b):
    return np.clip((x-a)/(b-a), 0, 1)


def past_percentile(s, window, min_periods=None):
    """Fraction of strictly past values <= current (current excluded from denominator)."""
    min_periods = window if min_periods is None else min_periods
    r = s.rolling(window+1, min_periods=min_periods+1)
    return (r.rank(method="max")-1) / (r.count()-1)


def frozen_robust_z(s, window=10080, refresh=60, minimum=.95):
    """Past-window median/MAD, refreshed hourly; current sample NEVER enters its baseline.

    This explicit hourly refresh is the computational approximation to the PDF's
    per-minute robust baseline. All underlying minutes, not hourly subsamples, are used.
    """
    a = s.to_numpy(dtype=float)
    med, scale = np.full(len(a), np.nan), np.full(len(a), np.nan)
    anchors = np.flatnonzero((s.index.asi8 // (60 * 10**9)) % refresh == 0)
    for i in anchors:
        if i < window:
            continue
        past = a[i-window:i]
        past = past[np.isfinite(past)]
        if len(past) < int(window*minimum):
            continue
        m = np.median(past)
        mad = np.median(np.abs(past-m)) * 1.4826
        med[i:i+refresh] = m
        scale[i:i+refresh] = max(mad, EPS)
    return pd.Series(np.clip((a-med)/scale, -4, 4), index=s.index)


def seasonal(s):
    """14 prior UTC days, minute-of-day median, circular +/-10 minute smoothing."""
    days = pd.date_range(s.index.min().floor("D"), s.index.max().floor("D"), freq="D")
    daily = s.reindex(pd.date_range(days[0], days[-1]+pd.Timedelta(days=1), freq="min", inclusive="left")).to_numpy().reshape(-1, 1440)
    output = np.full_like(daily, np.nan)
    for d in range(14, len(days)):
        past = daily[d-14:d]
        counts = np.isfinite(past).sum(axis=0)
        # Avoid all-NaN warnings while preserving gaps as unknown.
        good = counts >= 12
        profile = np.full(1440, np.nan)
        if good.any():
            profile[good] = np.nanmedian(past[:, good], axis=0)
        smooth = np.stack([np.roll(profile, k) for k in range(-10, 11)])
        output[d] = np.mean(smooth, axis=0)
    full = pd.Series(output.ravel(), index=pd.date_range(days[0], periods=output.size, freq="min"))
    profile = full.reindex(s.index)
    numerator = s.shift(60).rolling(1380, min_periods=1380).sum()
    denominator = profile.shift(60).rolling(1380, min_periods=1380).sum()
    level = (numerator/denominator.clip(lower=EPS)).clip(.5, 2)
    return profile, level


def slope(s, n=30):
    x = np.arange(n, dtype=float)
    x -= x.mean()
    values = s.to_numpy(dtype=float)
    clean = np.nan_to_num(values)
    # correlation at t uses [t-n+1,t], oldest gets the negative coefficient.
    result = np.convolve(clean, x[::-1], mode="full")[:len(values)] / np.dot(x, x)
    valid = s.rolling(n).count().to_numpy() == n
    result[~valid] = np.nan
    return pd.Series(result, index=s.index)


def bars5(raw):
    r = raw.resample("5min", closed="right", label="right")
    five = r.agg({"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum", "quote": "sum", "trades": "sum", "taker_quote": "sum"})
    five.loc[r.close.count() != 5, :] = np.nan
    return five.loc[five.index <= raw.index.max()]


def huber_beta(asset5, btc5):
    """3 days of 5m returns; Huber IRLS at each hour, 8 iterations, past only."""
    y = np.log(asset5).diff().to_numpy()
    x = np.log(btc5.reindex(asset5.index)).diff().to_numpy()
    result = np.full((len(x), 3), np.nan)
    anchors = np.flatnonzero(asset5.index.minute == 0)
    window = 864
    for begin in range(0, len(anchors), 128):
        aa = anchors[begin:begin+128]
        aa = aa[aa >= window]
        if not len(aa):
            continue
        ix = aa[:, None] - window + np.arange(window)
        xx, yy = x[ix], y[ix]
        valid = np.isfinite(xx) & np.isfinite(yy)
        enough = valid.sum(axis=1) >= int(.98*window)
        xx, yy = np.nan_to_num(xx), np.nan_to_num(yy)
        w = valid.astype(float)
        for _ in range(8):
            total = w.sum(axis=1).clip(min=1)
            mx, my = (w*xx).sum(axis=1)/total, (w*yy).sum(axis=1)/total
            xc, yc = xx-mx[:, None], yy-my[:, None]
            beta = (w*xc*yc).sum(axis=1)/(w*xc*xc).sum(axis=1).clip(min=EPS)
            alpha = my-beta*mx
            residual = yy-alpha[:, None]-beta[:, None]*xx
            # Most windows have full coverage. Invalid entries get zero weight.
            scale = np.median(np.abs(residual-np.median(residual, axis=1)[:, None]), axis=1)*1.4826
            w = valid * np.minimum(1, 1.345*scale[:, None].clip(min=EPS)/np.abs(residual).clip(min=EPS))
        sd = np.sqrt((valid*residual**2).sum(axis=1)/valid.sum(axis=1).clip(min=1))
        values = np.stack([alpha, beta, sd], axis=1)
        values[~enough] = np.nan
        for a, value in zip(aa, values):
            result[a:a+12] = value
    return pd.DataFrame(result, index=asset5.index, columns=["alpha", "beta", "residual_sigma"])


def make_features(raw, btc, oi=None, funding=None, oi_mode="available"):
    f = raw.copy()
    close = raw.close
    logc = np.log(close)
    f["observed"] = raw.notna().all(axis=1)
    sigma = np.sqrt(logc.diff().pow(2).ewm(halflife=180, min_periods=1440, ignore_na=False).mean()).clip(lower=1e-8)
    f["sigma"] = sigma
    profile_q, level_q = seasonal(raw.quote)
    profile_n, level_n = seasonal(raw.trades)
    for w in (1, 5, 15, 30, 60, 240, 1440):
        q, n, qb = (raw[c].rolling(w, min_periods=w).sum() for c in ("quote", "trades", "taker_quote"))
        rw = logc-logc.shift(w)
        f[f"r{w}"] = np.expm1(rw)
        f[f"zr{w}"] = rw/(sigma.shift(w)*np.sqrt(w))
        f[f"q{w}"] = q
        if w in (1, 5, 15, 30, 60):
            f[f"n{w}"] = n
            bq = level_q*profile_q.rolling(w, min_periods=w).sum()
            bn = level_n*profile_n.rolling(w, min_periods=w).sum()
            f[f"rvol{w}"] = q/bq.clip(lower=EPS)
            f[f"tcr{w}"] = n/bn.clip(lower=EPS)
            f[f"tbr{w}"] = qb/q.replace(0, np.nan)
            f[f"nfn{w}"] = (2*qb-q)/bq.clip(lower=EPS)
    f["fresh"] = f.rvol5/f.rvol60.clip(lower=1)
    f["ats5"] = f.q5/f.n5.clip(lower=1)
    f["tbr_slope"] = f.tbr5-f.tbr30
    f["net_flow"] = 2*raw.taker_quote-raw.quote
    f["cvd"] = f.net_flow.rolling(240).sum()
    f["cvd_norm"] = f.cvd/f.q60.replace(0, np.nan)
    f["div"] = frozen_robust_z(slope(f.cvd_norm))-frozen_robust_z(slope(logc))
    f["er10"] = close.diff(10).abs()/close.diff().abs().rolling(10).sum().replace(0, np.nan)
    uw = (raw.high-raw[["open", "close"]].max(axis=1))/(raw.high-raw.low).replace(0, np.nan)
    f["uw3"] = uw.fillna(0).rolling(3).mean().where(f.observed.rolling(3).sum() == 3)
    f["zero15"] = raw.trades.eq(0).rolling(15).sum().where(raw.trades.rolling(15).count() == 15)
    f["zero1440"] = raw.trades.eq(0).rolling(1440).mean().where(raw.trades.rolling(1440).count() == 1440)
    f["vwap24"] = f.q1440/raw.volume.rolling(1440).sum().replace(0, np.nan)
    f["vwap_dev"] = close/f.vwap24-1
    f["dd24"] = close/raw.low.rolling(1440).min()-1
    hl2 = np.log(raw.high/raw.low).pow(2)
    f["vcr"] = np.sqrt(hl2.rolling(60).mean()/hl2.rolling(1440).mean().replace(0, np.nan))
    five, btc5 = bars5(raw), bars5(btc)
    c = five.close
    mean, sd = c.rolling(20).mean(), c.rolling(20).std(ddof=0)
    bb = 4*sd/mean
    tr = pd.concat([five.high-five.low, (five.high-c.shift()).abs(), (five.low-c.shift()).abs()], axis=1).max(axis=1)
    tr = tr.where(five.close.notna() & c.shift().notna())
    atr = tr.ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    indicators = pd.DataFrame({"bbw": bb, "bbw_pct": past_percentile(bb, 2016), "atr5": atr})
    for w, name in ((12, "bo1h"), (48, "bo4h"), (288, "bo24h")):
        indicators[name] = (c-five.high.shift(1).rolling(w).max())/atr.clip(lower=EPS)
    hh, ll = five.high.shift().rolling(48).max(), five.low.shift().rolling(48).min()
    indicators["range4h"] = (hh-ll)/c
    indicators["pos4h"] = (c-ll)/(hh-ll).replace(0, np.nan)
    ema = c.ewm(span=20, min_periods=20, adjust=False).mean()
    atr20 = tr.ewm(alpha=1/20, min_periods=20, adjust=False).mean()
    sq = ((mean+2*sd < ema+1.5*atr20) & (mean-2*sd > ema-1.5*atr20)).astype(float).where(bb.notna())
    indicators["squeeze"] = sq
    indicators["sq_length"] = sq.groupby(sq.ne(sq.shift()).cumsum()).cumsum()
    indicators["sq_release"] = (sq.shift().eq(1) & sq.eq(0)).astype(float).where(sq.notna())
    relative = huber_beta(c, btc5.close)
    indicators = indicators.join(relative)
    # Match PDF R1: residual return subtracts beta*BTC, not alpha.
    ri30, rb30 = np.log(c).diff(6), np.log(btc5.close.reindex(c.index)).diff(6)
    indicators["zres30"] = (ri30-relative.beta*rb30)/(relative.residual_sigma.clip(lower=EPS)*np.sqrt(6))
    indicators = indicators.reindex(f.index, method="ffill", tolerance=pd.Timedelta(minutes=4))
    f = pd.concat([f, indicators], axis=1)
    f["oi"], f["oi_usdt"], f["doi15"], f["zoi15"] = np.nan, np.nan, np.nan, np.nan
    if oi_mode != "off" and oi is not None and len(oi):
        # Evaluate changes at native 5m samples, not on stale forward-filled 1m points.
        native = native_oi(oi)
        # Native-window refresh=1 means every 5m sample; 7 days, excluding current.
        native["zoi15"] = frozen_robust_z(native.doi15, window=2016, refresh=1)
        aligned = native.reindex(f.index, method="ffill", tolerance=pd.Timedelta(minutes=4))
        for col in ("oi", "oi_usdt", "doi15", "zoi15"):
            f[col] = aligned[col]
    f["funding8h"], f["zf"] = np.nan, np.nan
    if funding is not None and len(funding):
        # Funding events vary in interval. Use actual previous 30d events, not 1m duplicates.
        funding = funding.copy().sort_index()
        z = []
        for t, value in funding.funding8h.items():
            past = funding.loc[(funding.index >= t-pd.Timedelta(days=30)) & (funding.index < t), "funding8h"].dropna()
            z.append(np.clip((value-past.median())/max(1.4826*(past-past.median()).abs().median(), EPS), -4, 4) if len(past) >= 60 else np.nan)
        funding["zf"] = z
        aligned = funding.reindex(f.index, method="ffill", tolerance=pd.Timedelta(hours=8))
        f[["funding8h", "zf"]] = aligned[["funding8h", "zf"]]
    still = 1-ramp(f.zr15.abs(), 1, 2)
    f[COMPONENTS[0]] = ramp(1-f.bbw_pct, .70, .95)
    f[COMPONENTS[1]] = ramp(f.bo1h, -3, -1)*(1-ramp(f.bo1h, .5, 2))
    f[COMPONENTS[2]] = ramp(f.rvol15, 1.3, 3)*still
    f[COMPONENTS[3]] = ramp(f.tcr15, 1.3, 3)
    f[COMPONENTS[4]] = .6*ramp(f.tbr15, .52, .62)+.4*ramp(f.tbr_slope, 0, .06)
    f[COMPONENTS[5]] = ramp(f.zres30, .5, 2.5)
    f[COMPONENTS[6]] = ramp(f.zoi15, 1, 3)*still
    f[COMPONENTS[7]] = ramp(f["div"], .5, 2)
    f["oi_available"] = f.oi_build.notna()
    f["valid"] = (f.n5 >= 60) & (f.q5 >= 20000) & (f.zero15 <= 2)
    efficiency = f.zr5.abs()/np.log(f.rvol5.clip(lower=EPS)).clip(lower=.3)
    f["wash"] = (f.rvol5 >= 5) & (efficiency < .4) & (f.er10 < .2) & f.tbr5.between(.45, .55)
    f["late"] = (f.r60 > .08) | (f.zr5 > 3.5)
    f["penalty"] = np.where(f.valid & ~f.wash & ~f.late, 1., 0.)
    f["penalty"] *= np.where(f.uw3 > .5, .6, 1.) * np.where(f.r1440 > .30, .5, 1.) * np.where(f.zf > 3, .7, 1.)
    f["feature_ready"] = f[[c for c in COMPONENTS if c != "oi_build"]].notna().all(axis=1)
    if oi_mode == "required":
        f["feature_ready"] &= f.oi_available
    # Listed age is a conservative LOWER bound from first observed archive bar.
    first = raw.close.first_valid_index()
    f["age_days_lower_bound"] = (f.index-first).total_seconds()/86400 if first is not None else np.nan
    # Require a complete trailing day: a missing minute invalidates all rolling gates.
    f["history_complete"] = f.observed.rolling(1440).sum().eq(1440)
    for col in f.select_dtypes(include=["float64"]).columns:
        f[col] = f[col].replace([np.inf, -np.inf], np.nan).astype("float32")
    return f


def build_features(cfg):
    btc = read_raw(cfg, "BTCUSDT")
    if btc.close.notna().sum() < 1440*4:
        raise ValueError("BTCUSDT 基准历史不足，先下载包含预热期的数据")
    directory = cfg.path / "features"
    directory.mkdir(exist_ok=True)
    marker = directory/".building"
    marker.write_text("指标正在重建；完成前不可混用旧模型。", encoding="utf-8")
    rows = []
    for symbol in sorted(set(cfg.symbols) | {"BTCUSDT"}):
        raw = read_raw(cfg, symbol)
        if raw.empty or raw.close.notna().sum() < 1440*8:
            print(symbol, "可用历史少于8天，跳过评分（仍保留在榜单数据中）", flush=True)
            continue
        optional = {}
        for name in ("oi", "funding"):
            p = cfg.path / "raw" / f"{symbol}.{name}.parquet"
            optional[name] = pd.read_parquet(p) if p.exists() else None
        f = make_features(raw, btc, **optional, oi_mode=cfg.oi_mode)
        # Retain warmup for charts and pool state; float32/zstd keeps full-minute history affordable.
        write_frame(f, directory / f"{symbol}.parquet", raw_source=cfg.path/"raw"/f"{symbol}.parquet")
        result = {"symbol": symbol, "rows": len(f), "ready": int(f.feature_ready.sum()), "oi_available": int(f.oi_available.sum())}
        rows.append(result)
        print("features", result, flush=True)
    json_write(cfg.path / "feature_summary.json", rows)
    json_write(directory/"build_info.json", {"version": 2, "revision": uuid4().hex,
               "completed_at": pd.Timestamp.now(tz="UTC").isoformat(),
               "oi_policy": "positive_native_contiguous_15m"})
    marker.unlink()
    return rows
