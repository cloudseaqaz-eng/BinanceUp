"""Causal high/low continuity occupancy and uninterrupted qualifying durations."""
import numpy as np
import pandas as pd

WINDOWS = (180, 360)


def metrics(raw):
    raw = raw.sort_index().reindex(pd.date_range(raw.index.min(), raw.index.max(), freq="min", name="time"))
    result = pd.DataFrame(index=raw.index)
    for kind, column in (("trade", "trades"), ("buy", "taker_quote")):
        value = raw[column]
        active = value.gt(0).astype(float).where(np.isfinite(value) & value.ge(0))
        points = active.rolling(5, min_periods=5).sum()
        prefix = "state_"+kind+"_"
        result[prefix+"c5"] = points/5
        for label, condition in (("run80", points.ge(4)), ("run100", points.eq(5))):
            run, values = 0, []
            for known, qualifies in zip(points.notna(), condition):
                run = run+1 if known and qualifies else 0
                values.append(float(run) if known else np.nan)
            result[prefix+label] = values
        high = points.ge(4).astype(float).where(points.notna())
        low = points.le(1).astype(float).where(points.notna())
        for window in WINDOWS:
            result[prefix+"high"+str(window)] = high.rolling(window, min_periods=window).mean()
            result[prefix+"low"+str(window)] = low.rolling(window, min_periods=window).mean()
    return result
