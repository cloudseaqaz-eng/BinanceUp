"""Lossless storage: exact dtypes/values, virtual duplicate columns, verified commits.

Storage format v2 does not change any feature, sampling, label, or scoring formula.
Legacy Parquet files remain readable. Only physically redundant columns are virtual.
"""
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import json
import os
import uuid
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from .config import json_write, utc

KEY = b"binanceup.storage"
VERSION = 2
RAW_COLUMNS = ("open", "high", "low", "close", "volume", "quote", "trades", "taker_quote")


def file_digest(path):
    h = sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()


def frame_digest(frame):
    """Logical fingerprint independent of Parquet codec and row group boundaries."""
    h = sha256()
    schema = {"columns": list(frame.columns), "dtypes": [str(t) for t in frame.dtypes],
              "index_dtype": str(frame.index.dtype), "index_names": frame.index.names}
    h.update(json.dumps(schema, sort_keys=True).encode())
    arrays = [frame.index.to_numpy()]+[frame[c].to_numpy() for c in frame.columns]
    for a in arrays:
        if a.dtype.kind in "biufmM":
            a = a.astype(a.dtype.newbyteorder("<"), copy=True)
            if a.dtype.kind == "f":
                a[np.isnan(a)] = np.nan
            h.update(a.tobytes())
        else:
            # Includes timezone-aware index values. Stable within supported pandas 2.x.
            h.update(pd.util.hash_array(a).astype("<u8").tobytes())
    return h.hexdigest()


def metadata(path):
    return json.loads((pq.read_schema(path).metadata or {}).get(KEY, b"{}"))


@lru_cache(maxsize=256)
def _source_digest(path, size, mtime_ns):
    # Modern raw files carry the fingerprint verified when they were written.
    # The stat-keyed cache avoids rereading a legacy raw file for every query.
    info = metadata(path)
    return info.get("logical_sha256") or frame_digest(pd.read_parquet(path, page_checksum_verification=True))


def source_digest(path):
    p = Path(path).resolve()
    st = p.stat()
    return _source_digest(str(p), st.st_size, st.st_mtime_ns)


def _raw_source(path, info):
    name = info["source_name"]
    if Path(name).name != name or not name.endswith(".parquet"):
        raise ValueError("无效的基础行情引用")
    source = Path(path).parent.parent/"raw"/name
    if source_digest(source) != info["source_logical_sha256"]:
        raise ValueError("基础行情已变化，不能混用旧指标；请重新生成 features、labels 和 train："+name)
    return source


def read_frame(path, start=None, end=None, columns=None):
    path = Path(path)
    info = metadata(path)
    filters = []
    if start is not None:
        filters.append(("time", ">=", utc(start)))
    if end is not None:
        filters.append(("time", "<=", utc(end)))
    virtual = info.get("virtual_columns", {})
    if not virtual:
        return pd.read_parquet(path, columns=columns, filters=filters or None, page_checksum_verification=True)
    requested = list(columns) if columns is not None else info["columns"]
    unknown = set(requested)-set(info["columns"])
    if unknown:
        raise KeyError("未知特征列："+", ".join(sorted(unknown)))
    physical = [c for c in requested if c not in virtual]
    source = _raw_source(path, info)
    result = pd.read_parquet(path, columns=physical, filters=filters or None, page_checksum_verification=True)
    needed = [c for c in requested if c in virtual]
    if needed:
        raw = pd.read_parquet(source, columns=needed, filters=filters or None, page_checksum_verification=True).reindex(result.index)
        for c in needed:
            # Preserve the original feature dtype (including pre-existing float32),
            # never introduce further quantization or change the raw float64 file.
            result[c] = raw[c].astype(virtual[c])
    return result[requested]


def _write_table(frame, path, info):
    table = pa.Table.from_pandas(frame, preserve_index=None)
    table = table.replace_schema_metadata({**(table.schema.metadata or {}), KEY: json.dumps(info, sort_keys=True).encode()})
    dictionary, encodings = [], {}
    for field in table.schema:
        if pa.types.is_floating(field.type):
            encodings[field.name] = "BYTE_STREAM_SPLIT"
        elif pa.types.is_integer(field.type) or pa.types.is_timestamp(field.type):
            encodings[field.name] = "DELTA_BINARY_PACKED"
        elif pa.types.is_string(field.type) or pa.types.is_large_string(field.type):
            dictionary.append(field.name)
    pq.write_table(table, path, compression="zstd", compression_level=9,
                   row_group_size=10080, use_dictionary=dictionary, column_encoding=encodings,
                   write_page_checksum=True)


def assert_exact(expected, actual):
    pd.testing.assert_frame_equal(expected, actual, check_exact=True, check_freq=False)
    # Equality alone treats +0/-0 alike; retain finite floating-point bits as well.
    for c in expected.select_dtypes(include=["float32", "float64"]).columns:
        a, b = expected[c].to_numpy(), actual[c].to_numpy()
        valid = ~np.isnan(a)
        if a[valid].tobytes() != b[valid].tobytes():
            raise AssertionError("浮点位模式发生变化："+c)


def write_frame(frame, path, raw_source=None):
    """Write a temporary file, read it back, verify exact equality, then atomic replace."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    original = frame
    info = {"version": VERSION, "columns": list(frame.columns), "logical_sha256": frame_digest(frame), "virtual_columns": {}}
    if raw_source is not None:
        raw_source = Path(raw_source)
        if raw_source.resolve().parent != (path.parent.parent/"raw").resolve():
            raise ValueError("基础行情必须在本实验 raw 目录中")
        raw = pd.read_parquet(raw_source, page_checksum_verification=True).reindex(frame.index)
        for c in RAW_COLUMNS:
            if c not in frame or c not in raw:
                continue
            try:
                restored = raw[[c]].astype({c: frame[c].dtype})
                assert_exact(frame[[c]], restored)
            except (AssertionError, ValueError, TypeError):
                continue  # A non-identical value is NEVER discarded to save space.
            info["virtual_columns"][c] = str(frame[c].dtype)
        if info["virtual_columns"]:
            info.update(source_name=raw_source.name, source_logical_sha256=source_digest(raw_source))
            frame = frame.drop(columns=list(info["virtual_columns"]))
    temporary = path.with_name("."+path.name+"."+uuid.uuid4().hex+".part")
    try:
        _write_table(frame, temporary, info)
        assert_exact(original, read_frame(temporary))
        # Only publish after all data and metadata are durable and verified.
        with temporary.open("rb") as f:
            os.fsync(f.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return info


def receipt(path):
    path = Path(path)
    return {"name": path.name, "bytes": path.stat().st_size, "sha256": file_digest(path),
            "logical_sha256": source_digest(path), "rows": pq.read_metadata(path).num_rows}


def verify_receipts(cfg, records):
    for r in records:
        if Path(r["name"]).name != r["name"]:
            return False
        path = cfg.path/"raw"/r["name"]
        if not path.exists() or path.stat().st_size != r["bytes"] or file_digest(path) != r["sha256"]:
            return False
    return bool(records)


def prune_archives(cfg, manifest):
    """Delete only listed, hash-matching ZIPs after checking converted raw receipts."""
    if manifest.get("error") or not verify_receipts(cfg, manifest.get("raw_receipts", [])):
        raise ValueError("原始转换文件未验证，拒绝清理ZIP缓存")
    removed = 0
    directory = (cfg.path/"archive").resolve()
    for item in manifest.get("files", []):
        if item.get("status") == "404":
            continue
        path = (directory/item["path"]).resolve()
        if not path.is_relative_to(directory) or path.suffix != ".zip":
            raise ValueError("无效的归档路径")
        if not path.exists():
            continue
        if not item.get("sha256") or file_digest(path) != item["sha256"]:
            raise ValueError("ZIP哈希不符，保留文件："+str(path))
        removed += path.stat().st_size
        path.unlink()
    return removed


def usage(cfg):
    result = {}
    for name in ("archive", "raw", "features", "labels", "results", "context"):
        result[name] = sum(p.stat().st_size for p in (cfg.path/name).rglob("*") if p.is_file())
    result["market"] = (cfg.path/"market.parquet").stat().st_size if (cfg.path/"market.parquet").exists() else 0
    result["total"] = sum(result.values())
    return result


def compact(cfg, prune=False):
    """Migrate existing data in place. One verified atomic file replacement at a time.

    A partially completed run remains readable because raw references use logical
    fingerprints, which survive changes of compression. The command is idempotent.
    """
    before = usage(cfg)
    log = []
    files = sorted((cfg.path/"raw").glob("*.parquet"))
    files += sorted((cfg.path/"features").glob("*.parquet"))
    files += sorted((cfg.path/"labels").glob("*.parquet"))
    if (cfg.path/"market.parquet").exists():
        files.append(cfg.path/"market.parquet")
    files += sorted((cfg.path/"results").glob("*.parquet"))
    for path in files:
        if metadata(path).get("version") == VERSION:
            continue
        f = read_frame(path)
        previous_bytes = path.stat().st_size
        raw = cfg.path/"raw"/path.name if path.parent.name == "features" else None
        info = write_frame(f, path, raw_source=raw if raw and raw.exists() else None)
        log.append({"file": str(path.relative_to(cfg.path)), "before": previous_bytes, "after": path.stat().st_size,
                    "rows": len(f), "exact_roundtrip": True, "virtual_columns": list(info["virtual_columns"])})
        print("compact", log[-1]["file"], previous_bytes, "->", path.stat().st_size, flush=True)
    # Update receipts after verified recompression; original archive hashes remain.
    # This also gives legacy successful downloads a resumable converted-data checkpoint.
    manifests = []
    for path in sorted((cfg.path/"manifests").glob("*.json")):
        m = json.loads(path.read_text())
        if m.get("error"):
            manifests.append(m)
            continue
        symbol = m["symbol"]
        records = []
        for suffix, count in (("", "spot_rows"), (".oi", "oi_rows"), (".funding", "funding_rows")):
            raw = cfg.path/"raw"/(symbol+suffix+".parquet")
            if m.get(count, 0):
                if not raw.exists() or pq.read_metadata(raw).num_rows != m[count]:
                    raise ValueError("原始行数与下载清单不符，拒绝清理："+symbol+suffix)
                records.append(receipt(raw))
        m["raw_receipts"] = records
        # Preserve any existing request descriptor; legacy inference is restricted
        # to the existing experiment's configured interval and observed funding calls.
        from .data import download_request
        funding = not m.get("oi_rows") or any("/fundingRate/" in item["path"] for item in m.get("files", []))
        m.setdefault("request", download_request(cfg, funding))
        json_write(path, m)
        if prune and records:
            prune_archives(cfg, m)
        manifests.append(m)
    if manifests:
        json_write(cfg.path/"download_summary.json", manifests)
    after = usage(cfg)
    report = {"version": VERSION, "before": before, "after": after, "saved_bytes": before["total"]-after["total"],
              "files_verified": len(log), "files": log, "pruned_archives": prune,
              "invariant": "全部时间点、dtype、数值、NaN位置及有限浮点位模式不变；无降采样、无公式变化"}
    json_write(cfg.path/"storage_report.json", report)
    return report
