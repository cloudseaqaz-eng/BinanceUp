"""Bounded minute-by-minute continuity accumulation, separate from fitted scores."""
import numpy as np
import pandas as pd


def accumulation(raw):
    columns = ["activity_accum", "activity_points5", "activity_step"]
    if raw.empty:
        return pd.DataFrame(index=raw.index, columns=columns, dtype=float)
    raw = raw.sort_index()
    raw = raw.reindex(pd.date_range(raw.index.min(), raw.index.max(), freq="min", name="time"))
    trades = raw.trades
    active = trades.gt(0).astype(float).where(np.isfinite(trades) & trades.ge(0))
    points = active.rolling(5, min_periods=5).sum()
    steps = pd.Series(np.where(points.ge(4), 1., np.where(points.le(1), -1., 0.)),
                      index=points.index).where(points.notna())
    score, values = 0., []
    for step in steps:
        if pd.isna(step):
            score = 0.
            values.append(np.nan)
        else:
            score = min(20., max(0., score+step))
            values.append(score)
    return pd.DataFrame({"activity_accum": values, "activity_points5": points,
                         "activity_step": steps}, index=raw.index)
