from dataclasses import asdict, dataclass, field
from pathlib import Path
import json
import pandas as pd

COMPONENTS = ["compression", "proximity", "preheat", "trade_count", "buy_bias", "relative_strength", "oi_build", "cvd_divergence"]
COMPONENT_LABELS = ["压缩度", "临界度", "预热放量", "笔数放大", "买盘倾向", "相对强度", "OI 蓄积", "CVD 背离"]
PDF_WEIGHTS = [.15, .20, .20, .05, .15, .10, .10, .05]
STABLE_BASES = {"USDT", "USDC", "BUSD", "TUSD", "FDUSD", "USDP", "DAI", "UST", "USTC", "AEUR", "EUR", "GBP", "AUD", "BRL", "BIDR", "IDRT", "TRY", "RUB", "UAH", "PAX", "SUSD", "USD1", "USDE", "EURI"}


def utc(value):
    t = pd.Timestamp(value)
    return t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")


def json_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


@dataclass
class Config:
    start: str
    end: str
    root: str = "research_data"
    warmup_days: int = 30
    sample_minutes: int = 1
    top_n: int = 10
    horizon_minutes: int = 1440
    min_quote24: float = 5_000_000
    oi_mode: str = "available"  # required | available | off; always reported
    oi_lag_minutes: int = 1
    trials: int = 256
    seed: int = 20261022
    top_k: int = 10
    min_score: float = 55
    pool_size: int = 30
    train_days: int = 56
    validation_days: int = 14
    calibration_days: int = 14
    test_days: int = 14
    holdout_days: int = 28
    min_calibration_rows: int = 500
    symbols: list = field(default_factory=list)
    universe_scope: str = "explicit_subset"

    def __post_init__(self):
        if utc(self.end) <= utc(self.start):
            raise ValueError("end 必须晚于 start；时间无时区时按 UTC")
        if self.sample_minutes < 1 or self.sample_minutes > 60 or 60 % self.sample_minutes:
            raise ValueError("sample_minutes 必须为 60 的正整数约数")
        if self.warmup_days < 22:
            raise ValueError("至少需要 22 天预热：14 天季节基线 + 7 天稳健统计")
        if self.oi_mode not in {"required", "available", "off"}:
            raise ValueError("未知 OI 模式")

    @property
    def path(self):
        return Path(self.root).resolve()

    @property
    def warm_start(self):
        return utc(self.start) - pd.Timedelta(days=self.warmup_days)

    def save(self):
        json_write(self.path / "config.json", asdict(self))

    @classmethod
    def load(cls, root):
        data = json.loads((Path(root) / "config.json").read_text())
        data["root"] = str(Path(root).resolve())
        return cls(**data)


def board_symbol(symbol):
    if not symbol.endswith("USDT") or not symbol.isalnum():
        return False
    base = symbol[:-4]
    # Explicit suffix list: do not accidentally exclude JUP, SUPER, etc.
    leveraged = ("UP", "DOWN", "BULL", "BEAR")
    leveraged_roots = {"BTC", "ETH", "BNB", "XRP", "TRX", "EOS", "LINK", "ADA", "XTZ", "DOT", "BCH", "LTC", "SUSHI", "UNI", "YFI", "FIL", "AAVE", "SXP"}
    return base not in STABLE_BASES and not any(base == r+s for r in leveraged_roots for s in leveraged)
