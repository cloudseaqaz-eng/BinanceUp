"""On-demand upper-wick diagnostics; never changes stored scoring features."""
import numpy as np
import pandas as pd

BASELINE_MINUTES = 360
BASELINE_GAP = 30
NOISE_FLOOR = .01  # one percentage point of change above the baseline median
CONFIRM_MINUTES = 3
# Include enough history for the baseline and a day of event context. A longer
# uninterrupted event is explicitly left censored rather than given a fake start.
LOOKBACK_MINUTES = BASELINE_MINUTES + BASELINE_GAP + 8 + 1440
NOTE = ("分钟变化=相邻UW3差值的绝对值；蓝线为最近5分钟平均。历史基线取此前6小时，"
        "排除最近30分钟，至少95%样本有效。连续3分钟高于P90且高于中位数至少1个百分点才确认；"
        "标记落在确认分钟，不回填到起点。这是形态变化标记，尚未验证为看涨信号，也未改动评分。")


def metrics(raw):
    if raw.empty:
        raise ValueError("计算UW观察指标需要分钟K线")
    raw = raw.sort_index()
    raw = raw.reindex(pd.date_range(raw.index.min(), raw.index.max(), freq="min", name="time"))
    prices = raw[["open", "high", "low", "close"]]
    known = np.isfinite(prices).all(axis=1) & prices.gt(0).all(axis=1)
    known &= raw.high.ge(prices[["open", "close"]].max(axis=1))
    known &= raw.low.le(prices[["open", "close"]].min(axis=1))
    span = (raw.high-raw.low).where(known)
    upper = (raw.high-prices[["open", "close"]].max(axis=1)).where(known)
    # Legacy UW3 regards a known flat candle as zero upper wick. Keep that
    # interpretation for its observer copy, while missing candles stay unknown.
    uw1 = (upper/span.replace(0, np.nan)).where(span.ne(0), 0.).where(known)
    result = pd.DataFrame(index=raw.index)
    result["uw_raw3"] = uw1.rolling(3, min_periods=3).mean()
    total_span = span.rolling(15, min_periods=15).sum()
    result["uw_pressure15"] = upper.rolling(15, min_periods=15).sum()/total_span.replace(0, np.nan)
    result["uw_delta1"] = result.uw_raw3.diff().abs()
    result["uw_change5"] = result.uw_delta1.rolling(5, min_periods=5).mean()
    history = result.uw_change5.shift(BASELINE_GAP)
    coverage = history.notna().rolling(BASELINE_MINUTES, min_periods=BASELINE_MINUTES).mean()
    past = history.rolling(BASELINE_MINUTES, min_periods=int(np.ceil(.95*BASELINE_MINUTES)))
    result["uw_baseline"] = past.median().where(coverage >= .95)
    result["uw_p90"] = past.quantile(.9).where(coverage >= .95)
    result["uw_baseline_coverage"] = coverage
    result["uw_threshold"] = np.maximum(result.uw_p90, result.uw_baseline+NOISE_FLOOR)
    valid = result[["uw_change5", "uw_threshold"]].notna().all(axis=1)
    above = result.uw_change5.gt(result.uw_threshold+1e-12)
    run, censored, start_ms, confirmed_ms = 0, False, np.nan, np.nan
    previous_known = False
    rows = []
    for i, t in enumerate(result.index):
        event = False
        if not valid.iloc[i]:
            run, censored, start_ms, confirmed_ms = 0, False, np.nan, np.nan
        elif not above.iloc[i]:
            run, censored, start_ms, confirmed_ms = 0, False, np.nan, np.nan
        else:
            if run == 0:
                censored = not previous_known
                start_ms = np.nan if censored else t.value//10**6
            run += 1
            if run == CONFIRM_MINUTES:
                confirmed_ms = t.value//10**6
                # For a left-censored run this is only the first confirmation
                # visible in the available history, not the true first event.
                event = not censored
        rows.append({"uw_above": float(above.iloc[i]) if valid.iloc[i] else np.nan,
                     "uw_run_minutes": float(run) if valid.iloc[i] else np.nan,
                     "uw_run_censored": censored,
                     "uw_started_ms": start_ms,
                     "uw_confirmed_ms": confirmed_ms,
                     "uw_confirmed": bool(run >= CONFIRM_MINUTES), "uw_event": event})
        previous_known = bool(valid.iloc[i])
    return result.join(pd.DataFrame(rows, index=result.index))


def events(frame, start, end):
    """Exact minute markers independent of selected display/Kline period."""
    window = frame.loc[start:end]
    rows = []
    for t, r in window.loc[window.uw_event].iterrows():
        rows.append({"ms": t.value//10**6, "started_ms": int(r.uw_started_ms),
                     "value": float(r.uw_change5), "threshold": float(r.uw_threshold)})
    return rows


def regions(frame, start, end):
    window = frame.loc[start:end]
    output, first, last = [], None, None
    for t, r in window.iterrows():
        if r.uw_confirmed:
            if first is None:
                first = t
            last = t
        elif first is not None:
            output.append({"start_ms": first.value//10**6, "end_ms": (last+pd.Timedelta(minutes=1)).value//10**6})
            first, last = None, None
    if first is not None:
        output.append({"start_ms": first.value//10**6, "end_ms": (last+pd.Timedelta(minutes=1)).value//10**6})
    return output
