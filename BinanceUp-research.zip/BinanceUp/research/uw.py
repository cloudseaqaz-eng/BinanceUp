"""On-demand upper-wick pressure; never changes stored scoring features."""
import numpy as np
import pandas as pd

WINDOWS = (30, 60, 120)
LOOKBACK_MINUTES = 1440 + max(WINDOWS) + 1
NOTE = ("原始UW3为最近3根一分钟K线上影比例的平均值；压力15为15分钟上影长度之和÷振幅之和。"
        "已知平价K线的原始上影比例记0；15分钟完全无波动时加权压力留空。缺失或非法K线不补零。平滑窗口30/60/120分钟：UW3零值占比为窗口中零值样本占比；整体上影压力为该窗口上影总长÷振幅总和。窗口数据完整才显示；对比基线为当前窗口之前的24小时。")


def metrics(raw):
    if raw.empty:
        raise ValueError("计算UW观察指标需要分钟K线")
    raw = raw.sort_index()
    raw = raw.reindex(pd.date_range(raw.index.min(), raw.index.max(), freq="min", name="time"))
    prices = raw[["open", "high", "low", "close"]]
    known = np.isfinite(prices).all(axis=1) & prices.gt(0).all(axis=1)
    known &= raw.high.ge(prices[["open", "close"]].max(axis=1))
    known &= raw.low.le(prices[["open", "close"]].min(axis=1))
    span = (raw.high-raw.low).where(known)
    upper = (raw.high-prices[["open", "close"]].max(axis=1)).where(known)
    uw1 = (upper/span.replace(0, np.nan)).where(span.ne(0), 0.).where(known)
    result = pd.DataFrame(index=raw.index)
    result["uw_raw3"] = uw1.rolling(3, min_periods=3).mean()
    total_span = span.rolling(15, min_periods=15).sum()
    result["uw_pressure15"] = upper.rolling(15, min_periods=15).sum()/total_span.replace(0, np.nan)
    # All windows are elapsed minutes, including gaps. Require complete data;
    # coverage is exposed so a blank never silently becomes a zero.
    zero = result.uw_raw3.eq(0).astype(float).where(result.uw_raw3.notna())
    baseline_zero = zero.rolling(1440, min_periods=1440).mean()
    baseline_upper = upper.rolling(1440, min_periods=1440).sum()
    baseline_span = span.rolling(1440, min_periods=1440).sum()
    baseline_pressure = baseline_upper/baseline_span.replace(0, np.nan)
    for window in WINDOWS:
        result[f"uw_zero{window}"] = zero.rolling(window, min_periods=window).mean()
        result[f"uw_pressure{window}"] = (upper.rolling(window, min_periods=window).sum()
            / span.rolling(window, min_periods=window).sum().replace(0, np.nan))
        result[f"uw_coverage{window}"] = (zero.notna().astype(float)
            .rolling(window, min_periods=window).mean())
        result[f"uw_zero_delta{window}"] = result[f"uw_zero{window}"]-baseline_zero.shift(window)
        result[f"uw_pressure_delta{window}"] = result[f"uw_pressure{window}"]-baseline_pressure.shift(window)
    return result
