"""On-demand upper-wick pressure; never changes stored scoring features."""
import numpy as np
import pandas as pd

LOOKBACK_MINUTES = 14
NOTE = ("原始UW3为最近3根一分钟K线上影比例的平均值；压力15为15分钟上影长度之和÷振幅之和。"
        "已知平价K线的原始上影比例记0；15分钟完全无波动时加权压力留空。缺失或非法K线不补零。")


def metrics(raw):
    if raw.empty:
        raise ValueError("计算UW观察指标需要分钟K线")
    raw = raw.sort_index()
    raw = raw.reindex(pd.date_range(raw.index.min(), raw.index.max(), freq="min", name="time"))
    prices = raw[["open", "high", "low", "close"]]
    known = np.isfinite(prices).all(axis=1) & prices.gt(0).all(axis=1)
    known &= raw.high.ge(prices[["open", "close"]].max(axis=1))
    known &= raw.low.le(prices[["open", "close"]].min(axis=1))
    span = (raw.high-raw.low).where(known)
    upper = (raw.high-prices[["open", "close"]].max(axis=1)).where(known)
    uw1 = (upper/span.replace(0, np.nan)).where(span.ne(0), 0.).where(known)
    result = pd.DataFrame(index=raw.index)
    result["uw_raw3"] = uw1.rolling(3, min_periods=3).mean()
    total_span = span.rolling(15, min_periods=15).sum()
    result["uw_pressure15"] = upper.rolling(15, min_periods=15).sum()/total_span.replace(0, np.nan)
    return result
