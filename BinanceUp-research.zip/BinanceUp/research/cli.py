import argparse
from dataclasses import asdict
from pathlib import Path
import json
import sys
import pandas as pd
from .config import Config, board_symbol, json_write, utc


def main(argv=None):
    parser = argparse.ArgumentParser(description="币安慢层评分回测（研究用途，无下单模块）")
    parser.add_argument("--root", default="research_data", help="独立数据目录；可保存多个实验")
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init", help="创建最近六个日历月的实验配置")
    init.add_argument("--start")
    init.add_argument("--end", help="UTC结束时刻（包含最后一根于此收盘的分钟K线）")
    init.add_argument("--symbols", help="逗号分隔；仅限子市场研究，不可宣称是币安全市场概率")
    init.add_argument("--universe", help="每行一个交易对的历史归档目录清单（discover 导出）")
    init.add_argument("--sample-minutes", type=int, default=1)
    init.add_argument("--oi-mode", choices=["available", "required", "off"], default="available")
    init.add_argument("--trials", type=int, default=256)
    d = sub.add_parser("discover", help="下载历史归档交易对目录（含下架币），写入清单")
    d.add_argument("--output", default="universe.json")
    d = sub.add_parser("download", help="下载预热期+回测区间，按ZIP缓存，可重复执行")
    d.add_argument("--workers", type=int, default=3)
    d.add_argument("--no-funding", action="store_true")
    for command in ("features", "labels", "train", "run", "status"):
        sub.add_parser(command)
    serve = sub.add_parser("serve", help="本机回测面板")
    serve.add_argument("--port", type=int, default=8767)
    demo = sub.add_parser("demo", help="生成隔离的模拟演示；不产生任何真实币安结论")
    demo.add_argument("--days", type=int, default=150)
    demo.add_argument("--train", action="store_true")
    args = parser.parse_args(argv)
    if args.command == "discover":
        from .data import discover
        symbols = discover()
        json_write(args.output, {"source": "binance_historical_archive", "fetched_at": pd.Timestamp.now(tz="UTC").isoformat(), "symbols": symbols})
        print(f"保存 {len(symbols)} 个历史USDT交易对到 {args.output}")
        return
    if args.command == "init":
        end = utc(args.end) if args.end else pd.Timestamp.now(tz="UTC").floor("D")
        start = utc(args.start) if args.start else end-pd.DateOffset(months=6)
        scope = "explicit_subset"
        if args.universe:
            p = Path(args.universe)
            if p.suffix.lower() == ".json":
                data = json.loads(p.read_text())
                symbols = data["symbols"] if isinstance(data, dict) else data
                if isinstance(data, dict) and data.get("source") == "binance_historical_archive":
                    scope = "historical_archive"
            else:
                symbols = p.read_text().splitlines()
        elif args.symbols:
            symbols = args.symbols.upper().split(",")
        else:
            from .data import discover
            symbols = discover()
            scope = "historical_archive"
        symbols = sorted({s.strip() for s in symbols if board_symbol(s.strip())})
        if not symbols:
            raise ValueError("交易对清单为空")
        if (Path(args.root)/"config.json").exists():
            raise ValueError("实验目录已有配置；为避免混用缓存/模型，请指定新的 --root")
        cfg = Config(start=start.isoformat(), end=end.isoformat(), root=str(Path(args.root).resolve()), symbols=symbols,
                     universe_scope=scope, sample_minutes=args.sample_minutes, oi_mode=args.oi_mode, trials=args.trials)
        cfg.save()
        print(json.dumps(asdict(cfg), ensure_ascii=False, indent=2))
        print("下一步: python -m research --root", args.root, "run")
        return
    if args.command == "demo":
        from .demo import make_demo
        cfg = make_demo(args.root, args.days)
        if args.train:
            from .train import train
            train(cfg)
        return
    cfg = Config.load(args.root)
    if args.command in ("download", "run"):
        from .data import download
        download(cfg, getattr(args, "workers", 3), funding=not getattr(args, "no_funding", False))
    if args.command in ("features", "run"):
        from .features import build_features
        build_features(cfg)
    if args.command in ("labels", "run"):
        from .labels import build_labels
        build_labels(cfg)
    if args.command in ("train", "run"):
        from .train import train
        report = train(cfg)
        print(json.dumps(report["final_holdout"]["top_k"], ensure_ascii=False, indent=2))
    if args.command == "serve":
        from .web import serve
        serve(cfg, args.port)
    if args.command == "status":
        print(json.dumps(asdict(cfg), ensure_ascii=False, indent=2))
        for name in ("download_summary.json", "feature_summary.json", "label_summary.json", "results/report.json"):
            path = cfg.path/name
            print(name, "存在" if path.exists() else "未生成")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, OSError) as e:
        print("错误:", e, file=sys.stderr)
        sys.exit(1)
