"""Minute-sampled rolling-24h market board, independent of slow-layer filters."""
import json
import numpy as np
import pandas as pd
from .config import json_write, utc
from .data import read_raw
from .features import past_percentile


def future_labels(in_top, board_valid, horizon=1440):
    """A label exists only when the full [t,t+h] board is observed and t is not top N.

    First success is the first *future* top-N minute. No hit at t counts as success.
    Even an early observed success is censored if the rest of the horizon is missing;
    this deliberately avoids selectively retaining positives under data loss.
    """
    inside = np.asarray(in_top, dtype=bool)
    valid = np.asarray(board_valid, dtype=bool)
    n = len(inside)
    future_ok = pd.Series(valid[::-1].astype(float)).rolling(horizon+1, min_periods=horizon+1).sum().to_numpy()[::-1] == horizon+1
    next_hit = np.minimum.accumulate(np.where(inside, np.arange(n), n)[::-1])[::-1]
    next_hit = np.r_[next_hit[1:], n]
    delay = next_hit-np.arange(n)
    known = future_ok & ~inside
    hit = (next_hit < n) & (delay <= horizon)
    label = np.where(known, hit.astype(float), np.nan)
    delay = np.where(known & hit, delay, np.nan)
    return label, delay


def build_labels(cfg):
    # A failed downloader is not evidence that a symbol did not trade. Refuse to
    # silently shrink the board after an interrupted/partly failed real download.
    if cfg.universe_scope != "synthetic_demo":
        summary_path = cfg.path / "download_summary.json"
        if not summary_path.exists():
            raise ValueError("缺少完整下载清单；先完成 download，不能用不明来源的缺币数据构建榜单")
        downloads = {r["symbol"]: r for r in json.loads(summary_path.read_text())}
        failed = [s for s in cfg.symbols if s not in downloads or downloads[s].get("error")]
        if failed:
            raise ValueError("下载不完整，拒绝缩小榜单宇宙：" + ", ".join(failed[:12]))
    symbols, closes, opens, lifetimes = [], [], [], []
    for symbol in sorted(cfg.symbols):
        raw = read_raw(cfg, symbol)
        if raw.empty or not raw.close.notna().any():
            continue
        symbols.append(symbol)
        closes.append(raw.close.to_numpy(dtype=np.float32))
        opens.append(raw.open.to_numpy(dtype=np.float32))
        nonnull = np.flatnonzero(raw.close.notna().to_numpy())
        lifetimes.append((int(nonnull[0]), int(nonnull[-1])))
    if len(symbols) <= cfg.top_n:
        raise ValueError(f"只有 {len(symbols)} 个有数据的交易对，无法研究进入前 {cfg.top_n}；至少需要更多竞争币")
    index = raw.index
    close = np.column_stack(closes)
    del closes
    base = np.full_like(close, np.nan)
    base[1440:] = close[:-1440]
    expected = np.zeros_like(close, dtype=bool)
    for j, (first, last) in enumerate(lifetimes):
        expected[max(first, 1440 if first == 0 else first):last+1, j] = True
        if first > 0:
            # Newly observed listing: the first open is a public-data approximation to ticker's openPrice.
            base[first:min(first+1440, len(index)), j] = opens[j][first]
    returns = close/base-1
    known = np.isfinite(returns) & expected
    count = expected.sum(axis=1)
    coverage = np.divide(known.sum(axis=1), count, out=np.zeros(len(count), dtype=float), where=count > 0)
    board_valid = (coverage == 1) & (count > cfg.top_n)
    # Alphabetical tie breaking is deterministic, documented, and independent of future prices.
    ret = pd.DataFrame(np.where(known, returns, np.nan), index=index, columns=symbols)
    ranks = ret.rank(axis=1, ascending=False, method="first").to_numpy(dtype=np.float32)
    ranks[~board_valid, :] = np.nan
    r15 = close/np.roll(close, 15, axis=0)-1
    r15[:15] = np.nan
    eligible_breadth = expected & np.isfinite(r15)
    breadth = np.divide(((r15 > 0) & eligible_breadth).sum(axis=1), eligible_breadth.sum(axis=1),
                        out=np.full(len(index), np.nan), where=eligible_breadth.sum(axis=1) > 0)
    breadth[~board_valid] = np.nan
    btc_path = cfg.path / "features" / "BTCUSDT.parquet"
    btc = pd.read_parquet(btc_path, columns=["zr5", "sigma"]).reindex(index)
    # Volatility regime percentile: past 7 days at hourly observations, frozen between hours.
    hourly = btc.sigma.resample("h").last().shift(1)
    vol_pct = past_percentile(hourly, 168).reindex(index, method="ffill")
    risk_off = (btc.zr5 <= -2.5) | ((breadth < .25) & (vol_pct > .9))
    market = pd.DataFrame({"board_valid": board_valid, "board_coverage": coverage, "board_size": count,
                           "breadth15": breadth, "btc_zr5": btc.zr5, "btc_vol_pct": vol_pct, "risk_off": risk_off}, index=index)
    directory = cfg.path / "labels"
    directory.mkdir(exist_ok=True)
    market.to_parquet(cfg.path / "market.parquet", compression="zstd", row_group_size=1440)
    labels_summary = []
    for j, symbol in enumerate(symbols):
        rank = ranks[:, j]
        target, delay = future_labels(np.nan_to_num(rank, nan=np.inf) <= cfg.top_n, board_valid, cfg.horizon_minutes)
        # Asset itself must be rankable now, and its full horizon must remain observed/listed.
        asset_ok = pd.Series(known[:, j][::-1].astype(float)).rolling(cfg.horizon_minutes+1, min_periods=cfg.horizon_minutes+1).sum().to_numpy()[::-1] == cfg.horizon_minutes+1
        target[~asset_ok], delay[~asset_ok] = np.nan, np.nan
        result = pd.DataFrame({"rank24": rank, "board_return24": returns[:, j], "target": target,
                               "first_hit_minutes": delay}, index=index)
        result.to_parquet(directory / f"{symbol}.parquet", compression="zstd", row_group_size=1440)
        labels_summary.append({"symbol": symbol, "known_labels": int(np.isfinite(target).sum()), "positive_labels": int(np.nansum(target))})
    report = {"universe_scope": cfg.universe_scope, "symbols_with_data": len(symbols), "symbols_requested": len(cfg.symbols),
              "minute_coverage": float(board_valid.mean()), "range_coverage": float(board_valid[(index >= utc(cfg.start)) & (index <= utc(cfg.end))].mean()),
              "definition": f"t 时不在前 {cfg.top_n}；(t,t+{cfg.horizon_minutes}min] 内首次进入；每分钟采样滚动24h涨幅",
              "not_official_realtime_board": True,
              "universe_method": "历史归档 USDT 非稳定/非杠杆交易对；起止交易时间由归档首尾推断；新币首24h用首根open近似",
              "limitations": ["盘口、历史交易状态/监控标签/公告/解锁检测时刻未验证", "最后一日及未来窗口有任何缺口的标签为未知", "归档首尾推断交易区间可能将终端数据缺失误认为下架，应使用交易所历史状态复核"],
              "per_symbol": labels_summary}
    json_write(cfg.path / "label_summary.json", report)
    print("labels:", {k: v for k, v in report.items() if k != "per_symbol"}, flush=True)
    return report
