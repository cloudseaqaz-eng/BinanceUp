"""OI quality checks and observable missing-data explanations."""
import numpy as np
import pandas as pd
from .config import utc

# Explicit unit mappings, not a speculative prefix search. Ratios are invariant
# to the constant conversion; chart quantity is expressed in spot base coins.
CONTRACTS = {base+"USDT": ("1000"+base+"USDT", 1000) for base in
             ("PEPE", "SHIB", "BONK", "FLOKI", "XEC", "LUNC", "SATS", "RATS", "CAT", "CHEEMS", "WHY")}
CONTRACTS["BABYDOGEUSDT"] = ("1MBABYDOGEUSDT", 1_000_000)


def contract(symbol):
    return CONTRACTS.get(symbol, (symbol, 1))


def native_oi(oi):
    if oi is None or oi.empty:
        return pd.DataFrame(columns=["oi", "oi_usdt", "doi15"])
    oi = oi.sort_index().loc[lambda x: ~x.index.duplicated(keep="last")].copy()
    native = oi.reindex(pd.date_range(oi.index.min(), oi.index.max(), freq="5min", name="time"))
    native["oi"] = native.oi.where(np.isfinite(native.oi) & native.oi.gt(0))
    native["oi_usdt"] = native.oi_usdt.where(np.isfinite(native.oi_usdt) & native.oi_usdt.gt(0) & native.oi.notna())
    # Do not calculate a 15m change across a missing/invalid intermediate sample.
    native["doi15"] = (native.oi/native.oi.shift(3)-1).where(native.oi.rolling(4).count().eq(4))
    return native


def diagnose_oi(oi, at, mode="available", zoi=None):
    at = utc(at)
    if mode == "off":
        return {"code": "off", "label": "已关闭OI", "message": "实验配置oi_mode=off，OI未参与评分。"}
    if oi is None or oi.empty:
        return {"code": "no_archive", "label": "无OI归档", "message": "本地没有OI原始归档；可能无对应永续、归档未覆盖、旧版合约名称不匹配或下载未完成，不能据此认定没有合约。"}
    past = oi.loc[oi.index <= at]
    if past.empty:
        return {"code": "not_yet", "label": "当时无OI", "message": "截至此时尚无OI观测，后续数据不用于补齐。"}
    last = past.iloc[-1]
    age = (at-past.index[-1]).total_seconds()/60
    if age > 4:
        return {"code": "gap", "label": "OI采样缺口", "message": f"最近原始OI距此时{age:.0f}分钟，超过4分钟沿用上限；不跨缺口填充。"}
    if not np.isfinite(last.oi) or last.oi <= 0:
        return {"code": "invalid", "label": "OI值无效", "message": "最近OI为0、负值或非有限数，作为无效观测，不能当成清仓或异常增仓。"}
    native = native_oi(past)
    if native.empty or pd.isna(native.doi15.iloc[-1]):
        return {"code": "change_gap", "label": "OI变化缺口", "message": "最近15分钟原生OI样本不足或包含无效点，无法可靠计算变化率。"}
    if zoi is not None and np.isfinite(zoi):
        return {"code": "ready", "label": "OI已覆盖", "message": "15分钟OI变化与7天历史基线可用；原生5分钟采样，按配置延后可用。"}
    valid = int(np.isfinite(native.doi15.iloc[max(0, len(native)-2017):-1]).sum())
    return {"code": "warmup", "label": "OI基线不足", "message": f"zOI15需此前7天2016个原生5分钟变化样本，当前实现至少1915个有效样本（约95%）；当前有效{valid}个。已有OI不等于已有标准化基线。", "baseline_valid": valid}
