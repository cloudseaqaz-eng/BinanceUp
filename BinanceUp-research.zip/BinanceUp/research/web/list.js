"use strict";
let data=null,controller=null;
function render(){
 if(!data)return;
 const reveal=$('#future').checked,state=$('#activity-filter').value;
 document.querySelectorAll('th.future').forEach(e=>e.classList.toggle('hidden',!reveal));
 const rows=data.rows.filter(r=>(!$('#eligible').checked||r.eligible)&&r.symbol.includes($('#search').value.trim().toUpperCase())&&(!state||String(r.activity_state)===state));
 $('#eligible-count').textContent=data.rows.filter(r=>r.eligible).length+' / '+data.rows.length;
 $('#selected-count').textContent=data.rows.filter(r=>r.selected).length;
 $('#coverage').textContent=pct(data.board_coverage);
 $('#model').textContent=data.model?data.model.id:'PDF 默认';
 $('#model-note').textContent=data.model?'模型从 '+fmtTime(data.model.usable_from)+' 起可用；当前时间此前的验证结果用于选权重。':(data.model_message||'此时尚无完成训练和校准的模型。使用PDF默认权重，概率留空。');
 $('#context-note').textContent=data.context_note+' 低流动性观察请取消“仅看可评分币”；新状态列不改变原评分或概率。';
 $('#empty').classList.toggle('hidden',rows.length>0);
 $('#rows').innerHTML=rows.map((r,i)=>`<tr data-symbol="${esc(r.symbol)}" class="${r.selected?'selected':''}">
 <td>${i+1}${r.selected?' <span class="pill green">候选</span>':''}</td>
 <td><a href="/detail.html?symbol=${encodeURIComponent(r.symbol)}&at=${encodeURIComponent(data.at)}">${esc(r.symbol)}</a></td>
 <td><b>${num(r.score,1)}</b></td><td>${pct(r.probability)}</td>
 <td class="activity" title="${esc('背景截至 '+fmtTime(r.background_at_ms)+'；72h异常活跃小时占比 '+pct(r.active_share72)+'；距上次异常活跃 '+duration(r.last_active_hours))}"><span class="pill">${esc(r.activity_label)}</span></td>
 <td class="quiet">${esc(quietText(r))}</td><td class="continuity">${pct(r.continuity15)}</td><td>${pct(r.runup7d)}</td>
 <td>${num(r.pdf_score,1)}</td>
 <td>${num(r.rank24,0)}</td><td class="${r.r1440>=0?'up':'down'}">${pct(r.r1440)}</td>
 <td>${num(r.rvol15)}×</td><td>${num(r.tcr15)}×</td><td>${pct(r.tbr15)}</td>
 <td class="oi-status" title="${esc(r.oi_status.message)}">${esc(r.oi_status.label)}</td>
 <td class="${reveal?'':'hidden'}">${r.target===1?'<span class="up">进入前10</span>':r.target===0?'未上榜':'未知 / 不适用'}</td>
 <td class="${reveal?'':'hidden'}">${finite(r.first_hit_minutes)?num(r.first_hit_minutes,0)+' 分钟后':'—'}</td>
 <td>${esc(r.reasons.join('；')||(r.selected?'本次截面候选':'未达候选门槛/排名'))}</td></tr>`).join('');
}
async function calculate(){if(controller)controller.abort();controller=new AbortController();$('#calculate').disabled=true;try{const at=fromInput($('#at').value);data=await api('/api/snapshot?at='+encodeURIComponent(at),controller.signal);history.replaceState(null,'','?at='+encodeURIComponent(data.at));notice(scopeText(data.universe_scope)+' · 仅已收盘分钟数据 · OI策略：'+data.oi_mode,data.universe_scope==='historical_archive'?'':'warn');render()}catch(e){if(e.name!=='AbortError')notice(e.message,'error')}finally{$('#calculate').disabled=false}}
$('#form').addEventListener('submit',e=>{e.preventDefault();calculate()});
['eligible','future','search','activity-filter'].forEach(id=>$('#'+id).addEventListener('input',render));
for(const [id,delta] of [['previous',-1],['next',1]])$('#'+id).onclick=()=>{$('#at').value=toInput(new Date(new Date(fromInput($('#at').value)).getTime()+delta*3600000));calculate()};
(async()=>{try{const s=await api('/api/status');const at=new URLSearchParams(location.search).get('at')||s.default_at;$('#at').value=toInput(at);$('#at').min=toInput(s.start);$('#at').max=toInput(s.end);if(!s.ready){notice('尚未生成特征和榜单，请先完成回测脚本的数据准备。','warn');return}await calculate()}catch(e){notice(e.message,'error')}})();
