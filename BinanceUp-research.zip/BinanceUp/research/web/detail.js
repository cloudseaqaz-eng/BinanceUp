"use strict";
const params=new URLSearchParams(location.search),symbol=params.get('symbol'),at=params.get('at');
let data=null,controller=null,cursor=null,charts=[];
const UW_SERVICE_MESSAGE='当前页面服务尚未载入UW接口。请停止旧服务后，重新执行 python -m research --root research_data serve，再强制刷新页面。';
const colors=['#62b0ff','#f5c65b','#2ed3a1','#cc92ff'];
const definitions=[
 {id:'candles',title:'现货 K 线 · 绿涨红跌',keys:[],group:'always'},
 {id:'activation',title:'活跃状态转折 · 有成交分钟',keys:[],group:'core',percent:true,note:'从分钟事件直接平滑：快线半衰期5分钟，慢线30分钟；虚线为此前24小时发生率（截至当前时点前30分钟）。上影出现率与UW3零值占比口径不同。缺口后重新预热180分钟。初步/持续变化为待验证观察规则，不代表上涨概率。'},
 {id:'continuity',title:'交易连续性 · 有成交分钟占比',keys:[['continuity5','最近5分钟'],['continuity15','最近15分钟'],['continuity60','最近60分钟']],group:'core',percent:true,note:'有成交分钟数 ÷ 窗口分钟数。100%表示每分钟都有成交；只衡量连续性，不代表成交金额大。缺失分钟使对应窗口留空。'},
 {id:'buy-continuity',title:'主动买入交易连续性 · 有主动买入分钟占比',keys:[['buy_continuity5','最近5分钟'],['buy_continuity15','最近15分钟'],['buy_continuity60','最近60分钟']],group:'core',percent:true,note:'窗口内主动买入成交额（USDT）>0的分钟数 ÷ 窗口分钟数。100%表示每分钟均有主动买入；一笔微小买入也计为活跃，不代表买方占优或持续净买入。缺失/非法数据使窗口留空。'},
 {id:'uw-zero',title:'UW3零值占比 · 最近60分钟',keys:[['uw_zero60','UW3零值占比',{color:'#62b0ff',width:2.2}]],group:'uw',percent:true,smooth:'zero',note:'窗口内UW3为0的样本占比。下降表示连续3分钟无上影的状态减少；零值也可能来自平价K线或收在最高价的趋势行情。窗口数据不完整时留空。'},
 {id:'uw-smooth',title:'整体上影压力 · 最近60分钟',keys:[['uw_pressure60','上影压力60',{color:'#f5c65b',width:2.2}]],group:'uw',percent:true,smooth:'pressure',note:'所选窗口内上影总长 ÷ 振幅总和，按振幅加权；不是压力15的均值，也不直接代表买卖力量。全平价或缺失窗口留空。'},
 {id:'uw-pressure',title:'上影压力 · UW3 与15分钟加权压力',keys:[['uw_raw3','原始UW3',{color:'#8e9dad',width:1,alpha:.55}],['uw_pressure15','上影压力15',{color:'#f5c65b',width:2.2}]],group:'uw',percent:true,note:'灰线：一分钟K线重算的UW3。黄线：15分钟上影长度之和 ÷ 振幅之和，降低微小K线的干扰。0表示该窗口没有上影，不等于没有交易；完全无波动或数据缺失时黄线留空。数值高表示上冲后的回落占比较大。'},
 {id:'amount',title:'成交额与主动买入成交额 · USDT',keys:[['quote','成交额'],['taker_quote','主动买入额']],group:'flow'},
 {id:'count',title:'成交笔数',keys:[['trades','笔数']],group:'flow'},
 {id:'volume',title:'量能与笔数放大 · 倍数',keys:[['rvol15','RVOL15'],['tcr15','TCR15'],['rvol5','RVOL5']],group:'core'},
 {id:'buy',title:'主动买入占比',keys:[['tbr15','TBR15'],['tbr5','TBR5'],['tbr30','TBR30']],group:'core'},
 {id:'compress',title:'压缩度 · 布林带宽历史分位',keys:[['bbw_pct','BBW分位'],['squeeze','Keltner压缩']],group:'core'},
 {id:'breakout',title:'距前高 · ATR单位',keys:[['bo1h','BO1h'],['bo4h','BO4h']],group:'core'},
 {id:'oi',title:'持仓量 OI · 币数量（评分使用）',keys:[['oi','OI币数量']],group:'core',oi:true},
 {id:'oiusd',title:'持仓量 OI · 美元计（仅辅助观察）',keys:[['oi_usdt','OI USDT']],group:'flow',oi:true},
 {id:'zoi',title:'OI 异常 · zOI15',keys:[['zoi15','zOI15']],group:'core',oi:true},
 {id:'relative',title:'相对强度 · zres30',keys:[['zres30','zres30']],group:'core'},
 {id:'cvd',title:'滚动4小时净主动买入 CVD · USDT',keys:[['cvd','CVD']],group:'flow'},
 {id:'div',title:'CVD 背离与净流入强度',keys:[['div','DIV'],['nfn5','NFn5']],group:'core'},
 {id:'returns',title:'价格变化 · 比例',keys:[['r60','1h涨幅'],['r1440','24h涨幅'],['dd24','距24h低点涨幅']],group:'price'},
 {id:'zr',title:'标准化价格异动',keys:[['zr5','z_r5'],['zr15','z_r15']],group:'price'},
 {id:'structure',title:'价格结构 · ER10 与 POS4h',keys:[['er10','ER10'],['pos4h','POS4h']],group:'price'},
 {id:'vwap',title:'VWAP偏离',keys:[['vwap_dev','偏离比例']],group:'price'},
 {id:'market',title:'市场上涨广度与波动分位',keys:[['breadth15','15m上涨广度'],['btc_vol_pct','BTC波动分位']],group:'price'},
 {id:'funding',title:'归一化8小时资金费率',keys:[['funding8h','资金费率']],group:'flow'}
];
function valueText(def,v,d=2){return def.percent?pct(v):num(v,d)}
function uwWindow(){return Number($('#uw-window')?.value||60)}
function uwReadout(def,row){
 if(def.id==='activation')return activationReadout(row);
 if(!def.smooth)return '';
 const n=uwWindow(),delta=row['uw_'+def.smooth+'_delta'+n];
 return ' · 有效UW3覆盖 '+pct(row['uw_coverage'+n])+' · 较此前24h '+(finite(delta)?(delta>0?'+':'')+num(delta*100,2)+'个百分点':'—（基线不足）');
}
function activationKind(){return $('#activation-kind')?.value||'trade'}
function activationReadout(row){
 const k='activation_'+activationKind()+'_',delta=row[k+'delta'],state=row[k+'state'];
 return ' · 偏离基线 '+(finite(delta)?(delta>0?'+':'')+num(delta*100,2)+'个百分点':'—')+' · '+(['背景稳定','初步变化','持续变化'][state]||'历史不足/缺口')+' · 连续异常 '+num(row[k+'run'],0)+'分钟';
}
function setupCharts(){
 const mode=$('#group').value;
 const kind=activationKind(),a=definitions.find(d=>d.id==='activation');
 a.title='活跃状态转折 · '+({trade:'有成交分钟',buy:'有主动买入分钟',wick:'上影出现率'}[kind]);
 a.keys=[['activation_'+kind+'_fast','快线 · 半衰期5m',{color:'#62b0ff',width:1.8}],['activation_'+kind+'_slow','慢线 · 半衰期30m',{color:'#f5c65b',width:2.2}],['activation_'+kind+'_base','此前24h基线',{color:'#8e9dad',dash:[5,4],width:1.5}]];

 for(const d of definitions)if(d.smooth){
  const n=uwWindow(),label=d.smooth==='zero'?'UW3零值占比':'上影压力'+n;
  d.title=(d.smooth==='zero'?'UW3零值占比':'整体上影压力')+' · 最近'+n+'分钟';
  d.keys=[[('uw_'+d.smooth+n),label,{color:d.smooth==='zero'?'#62b0ff':'#f5c65b',width:2.2}]];
 }
 charts=definitions.filter(d=>d.group==='always'||mode==='all'||d.group===mode||(mode==='flow'&&['buy-continuity','activation'].includes(d.id))||(['core','price'].includes(mode)&&d.group==='uw'));
 charts=charts.filter(d=>d.id!=='uw-pressure'||$('#uw-raw')?.checked);
 $('#charts').innerHTML=charts.map(d=>`<section class="chart-card ${d.id==='candles'?'candles':''} ${d.group==='uw'?'uw-card':''}">
 <div class="chart-head"><h2>${esc(d.title)}</h2><div class="legend">${d.keys.map((k,i)=>`<span style="color:${k[2]?.color||colors[i]}">${esc(k[1])}</span>`).join('')}</div></div>
 <div id="read-${d.id}" class="readout">移动鼠标查看同一时刻数据</div><canvas id="chart-${d.id}" aria-label="${esc(d.title)}"></canvas>
 ${d.note||d.oi?`<p class="chart-note muted">${esc(d.id==='activation'&&!data.activation_series.length?'当前服务未提供状态观察数据，请覆盖完整research目录并重启serve后刷新。':d.id==='buy-continuity'&&!data.candles.some(r=>'buy_continuity5' in r)?'当前服务未提供主动买入连续性，请覆盖完整research目录并重启serve后刷新。':d.oi?'评分时点：'+data.oi_status.message:d.note)}</p>`:''}</section>`).join('');
 for(const def of charts){
  const canvas=$('#chart-'+def.id);
  canvas.addEventListener('mousemove',e=>hover(e,def));
  canvas.addEventListener('mouseleave',()=>{cursor=null;$('#tooltip').classList.add('hidden');drawAll()});
 }
 drawAll();
}
function geometry(canvas){
 const rect=canvas.getBoundingClientRect(),dpr=devicePixelRatio||1,w=rect.width,h=rect.height;
 canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);
 const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);
 return {ctx,w,h,left:12,right:76,top:12,bottom:28,start:new Date(data.start).getTime(),end:new Date(data.end).getTime()};
}
function draw(def){
 const canvas=$('#chart-'+def.id);if(!canvas||!data)return;
 const {ctx,w,h,left,right,top,bottom,start,end}=geometry(canvas);
 const rows=def.id==='activation'?data.activation_series:def.group==='uw'?data.uw_series:data.candles,cadence=(def.id==='activation'||def.group==='uw')?60000:data.period*60000;
 const x=t=>left+(t-start)/(end-start)*(w-left-right);
 let values=[];
 if(def.id==='candles'){for(const r of rows){if(finite(r.high)&&finite(r.low))values.push(r.high,r.low)}}
 else for(const r of rows)for(const [k] of def.keys)if(finite(r[k]))values.push(r[k]);
 let lo=Infinity,hi=-Infinity;for(const v of values){if(v<lo)lo=v;if(v>hi)hi=v}
 if(!values.length){lo=0;hi=1}
 const pad=(hi-lo||Math.abs(hi)*.01||1)*.08;lo-=pad;hi+=pad;
 if(def.percent){lo=0;hi=1}if(def.id==='zoi'){lo=-4.5;hi=4.5}
 const y=v=>top+(hi-v)/(hi-lo)*(h-top-bottom);
 ctx.font='11px system-ui';ctx.fillStyle='#8fa4bd';ctx.strokeStyle='#243448';ctx.lineWidth=1;
 for(let i=0;i<4;i++){
  const yy=top+i/3*(h-top-bottom),v=hi-i/3*(hi-lo);
  ctx.beginPath();ctx.moveTo(left,yy);ctx.lineTo(w-right,yy);ctx.stroke();
  ctx.fillText(def.percent?pct(v,0):num(v,hi-lo<1?5:2),w-right+8,yy+4);
 }
 for(let i=0;i<4;i++){
  const t=start+(end-start)*i/3;
  const text=new Date(t).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false});
  ctx.textAlign=i===0?'left':i===3?'right':'center';ctx.fillText(text,x(t),h-7);
 }
 ctx.textAlign='left';ctx.save();ctx.beginPath();ctx.rect(left,top,w-left-right,h-top-bottom);ctx.clip();
 if(def.id==='candles'){
  const cw=Math.max(.6,Math.min(8,(w-left-right)/Math.max(rows.length,1)*.7));
  for(const r of rows){
   if(!finite(r.close)||!finite(r.open))continue;
   ctx.strokeStyle=ctx.fillStyle=r.close>=r.open?'#2ed3a1':'#ff6178';ctx.beginPath();ctx.moveTo(x(r.ms),y(r.high));ctx.lineTo(x(r.ms),y(r.low));ctx.stroke();
   ctx.fillRect(x(r.ms)-cw/2,Math.min(y(r.open),y(r.close)),cw,Math.max(1,Math.abs(y(r.open)-y(r.close))));
  }
 }else{
  def.keys.forEach(([key,label,options={}],i)=>{
   ctx.save();ctx.strokeStyle=ctx.fillStyle=options.color||colors[i];ctx.lineWidth=options.width||1.4;ctx.globalAlpha=options.alpha??1;ctx.setLineDash(options.dash||[]);
   if(options.type==='bars'){
    const bw=Math.max(.6,Math.min(4,(w-left-right)/Math.max(rows.length,1)*.7));
    for(const r of rows)if(finite(r[key]))ctx.fillRect(x(r.ms)-bw/2,y(r[key]),bw,Math.max(1,y(0)-y(r[key])));
   }else{
    ctx.beginPath();let connected=false,last=null;
    for(const r of rows){
     if(!finite(r[key])){connected=false;continue}
     if(last!==null&&r.ms-last>cadence*1.5)connected=false;
     if(connected)ctx.lineTo(x(r.ms),y(r[key]));else ctx.moveTo(x(r.ms),y(r[key]));
     connected=true;last=r.ms;
    }
    ctx.stroke();
   }
   ctx.restore();
  });
 }
 ctx.setLineDash([5,4]);ctx.strokeStyle='#65acff';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x(new Date(data.at).getTime()),top);ctx.lineTo(x(new Date(data.at).getTime()),h-bottom);ctx.stroke();
 if(cursor!==null){ctx.strokeStyle='#bfd0e6';ctx.beginPath();ctx.moveTo(x(cursor),top);ctx.lineTo(x(cursor),h-bottom);ctx.stroke()}
 ctx.restore();
 if(!values.length){ctx.fillStyle='#90a2b8';ctx.fillText('该窗口无可用数据 / 尚未完成预热',left+20,top+30)}
 const row=cursor!==null?nearest(cursor):null;
 $('#read-'+def.id).textContent=row?(fmtTime(row.ms)+' · '+(def.id==='candles'?`O ${num(row.open,7)}  H ${num(row.high,7)}  L ${num(row.low,7)}  C ${num(row.close,7)}  Change ${finite(row.open)&&finite(row.close)?pct(row.close/row.open-1,2):'—'}`:def.keys.map(([k,label])=>label+' '+valueText(def,row[k],5)).join(' · ')+uwReadout(def,row))):'评分时刻：'+fmtTime(data.at);
}
function nearest(t){
 if(!data.candles.length)return null;
 let lo=0,hi=data.candles.length-1;
 while(lo<hi){const m=(lo+hi)>>1;if(data.candles[m].ms<t)lo=m+1;else hi=m}
 if(lo>0&&Math.abs(data.candles[lo-1].ms-t)<Math.abs(data.candles[lo].ms-t))lo--;
 const r=data.candles[lo];return Math.abs(r.ms-t)<=data.period*60000?r:null;
}
function hover(e,def){
 const rect=e.currentTarget.getBoundingClientRect(),xx=e.clientX-rect.left;
 const t=new Date(data.start).getTime()+Math.max(0,Math.min(1,(xx-12)/(rect.width-88)))*(new Date(data.end)-new Date(data.start));
 const row=nearest(t);cursor=row?row.ms:t;drawAll();const tip=$('#tooltip');
 if(!row){tip.classList.add('hidden');return}
 tip.textContent=fmtTime(row.ms)+'（北京时间）'+(def.id==='candles'?`\nO ${num(row.open,7)}  H ${num(row.high,7)}\nL ${num(row.low,7)}  C ${num(row.close,7)}\nChange ${finite(row.open)&&finite(row.close)?pct(row.close/row.open-1,2):'—'}`:'\n'+def.keys.map(([k,label])=>label+': '+valueText(def,row[k],6)).join('\n')+uwReadout(def,row));
 tip.style.whiteSpace='pre-line';tip.classList.remove('hidden');
 tip.style.left=Math.max(8,Math.min(e.clientX+14,innerWidth-tip.offsetWidth-10))+'px';tip.style.top=Math.max(8,Math.min(e.clientY+12,innerHeight-tip.offsetHeight-10))+'px';
}
function drawAll(){charts.forEach(draw)}
function summary(){
 const r=data.snapshot;
 if($('#oi-note'))$('#oi-note').textContent=data.oi_status.message;
 if($('#context-note'))$('#context-note').textContent=data.context_note+(data.model_message?' '+data.model_message:'');
 $('#title').textContent=symbol+' · 评分详情';$('#subtitle').textContent=fmtTime(data.at)+' 北京时间';$('#back').href='/?at='+encodeURIComponent(at);
 if(!r){$('#summary').textContent='该分钟没有评分记录';return}
 $('#summary').innerHTML=[['Setup评分',num(r.score,1)],['24h上榜概率',pct(r.probability)],['当前榜单名次',num(r.rank24,0)],['24h涨幅',pct(r.r1440)],['近期活跃状态',r.activity_label||'未提供'],['沉寂时长',typeof quietText==='function'?quietText(r):'未提供'],['交易连续性15',pct(r.continuity15)],['近7日最大24h上冲',pct(r.runup7d)],['OI输入',data.oi_status.label],['权重版本',data.model?data.model.id:'PDF默认']].map(([k,v])=>`<div class="kv"><span class="muted">${k}</span><b>${v}</b></div>`).join('')+`<p class="muted">${esc((r.reasons||[]).join('；')||'基础过滤通过')}</p>`;
 const effective=data.weights.reduce((s,w,i)=>s+(finite(r[data.components[i]])?w:0),0);
 $('#weights').innerHTML='<h2>评分分项</h2>'+data.components.map((k,i)=>`<div class="weight"><div class="kv"><span>${esc(data.component_labels[i])}</span><span>${num(r[k],2)} × ${pct(finite(r[k])?data.weights[i]/effective:null,1)}</span></div><div class="bar"><span style="width:${finite(r[k])?r[k]*100:0}%"></span></div></div>`).join('');
 $('#future-result').classList.toggle('hidden',$('#after').value==='0');
 $('#future-result').textContent='事后结果：'+(r.target===1?'首次进入前10，'+num(r.first_hit_minutes,0)+'分钟后':r.target===0?'未来24h未进入前10':'未知（未来数据不全或当前已在前10）');
}
async function load(){
 if(controller)controller.abort();controller=new AbortController();$('#reload').disabled=true;
 try{
  const q=new URLSearchParams({symbol,at,before:$('#before').value,after:$('#after').value,period:$('#period').value});
  data=await api('/api/detail?'+q,controller.signal);cursor=null;
  const uwReady=Array.isArray(data.uw_series)&&data.uw_current&&('uw_zero60' in data.uw_current);
  if(!uwReady){data.uw_series=[];data.uw_events=[];data.uw_regions=[];data.uw_current={};data.uw_note=UW_SERVICE_MESSAGE}
  data.oi_status??={label:'诊断未提供',message:'当前服务未提供OI诊断；更新后重启服务可查看。'};
  data.context_note??='';
  data.activation_series??=[];
  notice(uwReady?scopeText(data.universe_scope)+' · '+data.note:UW_SERVICE_MESSAGE,!uwReady||data.universe_scope!=='historical_archive'?'warn':'');summary();setupCharts();
 }catch(e){if(e.name!=='AbortError')notice(e.message,'error')}finally{$('#reload').disabled=false}
}
function initialize(){
 const required=['before','after','period','group','reload','charts','tooltip','title','subtitle','back','summary','weights','future-result','notice'];
 const missing=required.filter(id=>!$('#'+id));
 if(missing.length){
  const message='详情页结构不完整，请覆盖更新 research/web/detail.html 后强制刷新页面。缺少：'+missing.join('、');
  if($('#notice'))notice(message,'error');else console.error(message);
  return;
 }
 // Keep older HTML usable and remove its retired UW change-marker control.
 const group=$('#group');
 if(!Array.from(group.options).some(o=>o.value==='uw'))group.add(new Option('UW观察（含K线）','uw'));
 const retired=$('#uw-markers');
 if(retired)(retired.closest('label')||retired).remove();
 // Restore optional new controls when cached HTML predates smoothing.
 if(!$('#uw-window')){
  const label=document.createElement('label');label.innerHTML='UW平滑窗口<select id="uw-window"><option value="30">30分钟</option><option value="60" selected>60分钟</option><option value="120">120分钟</option></select>';
  $('#reload').before(label);
 }
 if(!$('#uw-raw')){
  const label=document.createElement('label');label.innerHTML='<input id="uw-raw" type="checkbox">展开原始UW3／压力15';
  $('#reload').before(label);
 }
 if(!$('#activation-kind')){
  const label=document.createElement('label');label.innerHTML='状态观察<select id="activation-kind"><option value="trade">成交出现率</option><option value="buy">主动买入出现率</option><option value="wick">上影出现率</option></select>';
  $('#reload').before(label);
 }
 $('#activation-kind').addEventListener('change',setupCharts);
 $('#uw-window').addEventListener('change',setupCharts);
 $('#uw-raw').addEventListener('change',setupCharts);
 for(const id of ['before','after','period'])$('#'+id).addEventListener('change',load);
 group.addEventListener('change',setupCharts);$('#reload').addEventListener('click',load);
 if(['core','flow','price','all','uw'].includes(params.get('group')))group.value=params.get('group');
 let timer;window.addEventListener('resize',()=>{clearTimeout(timer);timer=setTimeout(drawAll,100)});
 if(symbol&&at)load();else notice('链接缺少交易对或评分时间，请从排名列表打开。','error');
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize,{once:true});else initialize();
