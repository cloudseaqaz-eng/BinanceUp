"use strict";
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const finite=v=>typeof v==='number'&&Number.isFinite(v);
const num=(v,d=2)=>finite(v)?v.toLocaleString('zh-CN',{maximumFractionDigits:d}):'—';
const pct=(v,d=1)=>finite(v)?(v*100).toFixed(d)+'%':'—';
const fmtTime=v=>v?new Date(v).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false}):'—';
const toInput=iso=>new Date(new Date(iso).getTime()+8*3600000).toISOString().slice(0,16);
const fromInput=v=>{if(!v)throw Error('请输入日期时间');return new Date(v+':00+08:00').toISOString()};
async function api(path,signal){const r=await fetch(path,{signal});const d=await r.json();if(!r.ok||d.error)throw Error(d.error||'请求失败');return d}
function notice(text,type=''){const n=$('#notice');n.textContent=text;n.className='notice '+type}
const scopeText=s=>s==='historical_archive'?'历史归档全市场近似':s==='synthetic_demo'?'模拟数据演示 · 不代表真实预测':'指定币种子市场 · 不代表币安全榜';
