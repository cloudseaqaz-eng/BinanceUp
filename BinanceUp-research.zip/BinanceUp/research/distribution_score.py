"""Causal distribution scores of five-minute trade/buy continuity."""
import numpy as np
import pandas as pd

WINDOWS = (15, 30)


def score_points(points, window):
    """points is the 0..5 count underlying C5; require a complete time window."""
    counts = [points.eq(k).astype(float).where(points.notna()).rolling(window, min_periods=window).sum()
              for k in range(6)]
    remaining = pd.Series(window*.2, index=points.index)
    lower_sum = pd.Series(0., index=points.index)
    for k, count in enumerate(counts):
        take = np.minimum(count, remaining)
        lower_sum += take*k
        remaining -= take
    mean = points.rolling(window, min_periods=window).mean()/5
    lower = lower_sum/(window*.2)/5
    return pd.DataFrame({"score":100*(.7*mean+.3*lower), "mean":mean,
        "lower":lower, "lowshare":(counts[0]+counts[1])/window,
        "highshare":(counts[4]+counts[5])/window}, index=points.index)


def metrics(raw):
    raw = raw.sort_index().reindex(pd.date_range(raw.index.min(), raw.index.max(), freq="min", name="time"))
    result = pd.DataFrame(index=raw.index)
    for kind, column in (("trade", "trades"), ("buy", "taker_quote")):
        value = raw[column]
        active = value.gt(0).astype(float).where(np.isfinite(value) & value.ge(0))
        points = active.rolling(5, min_periods=5).sum()
        result[f"dist_{kind}_c5"] = points/5
        for window in WINDOWS:
            scored = score_points(points, window)
            scored.columns = [f"dist_{kind}_{name}{window}" for name in scored.columns]
            result = result.join(scored)
    return result
