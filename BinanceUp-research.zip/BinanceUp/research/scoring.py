import numpy as np
import pandas as pd
from .config import COMPONENTS, PDF_WEIGHTS, utc
from .storage import read_frame


def scores(frame, weights=PDF_WEIGHTS):
    u = frame[COMPONENTS].to_numpy(dtype=float)
    w = np.asarray(weights, dtype=float)
    if w.shape != (8,) or np.any(w < 0) or not np.isclose(w.sum(), 1):
        raise ValueError("八项评分权重必须非负且和为1")
    available = np.isfinite(u)
    # Only OI is optional; seven other missing components make score unavailable.
    denominator = available @ w
    numerator = np.nan_to_num(u) @ w
    s = np.divide(numerator, denominator, out=np.full(len(frame), np.nan), where=denominator > 1e-12)*100
    s[~available[:, [0, 1, 2, 3, 4, 5, 7]].all(axis=1)] = np.nan
    penalty = frame.penalty.to_numpy(dtype=float)
    s *= penalty
    if "risk_off" in frame:
        s *= ~frame.risk_off.fillna(True).to_numpy(dtype=bool)
    return s


def eligible(frame, cfg):
    return (frame.feature_ready.fillna(False) & frame.history_complete.fillna(False)
            & (frame.q1440 >= cfg.min_quote24) & (frame.zero1440 <= .05)
            & (frame.age_days_lower_bound >= 7) & frame.board_valid.fillna(False)
            & (frame.rank24 > cfg.top_n) & frame.btc_vol_pct.notna() & frame.btc_zr5.notna())


def parquet_slice(path, start=None, end=None, columns=None):
    return read_frame(path, start, end, columns)


def load_panel(cfg, start=None, end=None, step=None, columns=None):
    """One row per (closed minute,symbol); no duplicated cross-section rows."""
    start = utc(start or cfg.start)
    end = utc(end or cfg.end)
    market = parquet_slice(cfg.path / "market.parquet", start, end)
    step = step or cfg.sample_minutes
    keep = (market.index.asi8 // (60*10**9)) % step == 0
    market = market.loc[keep]
    frames = []
    cols = columns or COMPONENTS + ["penalty", "feature_ready", "history_complete", "q1440", "zero1440", "age_days_lower_bound", "oi_available", "close", "r60", "r1440", "rvol15", "tcr15", "tbr15", "zres30", "zoi15", "div", "bbw_pct", "bo1h", "wash", "late", "valid", "zf"]
    for symbol in sorted(cfg.symbols):
        path = cfg.path / "features" / f"{symbol}.parquet"
        lp = cfg.path / "labels" / f"{symbol}.parquet"
        if not path.exists() or not lp.exists():
            continue
        f = parquet_slice(path, start, end, cols).reindex(market.index)
        lab = parquet_slice(lp, start, end).reindex(market.index)
        f = f.join(market).join(lab)
        f["symbol"] = symbol
        f["eligible"] = eligible(f, cfg)
        f["pdf_score"] = scores(f)
        frames.append(f)
    if not frames:
        raise ValueError("没有可用特征；先执行 features 和 labels")
    return pd.concat(frames).reset_index().sort_values(["time", "symbol"]).reset_index(drop=True)


def select_top(frame, score_column="score", k=10, threshold=55):
    valid = frame.loc[frame.eligible & (frame[score_column] >= threshold)]
    return valid.sort_values(["time", score_column, "symbol"], ascending=[True, False, True]).groupby("time", sort=False).head(k)


def pool_entries(frame, score_column="score", cfg=None, state=None, return_state=False):
    """Stateful slow pool, scores supplied at configured cadence.

    Cooldown applies after every exit. Hard invalidation/current top-N exits immediately;
    scores <40 exit after 3 observed cycles; 60 minute residence cap.
    """
    # Preserve true entry/cooldown phases across model updates. A short arbitrary
    # warmup cannot reconstruct the phase of continuously qualified candidates.
    pool = {k: dict(v) for k, v in (state or {}).get("pool", {}).items()}
    cooldown = dict((state or {}).get("cooldown", {}))
    entries = []
    for t, group in frame.groupby("time", sort=True):
        rowmap = {r.symbol: r for r in group.itertuples()}
        for symbol in list(pool):
            row = rowmap.get(symbol)
            state = pool[symbol]
            score = getattr(row, score_column, np.nan) if row else np.nan
            invalid = row is None or not row.eligible or not np.isfinite(score) or row.penalty == 0 or row.risk_off
            state["low"] = state["low"]+1 if score < 40 else 0
            if invalid or state["low"] >= 3 or t-state["entered"] >= pd.Timedelta(minutes=60):
                del pool[symbol]
                cooldown[symbol] = t+pd.Timedelta(minutes=15)
        entrants = group.loc[group.eligible & (group[score_column] >= cfg.min_score)].sort_values([score_column, "symbol"], ascending=[False, True])
        for row in entrants.itertuples():
            if len(pool) >= cfg.pool_size:
                break
            if row.symbol in pool or t < cooldown.get(row.symbol, t):
                continue
            pool[row.symbol] = {"entered": t, "low": 0}
            entries.append(row.Index)
    result = frame.loc[entries].copy()
    if return_state:
        return result, {"pool": pool, "cooldown": cooldown}
    return result
