"""Causal descriptive activity context. Kept separate from fitted scoring inputs."""
from pathlib import Path
import json
from collections import defaultdict
from threading import RLock
import numpy as np
import pandas as pd
from .config import utc, json_write
from .storage import read_frame, write_frame, source_digest

VERSION = 1
_LOCKS = defaultdict(RLock)
STATE_NAMES = {0: "历史不足/缺口", 1: "长期沉寂", 2: "低活跃/沉寂中",
               3: "沉寂后激活", 4: "近期活跃", 5: "常态交易", 6: "近期拉升过"}
CONTEXT_NOTE = ("描述性规则，尚未训练分行情权重。背景截至评分前30分钟的最后整点；"
                "72小时状态、7天拉升记忆、此前14天基线。沉寂需连续至少6小时，长期沉寂至少72小时；"
                "缺口中断计时，≥表示起点未完整观察。近期拉升标记采用初始研究阈值。")


def continuity(raw):
    # A missing observation is not a zero-trade minute.
    if len(raw):
        raw = raw.reindex(pd.date_range(raw.index.min(), raw.index.max(), freq="min", name="time"))
    active = raw.trades.gt(0).astype(float).where(raw.trades.notna())
    return pd.DataFrame({f"continuity{w}": active.rolling(w, min_periods=w).mean()
                         for w in (5, 15, 60)}, index=raw.index)



def buy_continuity(raw):
    """Fraction of closed minutes with taker-buy quote > 0, not trade counts."""
    raw = raw.sort_index()
    if len(raw):
        raw = raw.reindex(pd.date_range(raw.index.min(), raw.index.max(), freq="min", name="time"))
    amount = raw.taker_quote
    valid = np.isfinite(amount) & amount.ge(0)
    active = amount.gt(0).astype(float).where(valid)
    return pd.DataFrame({f"buy_continuity{w}": active.rolling(w, min_periods=w).mean()
                         for w in (5, 15, 60)}, index=raw.index)


def hourly_context(raw):
    """Closed hourly context, released 30 min later; no event/future labels used."""
    raw = raw.sort_index()
    raw = raw.reindex(pd.date_range(raw.index.min(), raw.index.max(), freq="min", name="time"))
    groups = raw.resample("1h", closed="right", label="right")
    h = groups.agg({"quote": "sum", "trades": "sum", "close": "last", "high": "max", "low": "min"})
    complete = groups[["quote", "trades", "close", "high", "low"]].count().eq(60).all(axis=1)
    h = h.loc[h.index <= raw.index.max()].copy()
    h.loc[~complete.reindex(h.index)] = np.nan
    valid = h.notna().all(axis=1)
    bq = h.quote.shift().rolling(336, min_periods=336).median()
    bn = h.trades.shift().rolling(336, min_periods=336).median()
    qr = h.quote/bq.replace(0, np.nan)
    nr = h.trades/bn.replace(0, np.nan)
    spread = h.high/h.low-1
    quiet = valid & (((h.quote <= 20_000) & (h.trades <= 120) & (spread <= .02)) |
                     ((qr <= .5) & (nr <= .5) & (spread <= .01)))
    # Absolute floor avoids calling a handful of tiny trades an activation.
    active = valid & (h.quote >= 20_000) & (h.trades >= 120) & (
        ((qr >= 2) & (nr >= 2)) | ((bq.eq(0) | bn.eq(0)) & bq.notna() & bn.notna()))
    active_share = active.astype(float).where(valid).rolling(72, min_periods=72).mean()
    range72 = h.high.rolling(72, min_periods=72).max()/h.low.rolling(72, min_periods=72).min()-1
    runup = h.close/h.close.rolling(24, min_periods=24).min()-1
    # A historical event retains its original prior-low reference.
    pumps = {w: runup.rolling(w, min_periods=w).max() for w in (24, 72, 168)}
    rows = []
    run, left_censored = 0, True
    last_activation, prior_quiet, prior_censored, last_active = None, np.nan, False, None
    for i, t in enumerate(h.index):
        if not valid.iloc[i]:
            run, left_censored = 0, True
            last_activation, prior_quiet, last_active = None, np.nan, None
        elif quiet.iloc[i]:
            run += 1
        else:
            if run >= 6:
                # First departure from a quiet stretch. Still a descriptive
                # transition, not a claim that a pump has or will occur.
                last_activation, prior_quiet, prior_censored = t, run, left_censored
            run, left_censored = 0, False
        if active.iloc[i]:
            last_active = t
        age = (t-last_active).total_seconds()/3600 if last_active is not None else np.nan
        activation_age = (t-last_activation).total_seconds()/3600 if last_activation is not None else np.inf
        state = 0
        ready = valid.iloc[i] and pd.notna(active_share.iloc[i]) and pd.notna(bq.iloc[i])
        pumped = ((pumps[24].iloc[i] >= .15) or (pumps[72].iloc[i] >= .20) or (pumps[168].iloc[i] >= .30))
        duration, censored, kind = np.nan, False, 0
        if run >= 6:
            duration, censored, kind = run, left_censored, 1
        elif activation_age <= 72:
            duration, censored, kind = prior_quiet, prior_censored, 2
        if ready:
            if pumped:
                state = 6
            elif run >= 72 and range72.iloc[i] <= .08:
                state = 1
            elif run >= 6:
                state = 2
            elif activation_age <= 24:
                state = 3
            elif (pd.notna(age) and age <= 72) or active_share.iloc[i] >= .1:
                state = 4
            else:
                state = 5
        rows.append({"activity_state": state, "quiet_hours": duration,
                     "quiet_lower_bound": censored, "quiet_kind": kind,
                     "active_share72": active_share.iloc[i], "last_active_hours": age,
                     "runup7d": pumps[168].iloc[i], "background_at_ms": t.value//10**6})
    result = pd.DataFrame(rows, index=h.index+pd.Timedelta(minutes=30))
    result.index.name = "time"
    return result


def context_frame(cfg, symbol):
    with _LOCKS[str(cfg.path/"raw"/f"{symbol}.parquet")]:
        return _context_frame(cfg, symbol)


def _context_frame(cfg, symbol):
    """Small hourly cache invalidated by logical raw fingerprint + rule version."""
    source = cfg.path/"raw"/f"{symbol}.parquet"
    target = cfg.path/"context"/f"{symbol}.parquet"
    manifest = target.with_suffix(".json")
    identity = {"version": VERSION, "raw_sha256": source_digest(source)}
    if target.exists() and manifest.exists() and json.loads(manifest.read_text()) == identity:
        return read_frame(target)
    raw = read_frame(source, columns=["quote", "trades", "close", "high", "low"])
    frame = hourly_context(raw)
    write_frame(frame, target)
    json_write(manifest, identity)
    return frame


def activity_at(cfg, symbol, at):
    at = utc(at)
    context = context_frame(cfg, symbol).loc[:at].tail(1)
    result = context.iloc[0].to_dict() if len(context) else {"activity_state": 0}
    code = int(result["activity_state"])
    result["activity_label"] = STATE_NAMES[code]
    raw = read_frame(cfg.path/"raw"/f"{symbol}.parquet", at-pd.Timedelta(minutes=59), at, columns=["trades"])
    raw = raw.reindex(pd.date_range(at-pd.Timedelta(minutes=59), at, freq="min", name="time"))
    result.update(continuity(raw).iloc[-1].to_dict())
    return result


def build_context(cfg):
    for symbol in sorted(set(cfg.symbols) | {"BTCUSDT"}):
        if (cfg.path/"raw"/f"{symbol}.parquet").exists():
            frame = context_frame(cfg, symbol)
            print("context", symbol, len(frame), "小时背景点", flush=True)
