"""Purged chronological weight search and held-out probability calibration."""
from pathlib import Path
from dataclasses import asdict
from hashlib import sha256
import json
import numpy as np
import pandas as pd
from sklearn.isotonic import IsotonicRegression
from .config import COMPONENTS, PDF_WEIGHTS, json_write, utc
from .scoring import load_panel, pool_entries, scores, select_top
from .storage import write_frame


def search_weights(train, validation, cfg):
    """Coarse training search -> shortlist -> validation. No test/calibration labels used."""
    rng = np.random.default_rng(cfg.seed)
    candidates = [np.asarray(PDF_WEIGHTS), np.ones(8)/8]
    # Include leave-one-component-out ablations in the same fixed search budget.
    for i in range(8):
        w = np.array(PDF_WEIGHTS)
        w[i] = 0
        candidates.append(w/w.sum())
    for i in range(max(0, cfg.trials-len(candidates))):
        candidates.append(rng.dirichlet(np.asarray(PDF_WEIGHTS)*40 if i % 2 else np.ones(8)*2))
    # Keep optimization costs bounded; only hour-aligned cross sections enter the search.
    train = train.loc[train.eligible].copy()
    validation = validation.loc[validation.eligible].copy()
    def objective(frame, w):
        if frame.empty:
            return {"objective": -1., "precision": None, "selections": 0, "coverage": 0.}
        frame = frame.copy()
        frame["score"] = scores(frame, w)
        chosen = select_top(frame, k=cfg.top_k, threshold=cfg.min_score)
        labelled = chosen.loc[chosen.target.notna()]
        all_times = frame.time.nunique()
        coverage = chosen.time.nunique()/max(all_times, 1)
        precision = float(labelled.target.mean()) if len(labelled) else None
        # Shrink towards the eligible baseline and penalize near-abstention solutions.
        base = float(frame.target.mean()) if frame.target.notna().any() else 0
        shrunk = (labelled.target.sum()+100*base)/(len(labelled)+100)
        value = float(shrunk*np.sqrt(coverage)) if len(labelled) else -1.
        return {"objective": value, "precision": precision, "selections": len(labelled), "coverage": coverage}
    trials = [{"weights": w.tolist(), "train": objective(train, w)} for w in candidates]
    indices = sorted(range(len(trials)), key=lambda i: trials[i]["train"]["objective"], reverse=True)[:16]
    indices = sorted(set(indices) | {0})
    for i in indices:
        trials[i]["validation"] = objective(validation, candidates[i])
    best = max(indices, key=lambda i: (trials[i]["validation"]["objective"], -np.linalg.norm(candidates[i]-PDF_WEIGHTS)))
    if trials[best]["validation"]["selections"] < 50:
        best = 0
        status = "insufficient_validation_keep_pdf"
    else:
        status = "best_in_search_budget"
    return candidates[best].tolist(), {"status": status, "best_trial": best, "trials": trials,
                                      "objective": "(成功数+100×eligible基准概率)/(选中数+100) × sqrt(有选币时点占比)",
                                      "search_cadence_minutes": 60}


def fit_calibration(frame, cfg):
    calibrators = {}
    for available in (False, True):
        g = frame.loc[frame.eligible & frame.target.notna() & frame.score.notna() & frame.oi_available.eq(available)]
        if len(g):
            hits = g.loc[g.target.eq(1), ["symbol", "time", "first_hit_minutes"]].copy()
            hits["hit_at"] = hits.time+pd.to_timedelta(hits.first_hit_minutes, unit="min")
            events = len(hits.drop_duplicates(["symbol", "hit_at"]))
        else:
            events = 0
        status = "ok"
        if (len(g) < cfg.min_calibration_rows or g.time.dt.floor("D").nunique() < 7 or events < 20
                or g.target.nunique() < 2 or g.score.nunique() < 3):
            status = "insufficient_calibration"
        key = "with_oi" if available else "without_oi"
        record = {"status": status, "samples": len(g), "positive_events": events, "base_rate": float(g.target.mean()) if len(g) else None}
        if status == "ok":
            # Each timestamp receives equal total weight: busy cross sections cannot dominate.
            weights = 1/g.groupby("time").symbol.transform("size")
            iso = IsotonicRegression(out_of_bounds="clip", y_min=0, y_max=1).fit(g.score, g.target, sample_weight=weights)
            record.update(x=iso.X_thresholds_.tolist(), y=iso.y_thresholds_.tolist())
        calibrators[key] = record
    return calibrators


def probabilities(frame, calibration):
    p = np.full(len(frame), np.nan)
    for available, key in ((False, "without_oi"), (True, "with_oi")):
        cal = calibration.get(key, {})
        if cal.get("status") != "ok":
            continue
        use = frame.eligible.to_numpy(dtype=bool) & frame.oi_available.eq(available).to_numpy() & frame.score.notna().to_numpy()
        p[use] = np.interp(frame.loc[use, "score"], cal["x"], cal["y"])
    return p


def block_interval(frame, seed=7):
    """7-day moving-block bootstrap, retaining overlapping predictions within days."""
    g = frame.loc[frame.target.notna()].copy()
    if g.empty:
        return None
    daily = g.groupby(g.time.dt.floor("D")).target.agg(["sum", "count"])
    grid = pd.date_range(g.time.min().floor("D"), g.time.max().floor("D"), freq="D")
    daily = daily.reindex(grid, fill_value=0)
    if len(daily) < 14:
        return None
    rng = np.random.default_rng(seed)
    values = daily.to_numpy()
    estimates = []
    for _ in range(400):
        start = rng.integers(0, len(values)-6, size=int(np.ceil(len(values)/7)))
        ix = (start[:, None]+np.arange(7)).ravel()[:len(values)]
        total, count = values[ix].sum(axis=0)
        if count:
            estimates.append(total/count)
    return np.quantile(estimates, [.025, .975]).tolist() if estimates else None


def metrics(frame, baseline=None):
    known = frame.loc[frame.target.notna()]
    probability = known.loc[known.probability.notna()] if "probability" in known else known.iloc[:0]
    rate = float(known.target.mean()) if len(known) else None
    reliability = []
    if len(probability):
        for b in range(10):
            g = probability.loc[(probability.probability >= b/10) & ((probability.probability < (b+1)/10) if b < 9 else (probability.probability <= 1))]
            if len(g):
                reliability.append({"bin": b, "n": len(g), "predicted": float(g.probability.mean()), "actual": float(g.target.mean())})
    return {"rows": len(frame), "labelled": len(known), "censored": len(frame)-len(known),
            "successes": int(known.target.sum()), "hit_rate": rate,
            "lift": rate/baseline if baseline and rate is not None else None,
            "hit_rate_95pct_day_block": block_interval(known),
            "unique_symbols": int(frame.symbol.nunique()) if len(frame) else 0,
            "scoring_times": int(frame.time.nunique()) if len(frame) else 0,
            "first_hit_median_minutes": float(known.first_hit_minutes.median()) if known.first_hit_minutes.notna().any() else None,
            "calibrated_rows": len(probability),
            "brier": float(np.mean((probability.probability-probability.target)**2)) if len(probability) else None,
            "calibration": reliability}


def evaluate(frame, cfg, existing_pool=None):
    baseline = float(frame.loc[frame.eligible, "target"].mean()) if frame.loc[frame.eligible, "target"].notna().any() else None
    selected = select_top(frame, k=cfg.top_k, threshold=cfg.min_score)
    pool = pool_entries(frame, cfg=cfg) if existing_pool is None else existing_pool
    pdf = select_top(frame, score_column="pdf_score", k=cfg.top_k, threshold=cfg.min_score).copy()
    # A fitted-score probability must not be reported for a different PDF selection rule.
    pdf["probability"] = np.nan
    count_times = frame.time.nunique()
    result = {"eligible_baseline": baseline, "eligible": metrics(frame.loc[frame.eligible]),
              "top_k": metrics(selected, baseline), "pool_entries": metrics(pool, baseline), "pdf_top_k": metrics(pdf, baseline),
              "selected_time_coverage": selected.time.nunique()/max(count_times, 1),
              "pool_cycle_minutes": cfg.sample_minutes,
              "weekly": [], "per_symbol": []}
    for name, group in selected.groupby(selected.time.dt.strftime("%G-W%V")):
        result["weekly"].append({"week": name, **metrics(group, baseline)})
    for name, group in selected.groupby("symbol"):
        result["per_symbol"].append({"symbol": name, **metrics(group, baseline)})
    return result, selected, pool


def model_schedule(cfg):
    start = utc(cfg.start)
    last_test = utc(cfg.end)-pd.Timedelta(minutes=cfg.horizon_minutes)
    holdout_start = last_test-pd.Timedelta(days=cfg.holdout_days)
    needed = cfg.train_days+cfg.validation_days+cfg.calibration_days+3*cfg.horizon_minutes/1440
    first = start+pd.Timedelta(days=needed)
    if first > holdout_start:
        raise ValueError(f"历史区间不足。默认需要约 {needed+cfg.holdout_days+1:.0f} 天（另加预热期），短数据只能浏览，不能宣称已优化概率。")
    folds = []
    test_start = first
    while test_start < holdout_start:
        test_end = min(test_start+pd.Timedelta(days=cfg.test_days), holdout_start)
        folds.append((test_start, test_end, False))
        test_start = test_end
    folds.append((holdout_start, last_test+pd.Timedelta(minutes=cfg.sample_minutes), True))
    return folds


def train(cfg):
    folds = model_schedule(cfg)
    out = cfg.path / "results"
    out.mkdir(exist_ok=True)
    provenance = {"config": asdict(cfg), "source_hashes": {
        p.name: sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob("*.py")},
        "label_manifest_sha256": sha256((cfg.path/"label_summary.json").read_bytes()).hexdigest()}
    json_write(out / "provenance.json", provenance)
    records, all_selected, all_pool = [], [], []
    pool_state = None
    horizon = pd.Timedelta(minutes=cfg.horizon_minutes)
    # Features & labels are prepared once; each fold reads only its own chronological ranges.
    for number, (test_start, test_end, holdout) in enumerate(folds):
        cal_end = test_start-horizon
        cal_start = cal_end-pd.Timedelta(days=cfg.calibration_days)
        val_end = cal_start-horizon
        val_start = val_end-pd.Timedelta(days=cfg.validation_days)
        train_end = val_start-horizon
        train_start = train_end-pd.Timedelta(days=cfg.train_days)
        print(f"fold {number}: {'FINAL HOLDOUT' if holdout else 'walk-forward'} {test_start} -> {test_end}", flush=True)
        fitting = load_panel(cfg, train_start, train_end-pd.Timedelta(minutes=1), step=60)
        validating = load_panel(cfg, val_start, val_end-pd.Timedelta(minutes=1), step=60)
        weights, search = search_weights(fitting, validating, cfg)
        del fitting, validating
        calibrating = load_panel(cfg, cal_start, cal_end-pd.Timedelta(minutes=1))
        calibrating["score"] = scores(calibrating, weights)
        calibration = fit_calibration(calibrating, cfg)
        del calibrating
        model = {"id": f"fold_{number:02d}", "usable_from": test_start.isoformat(), "test_end": test_end.isoformat(),
                 "final_holdout": holdout, "weights": weights, "components": COMPONENTS, "calibration": calibration,
                 "ranges": {"train": [train_start.isoformat(), train_end.isoformat()], "validation": [val_start.isoformat(), val_end.isoformat()],
                            "calibration": [cal_start.isoformat(), cal_end.isoformat()], "test": [test_start.isoformat(), test_end.isoformat()]},
                 "embargo_minutes": cfg.horizon_minutes, "search_status": search["status"]}
        json_write(out / (model["id"]+".model.json"), model)
        json_write(out / (model["id"]+".search.json"), search)
        testing = load_panel(cfg, test_start, test_end-pd.Timedelta(minutes=1))
        testing["score"] = scores(testing, weights)
        testing["probability"] = probabilities(testing, calibration)
        warm_pool, pool_state = pool_entries(testing, cfg=cfg, state=pool_state, return_state=True)
        report, selected, _ = evaluate(testing, cfg, existing_pool=warm_pool)
        for f in (selected, warm_pool):
            f["fold"] = number
            f["final_holdout"] = holdout
        all_selected.append(selected)
        all_pool.append(warm_pool)
        report["model"] = model
        records.append(report)
        write_frame(selected, out / (model["id"]+".selected.parquet"))
        write_frame(warm_pool, out / (model["id"]+".pool.parquet"))
        json_write(out / (model["id"]+".report.json"), report)
        print("  topK", report["top_k"]["hit_rate"], "pool", report["pool_entries"]["hit_rate"], flush=True)
    selected = pd.concat(all_selected, ignore_index=True)
    pool = pd.concat(all_pool, ignore_index=True)
    for f, name in ((selected, "selected"), (pool, "pool_entries")):
        write_frame(f, out / (name+".parquet"))
    labels = json.loads((cfg.path / "label_summary.json").read_text())
    report = {"status": "completed", "universe_scope": cfg.universe_scope, "definition": labels["definition"],
              "coverage": labels, "oi_mode": cfg.oi_mode, "sample_minutes": cfg.sample_minutes,
              "pool_initialization": "首个样本外测试时刻空池启动；后续模型切换和最终留出测试延续真实池状态及冷却计时",
              "claim": "搜索预算内、验证区间表现最佳的权重；不是全局最优，也不是未来保证",
              "limitations": ["这是慢层研究，不含秒级快层、下单、滑点或PnL", "分钟榜单为公开数据近似，非官方逐笔实时榜单", "历史盘口、公告/监控标签/解锁时点未覆盖",
                              "available OI模式在缺失时按7项重分权重，不能等同于确认没有永续合约", "同一币多次评分相关：区间为7天块bootstrap；不能将分钟行当作独立试验",
                              "权重搜索使用小时截面，报告和候选池使用配置的评分周期；1分钟需 sample_minutes=1"],
              "walk_forward_top_k": metrics(selected.loc[~selected.final_holdout]),
              "walk_forward_pool": metrics(pool.loc[~pool.final_holdout]),
              "final_holdout": records[-1], "folds": records}
    json_write(out / "report.json", report)
    model_index = [r["model"] for r in records]
    json_write(out / "models.json", model_index)
    return report


def choose_model(cfg, at):
    path = cfg.path / "results" / "models.json"
    if not path.exists():
        return None
    models = json.loads(path.read_text())
    past = [m for m in models if utc(m["usable_from"]) <= utc(at)]
    return max(past, key=lambda m: utc(m["usable_from"])) if past else None
