from .cli import main
import sys

try:
    main()
except (ValueError, RuntimeError, OSError) as e:
    print("错误:", e, file=sys.stderr)
    sys.exit(1)
