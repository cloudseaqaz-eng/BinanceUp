"""Point-in-time Binance slow-setup research. No trading or execution code."""
